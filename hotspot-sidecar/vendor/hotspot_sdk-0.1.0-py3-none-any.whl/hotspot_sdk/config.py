"""SDK configuration — injection-first, no home-directory coupling.

The original app read ``~/.openclaw/workspace/group-monitor/config.json`` at import
time (see ``group_monitor/config.py``). That hard-codes the author's machine and
makes the engine impossible to embed. Here the same shape is expressed as pydantic
models, and the SDK is configured by *passing a config object in*.

Resolution priority (highest first):
    1. An explicit ``HotspotConfig`` / dict passed to ``load_config``
    2. Environment variables (``HOTSPOT_*``)
    3. An explicit JSON file path passed to ``load_config(path=...)``
    4. Built-in defaults

By design nothing is read from ``~/.openclaw`` unless the caller explicitly points
``load_config`` at such a file.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator


class AlertThresholds(BaseModel):
    rank_jump: int = Field(5, ge=1, le=40)
    rank_drop: int = Field(5, ge=1, le=40)
    new_entry_top: int = Field(40, ge=1, le=40)


class DrillAdaptive(BaseModel):
    enabled: bool = True
    hot_threshold: int = Field(10, gt=0)
    cold_threshold: int = Field(3, ge=0)
    window_count: int = Field(2, ge=1, le=10)


class DiscussionSweep(BaseModel):
    enabled: bool = True
    hours: int = Field(1, ge=0)
    probe_limit: int = Field(15, ge=1, le=100)
    max_fetch: int = Field(5, ge=1, le=50)
    timeout_s: int = Field(300, ge=1)


class ScrapeConfig(BaseModel):
    sample_keywords: int = Field(40, ge=1, le=40)
    pages_per_keyword: int = Field(2, ge=1, le=10)
    drill_dedup_hours: int = Field(6, ge=0, le=72)
    always_drill_top_n: int = Field(5, ge=0)
    top_n_dedup_hours: int = Field(4, ge=0, le=48)
    drill_adaptive: DrillAdaptive = Field(default_factory=DrillAdaptive)
    watch_keywords: list[str] = Field(default_factory=list)
    filter_sample_keywords: int = Field(2, ge=0)
    enable_yield: bool = True
    bot_scrape_timeout_s: int = Field(2400, ge=1)
    discussion_sweep: DiscussionSweep = Field(default_factory=DiscussionSweep)
    interest_categories: list[str] = Field(
        default_factory=lambda: [
            "成人内容", "主播直播", "影视资源",
            "资源分享", "二次元动漫", "情感交流",
        ]
    )


class ForwardConfig(BaseModel):
    default_limit: int = Field(3, ge=1)
    default_max_size_mb: int = Field(2000, ge=1)
    candidate_multiplier: int = Field(10, ge=1)
    album_window: int = Field(10, ge=1)


# Default service words (jisou / 极搜 trigger vocabulary) carried over verbatim.
_DEFAULT_SERVICE_WORDS = [
    "極搜", "极搜", "jisou", "Jisou", "JISOU",
    "熱搜", "热搜", "熱搜榜", "热搜榜",
    "榜", "榜單", "榜单", "排行", "排行榜",
    "熱點", "热点", "今日熱點", "今日热点",
    "最新", "新進", "新进", "diff", "Diff",
    "看熱搜", "看熱搜榜", "看榜", "看極搜",
]


class TelegramConfig(BaseModel):
    """Telethon credentials + push routing.

    ``api_id`` / ``api_hash`` come from https://my.telegram.org. ``session_path``
    points at the Telethon ``.session`` file; the SDK never assumes a home dir.
    """

    api_id: int = 0
    api_hash: str = ""
    session_path: str = ""
    push_chat_id: int = 0          # 0 = unset → fails safe, never auto-routes anywhere
    push_chat_name: str = ""
    push_chat_name_hint: str = ""
    source_channels: list[str] = Field(default_factory=lambda: ["@dgjum"])
    service_words: list[str] = Field(default_factory=lambda: list(_DEFAULT_SERVICE_WORDS))

    @field_validator("service_words")
    @classmethod
    def _non_empty_words(cls, v: list[str]) -> list[str]:
        if not all(isinstance(s, str) for s in v):
            raise ValueError("service_words must be a list of strings")
        return v


class HotspotConfig(BaseModel):
    """Top-level SDK config. Mirrors the original app's config.json shape."""

    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    alert_thresholds: AlertThresholds = Field(default_factory=AlertThresholds)
    scrape: ScrapeConfig = Field(default_factory=ScrapeConfig)
    forward: ForwardConfig = Field(default_factory=ForwardConfig)
    media_sample_posts_per_channel: int = Field(3, ge=1)

    # Where engine working data (sqlite, caches) lives. Caller-controlled; if unset
    # the engine falls back to a temp-style dir but never to ~/.openclaw.
    data_dir: str = ""

    def require_telegram(self) -> "HotspotConfig":
        """Raise if the Telegram credentials needed to actually run are missing.

        Kept separate from model validation so a config can be constructed for the
        scoring/content features without TG credentials.
        """
        missing = []
        if not self.telegram.api_id:
            missing.append("telegram.api_id")
        if not self.telegram.api_hash:
            missing.append("telegram.api_hash")
        if not self.telegram.push_chat_id and not self.telegram.push_chat_name_hint:
            missing.append("telegram.push_chat_id or telegram.push_chat_name_hint")
        if missing:
            raise ValueError(
                "Telegram config incomplete; set: " + ", ".join(missing)
            )
        return self


def _env_overrides() -> dict[str, Any]:
    """Collect ``HOTSPOT_*`` env vars into a nested override dict.

    Only a curated set of high-value knobs is wired to env, matching what an
    operator most often overrides per-deploy. Everything else stays config-object
    driven.
    """
    tg: dict[str, Any] = {}
    mapping = {
        "HOTSPOT_TG_API_ID": ("api_id", int),
        "HOTSPOT_TG_API_HASH": ("api_hash", str),
        "HOTSPOT_TG_SESSION_PATH": ("session_path", str),
        "HOTSPOT_TG_PUSH_CHAT_ID": ("push_chat_id", int),
        "HOTSPOT_TG_PUSH_CHAT_NAME_HINT": ("push_chat_name_hint", str),
    }
    for env_key, (field, cast) in mapping.items():
        raw = os.environ.get(env_key)
        if raw is not None and raw != "":
            tg[field] = cast(raw)
    out: dict[str, Any] = {}
    if tg:
        out["telegram"] = tg
    if os.environ.get("HOTSPOT_DATA_DIR"):
        out["data_dir"] = os.environ["HOTSPOT_DATA_DIR"]
    return out


def _deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(base[k], v)
        else:
            out[k] = v
    return out


def load_config(
    config: HotspotConfig | dict | None = None,
    *,
    path: str | os.PathLike | None = None,
) -> HotspotConfig:
    """Resolve the effective config.

    Priority: explicit ``config`` > env vars > ``path`` JSON file > defaults.
    Never reads any home-directory location implicitly.
    """
    base: dict[str, Any] = {}

    if path is not None:
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"config file not found: {p}")
        base = json.loads(p.read_text(encoding="utf-8"))

    base = _deep_merge(base, _env_overrides())

    if config is not None:
        # exclude_unset so an explicit object only overrides the fields the caller
        # actually set — otherwise every default (api_id=0, push_chat_id=0, ...) would
        # clobber the env/file layers, silently dropping env-supplied credentials.
        explicit = (
            config.model_dump(exclude_unset=True)
            if isinstance(config, HotspotConfig)
            else dict(config)
        )
        base = _deep_merge(base, explicit)

    return HotspotConfig.model_validate(base)
