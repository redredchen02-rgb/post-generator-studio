"""Load the bundled scoring vocabulary.

The vocab lives as packaged data under ``hotspot_sdk/scoring/vocab`` (one term per
line; blank lines and ``#`` comments ignored; UTF-8 simplified Chinese — see
vocab/README.md). Loading goes through ``importlib.resources`` so it works after a
``pip install`` (zip/site-packages), not only from a source checkout.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from importlib import resources

# category -> relative file paths within vocab/
_LAYOUT: dict[str, tuple[str, ...]] = {
    "hot_words_events": ("hot_words/events.txt",),
    "hot_words_nsfw": ("hot_words/nsfw_actions.txt",),
    "cta": ("cta/endings.txt",),
    "ai_banned_template_openers": ("ai_banned/template_openers.txt",),
    "ai_banned_connectors": ("ai_banned/connectors.txt",),
    "style_adjectives": ("style_accents/adjectives_strong.txt",),
    "style_colloq": ("style_accents/colloq_fragments.txt",),
}

# opener categories are loaded individually so the matched category is reportable
_OPENER_FILES: tuple[str, ...] = (
    "surprise", "absurd", "shock", "laugh", "overwhelm", "doubt",
)


def _parse_terms(text: str) -> list[str]:
    out: list[str] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        out.append(s)
    return out


def _read(rel: str) -> list[str]:
    root = resources.files("hotspot_sdk.scoring").joinpath("vocab")
    target = root.joinpath(rel)
    return _parse_terms(target.read_text(encoding="utf-8"))


@dataclass(frozen=True)
class Vocab:
    """Loaded vocabulary term sets, keyed by signal category."""

    terms: dict[str, list[str]] = field(default_factory=dict)
    openers: dict[str, list[str]] = field(default_factory=dict)  # category -> terms

    def get(self, category: str) -> list[str]:
        return self.terms.get(category, [])


@lru_cache(maxsize=1)
def load_vocab() -> Vocab:
    terms = {cat: _read(files[0]) for cat, files in _LAYOUT.items()}
    openers = {name: _read(f"openers/{name}.txt") for name in _OPENER_FILES}
    return Vocab(terms=terms, openers=openers)
