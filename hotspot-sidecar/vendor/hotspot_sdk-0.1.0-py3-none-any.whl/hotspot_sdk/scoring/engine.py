"""Vocabulary-driven copywriting / hotness scorer.

Scores a piece of copy by matching it against the bundled vocabulary (see
``vocab_loader``). The original weighting lived in a compiled module and could not
be recovered, so the weights below are a transparent, documented reconstruction of
the *intent* described in vocab/README.md, not the original constants. Every signal
is surfaced in ``ScoreResult.breakdown`` so a host can re-weight downstream.

Signal intent (from README):
    + hot_words/events       — trending event hooks (激战/开盒/反差/塌房…)
    + hot_words/nsfw_actions — explicit action hooks
    + openers/*              — punchy emotional openers (6 categories)
    + cta/endings            — engagement closers (留言区见…)
    + style_accents          — strong adjectives / colloquial fragments
    - ai_banned/*            — "AI slop": template openers & formal connectors

Matching is substring-based (Chinese has no word boundaries). The vocab is
simplified Chinese; the original app did 簡<->繁 normalisation before scoring — that
normalisation is NOT included here (deferred), so callers should feed simplified text
or normalise upstream.
"""
from __future__ import annotations

from ..adapters import OutputSink, ScoreResult, resolve_sink, safe_deliver
from .vocab_loader import Vocab, load_vocab

# Per-match weights (documented reconstruction, not original constants).
W_EVENT = 3.0
W_NSFW = 2.0
W_OPENER = 2.0          # flat bonus if any opener category present
W_CTA = 2.0            # flat bonus if a CTA ending present
W_ADJ = 0.5            # per strong adjective
W_COLLOQ = 1.0         # per colloquial fragment
P_TEMPLATE = 5.0       # penalty per AI template opener
P_CONNECTOR = 2.0      # penalty per AI connector
ADJ_CAP = 3.0          # cap total adjective bonus (README: 強形容詞 <=25% 密度)


def _count_matches(text: str, terms: list[str]) -> list[str]:
    return [t for t in terms if t and t in text]


class VocabScorer:
    """Score copy against the bundled vocabulary.

    ``score`` is pure and returns a fully transparent ``ScoreResult``. Construction
    is cheap (vocab is cached); pass a ``config`` for API symmetry (unused today).
    """

    def __init__(self, config=None, vocab: Vocab | None = None) -> None:
        self.config = config
        self.vocab = vocab or load_vocab()

    def score(self, text: str) -> ScoreResult:
        text = text or ""
        breakdown: dict[str, float] = {}
        flags: list[str] = []

        if not text.strip():
            return ScoreResult(text=text, score=0.0, breakdown={}, flags=[])

        v = self.vocab

        # hot words
        events = _count_matches(text, v.get("hot_words_events"))
        nsfw = _count_matches(text, v.get("hot_words_nsfw"))
        if events:
            breakdown["hot_words_events"] = round(W_EVENT * len(events), 3)
        if nsfw:
            breakdown["hot_words_nsfw"] = round(W_NSFW * len(nsfw), 3)

        # openers (record matched category)
        opener_hit = None
        for cat, terms in v.openers.items():
            if _count_matches(text, terms):
                opener_hit = cat
                break
        if opener_hit:
            breakdown["openers"] = W_OPENER
            flags.append(f"opener:{opener_hit}")

        # cta
        if _count_matches(text, v.get("cta")):
            breakdown["cta"] = W_CTA
            flags.append("cta")

        # style accents
        adjs = _count_matches(text, v.get("style_adjectives"))
        colloq = _count_matches(text, v.get("style_colloq"))
        if adjs:
            breakdown["style_adjectives"] = round(min(ADJ_CAP, W_ADJ * len(adjs)), 3)
        if colloq:
            breakdown["style_colloq"] = round(W_COLLOQ * len(colloq), 3)

        # ai-banned penalties
        templates = _count_matches(text, v.get("ai_banned_template_openers"))
        connectors = _count_matches(text, v.get("ai_banned_connectors"))
        penalty = P_TEMPLATE * len(templates) + P_CONNECTOR * len(connectors)
        if penalty:
            breakdown["ai_banned"] = round(-penalty, 3)
            flags.append("ai_slop")

        score = round(sum(breakdown.values()), 3)
        return ScoreResult(text=text, score=score, breakdown=breakdown, flags=flags)

    async def score_and_deliver(
        self, text: str, sink: OutputSink | None = None
    ) -> ScoreResult:
        result = self.score(text)
        await safe_deliver(resolve_sink(sink), result)
        return result
