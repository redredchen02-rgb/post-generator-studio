"""Vocab pool loader.

Reads categorized .txt files under this directory and returns a placeholder
dict for prompt injection. Supports both dev mode and PyInstaller frozen
mode via sys._MEIPASS detection.

Placeholder naming convention:
    {vocab_openers_surprise} -> "乖乖, 天哪, ..."
    {vocab_cta}              -> "吃瓜兄弟们, ..."
    {vocab_banned_connectors}-> "此外, 与此同时, ..."
    etc.

Cached after first load (vocab rarely changes at runtime).
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Dict, List

log = logging.getLogger(__name__)

_CACHE: Dict[str, str] | None = None


def _vocab_root() -> Path:
    """Locate vocab dir. PyInstaller frozen puts datas beside executable."""
    if getattr(sys, "frozen", False):
        # PyInstaller sets _MEIPASS to the tmp extraction dir
        meipass = Path(getattr(sys, "_MEIPASS", ""))
        candidate = meipass / "backend" / "core" / "scoring" / "vocab"
        if candidate.exists():
            return candidate
        # Fallback: beside this file (if datas placed differently)
    return Path(__file__).parent


def _load_txt(rel_path: str) -> List[str]:
    """Read a .txt file, stripping blanks and # comments. Return [] on miss."""
    p = _vocab_root() / rel_path
    if not p.exists():
        log.warning("vocab file missing: %s", rel_path)
        return []
    try:
        lines = p.read_text(encoding="utf-8").splitlines()
    except OSError as e:
        log.warning("vocab read failed %s: %s", rel_path, e)
        return []
    return [ln.strip() for ln in lines if ln.strip() and not ln.startswith("#")]


def _join(words: List[str]) -> str:
    """Join words with 「、」（Chinese-style separator — more natural for LLM）."""
    return "、".join(words)


def build_vocab_injection() -> Dict[str, str]:
    """Return placeholder -> value dict for prompt .replace().

    All values are 「、」-joined Chinese strings ready for inline injection.
    """
    global _CACHE
    if _CACHE is not None:
        return _CACHE

    openers_surprise  = _load_txt("openers/surprise.txt")
    openers_absurd    = _load_txt("openers/absurd.txt")
    openers_shock     = _load_txt("openers/shock.txt")
    openers_laugh     = _load_txt("openers/laugh.txt")
    openers_overwhelm = _load_txt("openers/overwhelm.txt")
    openers_doubt     = _load_txt("openers/doubt.txt")

    openers_all = (
        openers_surprise + openers_absurd + openers_shock +
        openers_laugh + openers_overwhelm + openers_doubt
    )

    _CACHE = {
        "{vocab_openers_surprise}":   _join(openers_surprise),
        "{vocab_openers_absurd}":     _join(openers_absurd),
        "{vocab_openers_shock}":      _join(openers_shock),
        "{vocab_openers_laugh}":      _join(openers_laugh),
        "{vocab_openers_overwhelm}":  _join(openers_overwhelm),
        "{vocab_openers_doubt}":      _join(openers_doubt),
        "{vocab_openers_all}":        _join(openers_all),
        "{vocab_cta}":                _join(_load_txt("cta/endings.txt")),
        "{vocab_hot_events}":         _join(_load_txt("hot_words/events.txt")),
        "{vocab_hot_nsfw}":           _join(_load_txt("hot_words/nsfw_actions.txt")),
        "{vocab_adj_strong}":         _join(_load_txt("style_accents/adjectives_strong.txt")),
        "{vocab_colloq}":             _join(_load_txt("style_accents/colloq_fragments.txt")),
        "{vocab_banned_connectors}":  _join(_load_txt("ai_banned/connectors.txt")),
        "{vocab_banned_openers}":     _join(_load_txt("ai_banned/template_openers.txt")),
    }
    log.info("vocab injection loaded: %d placeholders", len(_CACHE))
    return _CACHE


def inject(prompt: str) -> str:
    """Replace all {vocab_*} placeholders in prompt with joined word lists.

    Safe to call on prompts that contain no placeholders (no-op).
    """
    vocab = build_vocab_injection()
    for placeholder, value in vocab.items():
        if placeholder in prompt:
            prompt = prompt.replace(placeholder, value)
    return prompt


def reload_cache() -> None:
    """Force reload — useful when editing vocab files at runtime during dev."""
    global _CACHE
    _CACHE = None
    build_vocab_injection()


def pick_enforced_opener() -> str:
    """Pick ONE random opener across all 6 categories.

    Used to force cross-article opener variety — without this the LLM
    settles on the highest-frequency option ("天哪") every call. Caller
    should replace {enforced_opener} in the prompt with this return value.
    """
    import random
    cats = ["surprise", "absurd", "shock", "laugh", "overwhelm", "doubt"]
    all_openers: list[str] = []
    for cat in cats:
        all_openers.extend(_load_txt(f"openers/{cat}.txt"))
    if not all_openers:
        return "天哪"  # fallback
    return random.choice(all_openers)


if __name__ == "__main__":
    vocab = build_vocab_injection()
    for k, v in vocab.items():
        print(f"{k:35s} -> {v[:60]}{'...' if len(v) > 60 else ''}")
    print(f"\nTotal placeholders: {len(vocab)}")
