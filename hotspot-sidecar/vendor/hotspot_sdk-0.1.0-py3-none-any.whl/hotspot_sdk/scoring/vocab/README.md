# Vocab Pool

語料驅動的詞彙池，供 LLM 評分/改寫 prompt 注入使用。所有詞彙從 588 篇
真實文章統計驗證過。

## 目錄結構

```
vocab/
├── openers/              # 開場驚嘆詞（6 類）
│   ├── surprise.txt      # 驚嘆 (乖乖/天哪/卧槽...)
│   ├── absurd.txt        # 荒謬 (离谱/绝了...)
│   ├── shock.txt         # 震撼 (炸裂/麻了...)
│   ├── laugh.txt         # 笑噴 (笑死/没绷住...)
│   ├── overwhelm.txt     # 受不了 (上头/血脉喷张/欲罢不能...)
│   └── doubt.txt         # 懷疑 (真的假的/好家伙...)
├── cta/
│   └── endings.txt       # 結尾互動 (吃瓜兄弟们/留言区见...)
├── hot_words/
│   ├── events.txt        # 事件熱詞 (激战/开盒/反差/塌房...)
│   └── nsfw_actions.txt  # NSFW 動作詞 (后入/口交/骑乘...)
├── style_accents/
│   ├── adjectives_strong.txt  # 強形容詞 (限 <=25% 密度)
│   └── colloq_fragments.txt   # 口語殘缺（強制補，≥1 per article）
└── ai_banned/
    ├── connectors.txt         # 禁用 AI 連接詞
    └── template_openers.txt   # 禁用模板化開場
```

## 格式

- 一行一個詞
- 空行與 `#` 開頭行忽略
- UTF-8，簡體中文（app 層做 簡<->繁 轉換）

## 維護規則

- 新增詞前用語料驗證（頻次 > 3 再加）
- 禁用詞保守（真人也會用就不禁）
- 改動後跑一輪 regression 測試 scoring 分布
