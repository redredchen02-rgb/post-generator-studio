"""hotspot_sdk.scoring — vocabulary-driven copywriting / hotness scoring."""
from __future__ import annotations

from ..adapters import ScoreResult
from .engine import VocabScorer
from .vocab_loader import Vocab, load_vocab

__all__ = ["VocabScorer", "Vocab", "load_vocab", "score"]


def score(text: str) -> ScoreResult:
    """Convenience: score ``text`` with a default ``VocabScorer``."""
    return VocabScorer().score(text)
