"""hotspot-sdk — reusable functionality extracted from the 熱點監控 app.

Four capability packages:
    - ``hotspot_sdk.telegram`` : Telegram monitoring / forwarding engine
    - ``hotspot_sdk.hotspot``  : hotspot keyword ranking + alerts
    - ``hotspot_sdk.content``  : NSFW / cover content analysis
    - ``hotspot_sdk.scoring``  : copywriting / hotness scoring

Configuration is injection-first (see ``hotspot_sdk.config``) and all capabilities
emit results through a unified ``OutputSink`` (see ``hotspot_sdk.adapters``).
"""
from __future__ import annotations

from .adapters import (
    CallbackSink,
    CollectingSink,
    ContentVerdict,
    ForwardedMedia,
    OutputSink,
    RankingAlert,
    ScoreResult,
    clear_default_sink,
    get_default_sink,
    resolve_sink,
    safe_deliver,
    set_default_sink,
)
from .config import HotspotConfig, TelegramConfig, load_config

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "HotspotConfig",
    "TelegramConfig",
    "load_config",
    "OutputSink",
    "CollectingSink",
    "CallbackSink",
    "ForwardedMedia",
    "RankingAlert",
    "ContentVerdict",
    "ScoreResult",
    "set_default_sink",
    "clear_default_sink",
    "get_default_sink",
    "resolve_sink",
    "safe_deliver",
]
