"""hotspot_sdk.content — NSFW detection, scene split, and cover/action scoring.

Heavy deps (nudenet, opencv, scenedetect) are lazy-imported by submodules, so
importing this package does not require them; install with ``hotspot-sdk[content]``.
"""
from __future__ import annotations

from .analyze import ContentAnalyzer
from .frame_hash import dhash, hamming, is_visual_dup
from .scenes import KeyFrame, extract_key_frames
from .scorers import ACTION, GENITAL, NSFW_CLASSES, CoverScorer, NudeNetScorer, NullScorer

__all__ = [
    "ContentAnalyzer",
    "CoverScorer",
    "NudeNetScorer",
    "NullScorer",
    "dhash",
    "hamming",
    "is_visual_dup",
    "extract_key_frames",
    "KeyFrame",
    "ACTION",
    "GENITAL",
    "NSFW_CLASSES",
]
