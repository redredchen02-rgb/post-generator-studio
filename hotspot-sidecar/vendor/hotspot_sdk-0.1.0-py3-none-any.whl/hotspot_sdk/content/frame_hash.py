"""Perceptual hash (dHash) + Hamming distance for visual-dedup of frames.

Reconstructed from the original ``backend/core/cover/frame_hash.py`` (which
decompiled CLEAN except for a loop-return artifact in ``dhash`` and a missing
``is_visual_dup`` body). Behavior preserved:

- ``dhash`` resizes a grayscale frame to (hash_size+1, hash_size), compares
  horizontally-adjacent pixel brightness (left > right -> 1), then OR-s in a
  guard bit so a *computed* hash is never 0 (even a solid/black frame). That
  keeps a real all-False hash from colliding with the 0 "not computed" sentinel.
- ``is_visual_dup`` treats phash==0 (and any 0 in ``seen``) as the sentinel and
  never dedupes against it.

cv2/numpy are imported lazily so this module imports without them.
"""
from __future__ import annotations

VISUAL_DUP_HAMMING = 10
_DHASH_GUARD_SHIFT = 64


def dhash(gray, hash_size: int = 8) -> int:
    """Single-channel grayscale image -> (hash_size*hash_size)-bit difference hash.

    The result always has the guard bit set, so it is never 0 for a real frame.
    """
    import cv2  # lazy

    if getattr(gray, "ndim", None) != 2:
        raise ValueError("dhash 需要单通道灰阶图 (H, W)")
    guard = 1 << max(_DHASH_GUARD_SHIFT, hash_size * hash_size)
    resized = cv2.resize(gray, (hash_size + 1, hash_size), interpolation=cv2.INTER_AREA)
    diff = resized[:, 1:] > resized[:, :-1]
    bits = 0
    for bit in diff.flatten():
        bits = (bits << 1) | int(bit)
    return bits | guard


def hamming(a: int, b: int) -> int:
    """Hamming distance between two dHashes (number of differing bits)."""
    return bin(a ^ b).count("1")


def is_visual_dup(phash: int, seen, threshold: int = VISUAL_DUP_HAMMING) -> bool:
    """Is ``phash`` visually duplicate of any hash already in ``seen``?

    Sentinel: phash==0 (not computed / legacy) -> always False. Zeros inside
    ``seen`` are skipped. Real hashes carry the guard bit so they are never 0.
    """
    if not phash:
        return False
    for s in seen:
        if not s:
            continue
        if hamming(phash, s) <= threshold:
            return True
    return False
