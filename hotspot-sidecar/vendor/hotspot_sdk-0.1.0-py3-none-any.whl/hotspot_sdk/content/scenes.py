"""Key-frame extraction from video, with visual dedup.

Splits a video into scenes (scenedetect) and pulls one representative frame per
scene, then drops visually-duplicate frames using the dHash logic in
``frame_hash`` (preserves the original "different scene, far apart, but near-
identical image" dedup the app added).

scenedetect + cv2 are lazy-imported so this module imports without them.
"""
from __future__ import annotations

from dataclasses import dataclass

from .frame_hash import VISUAL_DUP_HAMMING, dhash, is_visual_dup


@dataclass
class KeyFrame:
    index: int          # frame number in the source video
    scene_idx: int
    frame: object       # decoded BGR numpy array


def _to_gray(frame):
    import cv2  # lazy

    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def detect_scene_frames(video_path: str, threshold: float = 27.0) -> list[tuple[int, int]]:
    """Return [(scene_idx, frame_number)] — the start frame of each detected scene.

    Thin wrapper over scenedetect's content detector. Lazy-imported.
    """
    from scenedetect import detect, ContentDetector  # lazy

    scene_list = detect(video_path, ContentDetector(threshold=threshold))
    out: list[tuple[int, int]] = []
    for i, (start, _end) in enumerate(scene_list):
        out.append((i, start.get_frames()))
    return out


def extract_key_frames(
    video_path: str,
    *,
    threshold: float = 27.0,
    hamming_threshold: int = VISUAL_DUP_HAMMING,
    reader=None,
) -> list[KeyFrame]:
    """Extract one deduped key frame per scene.

    ``reader`` is an injectable callable ``(video_path, frame_number) -> frame`` for
    testing; by default frames are read with OpenCV. Unreadable frames are skipped
    (never raises on a bad frame).
    """
    if reader is None:
        reader = _default_reader

    scene_frames = detect_scene_frames(video_path, threshold=threshold)
    seen_hashes: list[int] = []
    out: list[KeyFrame] = []
    for scene_idx, frame_no in scene_frames:
        try:
            frame = reader(video_path, frame_no)
        except Exception:
            continue
        if frame is None:
            continue
        try:
            ph = dhash(_to_gray(frame))
        except Exception:
            ph = 0
        if is_visual_dup(ph, seen_hashes, hamming_threshold):
            continue
        if ph:
            seen_hashes.append(ph)
        out.append(KeyFrame(index=frame_no, scene_idx=scene_idx, frame=frame))
    return out


def _default_reader(video_path: str, frame_number: int):
    import cv2  # lazy

    cap = cv2.VideoCapture(video_path)
    try:
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
        ok, frame = cap.read()
        return frame if ok else None
    finally:
        cap.release()
