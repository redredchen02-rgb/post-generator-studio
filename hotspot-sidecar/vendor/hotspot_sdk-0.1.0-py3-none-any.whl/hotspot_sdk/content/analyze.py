"""ContentAnalyzer — NSFW/cover analysis pipeline delivering ContentVerdict.

Ties the scorer + scene splitter together and emits one ``ContentVerdict`` per
analyzed media path through the SDK ``OutputSink``. Preserves the original
"never raise on a bad frame" guarantee.
"""
from __future__ import annotations

from hotspot_sdk.adapters import ContentVerdict, OutputSink, resolve_sink, safe_deliver
from hotspot_sdk.config import HotspotConfig, load_config

from .scenes import extract_key_frames
from .scorers import CoverScorer, NudeNetScorer


class ContentAnalyzer:
    """Analyze images/videos for NSFW + cover/action signals.

    ``scorer`` defaults to :class:`NudeNetScorer`. Pass :class:`NullScorer` or your
    own :class:`CoverScorer` (e.g. a restored CLIP scorer) to override.
    """

    def __init__(
        self,
        config: HotspotConfig | dict | None = None,
        scorer: CoverScorer | None = None,
        sink: OutputSink | None = None,
    ) -> None:
        self.config = config if isinstance(config, HotspotConfig) else load_config(config)
        self.scorer = scorer or NudeNetScorer()
        self.sink = resolve_sink(sink)

    def _read_image(self, path: str):
        import cv2  # lazy

        return cv2.imread(path)

    def _verdict_from_frame(self, path: str, frame, extra_meta: dict | None = None) -> ContentVerdict:
        scored = self.scorer.score_frame(frame)
        meta = dict(scored.get("meta", {}))
        if extra_meta:
            meta.update(extra_meta)
        return ContentVerdict(
            path=path,
            nsfw_score=float(scored.get("nsfw", 0.0)),
            action_score=float(scored.get("action", 0.0)),
            sharp_score=float(scored.get("sharp", 0.0)),
            labels={k: float(v) for k, v in scored.get("labels", {}).items()},
            meta=meta,
        )

    async def analyze_image(self, path: str, *, frame=None) -> ContentVerdict | None:
        """Score a single image and deliver the verdict.

        ``frame`` may be supplied directly (decoded array) to skip disk read.
        Returns the verdict, or None if the frame was unreadable.
        """
        if frame is None:
            try:
                frame = self._read_image(path)
            except Exception:
                frame = None
        if frame is None:
            return None
        verdict = self._verdict_from_frame(path, frame)
        await safe_deliver(self.sink, verdict)
        return verdict

    async def analyze_video(self, path: str, *, threshold: float = 27.0, reader=None) -> list[ContentVerdict]:
        """Split video into deduped key frames, score each, deliver each verdict.

        Bad frames are skipped silently. Returns the list of delivered verdicts.
        """
        verdicts: list[ContentVerdict] = []
        try:
            key_frames = extract_key_frames(path, threshold=threshold, reader=reader)
        except Exception:
            key_frames = []
        for kf in key_frames:
            try:
                verdict = self._verdict_from_frame(
                    path, kf.frame, extra_meta={"scene_idx": kf.scene_idx, "frame_index": kf.index}
                )
            except Exception:
                continue
            await safe_deliver(self.sink, verdict)
            verdicts.append(verdict)
        return verdicts
