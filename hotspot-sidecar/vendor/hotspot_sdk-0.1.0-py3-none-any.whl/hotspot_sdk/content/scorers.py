"""Pluggable cover/NSFW frame scorers.

The original app scored covers along two axes:
  - an NSFW/exposure axis from **nudenet** detections (label vocabulary preserved
    below from ``backend/core/cover/cover_select.py``), and
  - an **action** axis from an external **CLIP** sidecar (``clip_act`` in a torch
    venv), keyed by ACTION_KEYS = blowjob/facial/rear/climax, plus a CLIP-based
    sharpness score.

The CLIP model (``clip_act.flavor_and_clip_sharp``) was NOT packaged in the app and
is **not recoverable** from the build artifact. So scoring is made pluggable:

  - ``NudeNetScorer``  — default. Real nudenet labels -> nsfw_score, and a nudenet
    *proxy* for the action axis (genital/buttocks exposure). No CLIP fidelity.
  - ``NullScorer``     — returns zeros and flags ``model_missing`` so callers can
    detect that no real model is wired.
  - ``CoverScorer``    — Protocol; supply your own (e.g. a restored CLIP scorer).

nudenet is lazy-imported so this module imports without it.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

# --- nudenet label vocabulary (verbatim from cover_select.py) --------------------
BREAST = frozenset({"FEMALE_BREAST_EXPOSED"})
GENITAL = frozenset(
    {"ANUS_EXPOSED", "MALE_GENITALIA_EXPOSED", "FEMALE_GENITALIA_EXPOSED"}
)
# "action" axis proxy: genital exposure + buttocks (rear). Mirrors cover_select.ACTION.
ACTION = frozenset(GENITAL | {"BUTTOCKS_EXPOSED"})
# Everything that counts toward an NSFW/exposure score.
NSFW_CLASSES = frozenset(
    BREAST
    | GENITAL
    | {
        "BUTTOCKS_EXPOSED",
        "FEMALE_BREAST_EXPOSED",
        "MALE_BREAST_EXPOSED",
        "BELLY_EXPOSED",
        "ARMPITS_EXPOSED",
    }
)


@runtime_checkable
class CoverScorer(Protocol):
    """Scores a single decoded frame (a numpy BGR array, as from ``cv2.imread``).

    Returns a dict with at least: ``nsfw`` (float 0-1), ``action`` (float 0-1),
    ``sharp`` (float), ``labels`` (dict[str, float]). ``meta`` is optional.
    """

    def score_frame(self, frame) -> dict:  # pragma: no cover - protocol
        ...


def _detections_to_scores(detections: list[dict]) -> tuple[float, float, dict]:
    """Collapse nudenet detections -> (nsfw_score, action_score, labels).

    Each detection is nudenet's ``{"class": str, "score": float, ...}``. We take the
    max confidence per axis. ``labels`` keeps the max confidence seen per class.
    """
    labels: dict[str, float] = {}
    for d in detections or []:
        cls = d.get("class") or d.get("label") or ""
        score = float(d.get("score", d.get("confidence", 0.0)) or 0.0)
        if not cls:
            continue
        if score > labels.get(cls, 0.0):
            labels[cls] = score
    nsfw = max((labels[c] for c in labels if c in NSFW_CLASSES), default=0.0)
    action = max((labels[c] for c in labels if c in ACTION), default=0.0)
    return nsfw, action, labels


class NudeNetScorer:
    """Default scorer backed by nudenet. No CLIP action fidelity (proxy only)."""

    def __init__(self, detector=None) -> None:
        self._detector = detector  # injectable for tests; else lazy-built

    def _ensure_detector(self):
        if self._detector is None:
            from nudenet import NudeDetector  # lazy

            self._detector = NudeDetector()
        return self._detector

    def detect(self, frame_path_or_array) -> list[dict]:
        det = self._ensure_detector()
        return det.detect(frame_path_or_array)

    def score_frame(self, frame) -> dict:
        detections = self.detect(frame)
        nsfw, action, labels = _detections_to_scores(detections)
        return {
            "nsfw": nsfw,
            "action": action,
            "sharp": 0.0,  # CLIP sharpness unavailable; see module docstring
            "labels": labels,
            "meta": {"scorer": "nudenet", "clip_action": False},
        }


class NullScorer:
    """No-op scorer: zeros, with an explicit model-missing flag.

    Use when neither nudenet nor a CLIP model is available, so the pipeline still
    runs and downstream code can see that no real scoring happened.
    """

    def score_frame(self, frame) -> dict:
        return {
            "nsfw": 0.0,
            "action": 0.0,
            "sharp": 0.0,
            "labels": {"model_missing": 1.0},
            "meta": {"scorer": "null", "model_missing": True, "clip_action": False},
        }
