"""Pure ranking-change detection + adaptive dedup.

Reconstructed from the original app's documented semantics. The threshold meanings
are copied verbatim from ``group_monitor/config.py`` (the authoritative source):

    rank_jump  -- push 📈 when a keyword's rank improves by >= N
    rank_drop  -- push 📉 when a keyword's rank drops by >= N
    new_entry_top -- alert new entries up to top N

    drill_adaptive: avg recent new_count >= hot_threshold  -> halve dedup window
                    avg recent new_count <  cold_threshold -> double dedup window

NOTE (inferred): the concrete comparison loop that applied these thresholds lived in
the app's bot_scraper/digest path, which was not present in the recovered source
(neither the clean vendored package nor the decompiled tree). The data-access
building blocks in ``db.py`` (keywords_in_window/best_rank, recent_drill_stats) are
real; the diff loop below reconstructs the documented behaviour around them.

Rank convention: 1-based, lower number = higher position (rank 1 is the top).
"""
from __future__ import annotations

from hotspot_sdk.adapters import RankingAlert
from hotspot_sdk.config import AlertThresholds, DrillAdaptive


def diff_rankings(
    prev: dict[str, int],
    curr: dict[str, int],
    thresholds: AlertThresholds,
    *,
    include_off_board: bool = False,
) -> list[RankingAlert]:
    """Compare two leaderboards and emit alerts for significant changes.

    ``prev`` / ``curr`` map keyword -> 1-based rank. Returns alerts ordered by the
    current rank (most prominent first).

    ``include_off_board`` (opt-in): also emit a ``drop`` for a keyword that was within
    the watched band (prev rank <= ``new_entry_top``) and vanished from ``curr`` — the
    largest possible drop. Off by default because the original app's recovered source
    did not contain this comparison, so the semantics are inferred, not verified, and a
    churning board could make it noisy. Off-board drops carry ``rank=0``.
    """
    alerts: list[RankingAlert] = []

    if include_off_board:
        for keyword, old_rank in prev.items():
            if keyword not in curr and old_rank <= thresholds.new_entry_top:
                alerts.append(
                    RankingAlert(
                        keyword=keyword,
                        kind="drop",
                        rank=0,  # 0 == off the board
                        prev_rank=old_rank,
                        delta=0,
                        meta={"off_board": True},
                    )
                )

    for keyword, cur_rank in curr.items():
        old_rank = prev.get(keyword)

        if old_rank is None:
            # New keyword: alert only if it lands within the watched top band.
            if cur_rank <= thresholds.new_entry_top:
                alerts.append(
                    RankingAlert(
                        keyword=keyword,
                        kind="new_entry",
                        rank=cur_rank,
                        prev_rank=0,
                        delta=0,
                    )
                )
            continue

        if cur_rank < old_rank:
            # Lower number == moved up. Improvement magnitude.
            improve = old_rank - cur_rank
            if improve >= thresholds.rank_jump:
                alerts.append(
                    RankingAlert(
                        keyword=keyword,
                        kind="jump",
                        rank=cur_rank,
                        prev_rank=old_rank,
                        delta=improve,
                    )
                )
        elif cur_rank > old_rank:
            drop = cur_rank - old_rank
            if drop >= thresholds.rank_drop:
                alerts.append(
                    RankingAlert(
                        keyword=keyword,
                        kind="drop",
                        rank=cur_rank,
                        prev_rank=old_rank,
                        delta=drop,
                    )
                )

    alerts.sort(key=lambda a: a.rank)
    return alerts


def adaptive_dedup_hours(
    recent_new_counts: list[int],
    base_hours: int,
    cfg: DrillAdaptive,
) -> int:
    """Adjust a keyword's dedup window from its recent drill productivity.

    Mirrors ``drill_adaptive``: a hot keyword (lots of new links) gets a shorter
    window so it is re-drilled sooner; a cold/stagnant one gets a longer window.
    Uses the last ``cfg.window_count`` samples. Returns ``base_hours`` unchanged
    when adaptive is disabled or there is no history.
    """
    if not cfg.enabled or not recent_new_counts:
        return base_hours

    sample = recent_new_counts[: cfg.window_count]
    avg = sum(sample) / len(sample)

    if avg >= cfg.hot_threshold:
        return max(1, base_hours // 2)
    if avg < cfg.cold_threshold:
        return base_hours * 2
    return base_hours
