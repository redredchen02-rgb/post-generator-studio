"""hotspot_sdk.hotspot — keyword ranking change detection + alerts."""
from __future__ import annotations

from .monitor import HotspotRanker
from .ranking import adaptive_dedup_hours, diff_rankings
from .scraper import JisouScraper, parse_leaderboard

__all__ = [
    "HotspotRanker",
    "diff_rankings",
    "adaptive_dedup_hours",
    "JisouScraper",
    "parse_leaderboard",
]
