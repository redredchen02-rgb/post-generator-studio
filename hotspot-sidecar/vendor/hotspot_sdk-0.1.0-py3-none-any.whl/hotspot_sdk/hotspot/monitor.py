"""Stateful hotspot ranker: feed it leaderboard snapshots, get alerts via the sink."""
from __future__ import annotations

from hotspot_sdk.adapters import OutputSink, RankingAlert, resolve_sink, safe_deliver
from hotspot_sdk.config import HotspotConfig, load_config

from .ranking import adaptive_dedup_hours, diff_rankings


class HotspotRanker:
    """Tracks the previous leaderboard in memory and surfaces ranking changes.

    Usage::

        ranker = HotspotRanker(config, sink=my_sink)
        alerts = await ranker.process_snapshot({"大杨嫂": 1, "foo": 12})

    State is per-instance and in-memory. Persisting snapshots/drill stats to sqlite
    (mirroring ``db.py``'s trending_keywords / drill_stats tables) is deferred —
    callers that need durability can wrap this and persist the returned alerts.
    """

    def __init__(
        self,
        config: HotspotConfig | dict | None = None,
        sink: OutputSink | None = None,
        *,
        alert_off_board: bool = False,
    ):
        self.config = config if isinstance(config, HotspotConfig) else load_config(config)
        self._sink = sink
        self._alert_off_board = alert_off_board  # alert keywords that fall off the board
        self._prev: dict[str, int] = {}
        self._primed = False  # has a baseline been established?

    async def process_snapshot(self, ranking: dict[str, int]) -> list[RankingAlert]:
        """Diff a new leaderboard against the previous one, deliver + return alerts.

        The very first snapshot only establishes a baseline and emits no alerts —
        otherwise startup (or a post-``reset()`` snapshot) would flood ~40 spurious
        ``new_entry`` alerts for the whole board. The original app avoided this by
        loading the previous board from its persistent db; this in-memory port primes
        explicitly instead. Callers that *want* the whole board reported on first run
        can pass a known prior board via :meth:`prime`.
        """
        if not self._primed:
            self._prev = dict(ranking)
            self._primed = True
            return []
        alerts = diff_rankings(
            self._prev,
            ranking,
            self.config.alert_thresholds,
            include_off_board=self._alert_off_board,
        )
        sink = resolve_sink(self._sink)
        for alert in alerts:
            await safe_deliver(sink, alert)
        self._prev = dict(ranking)
        return alerts

    def prime(self, ranking: dict[str, int]) -> None:
        """Seed the baseline (e.g. from a persisted board) without emitting alerts."""
        self._prev = dict(ranking)
        self._primed = True

    def reset(self) -> None:
        """Forget the baseline; the next snapshot re-primes and emits no alerts."""
        self._prev = {}
        self._primed = False

    def dedup_hours_for(self, keyword: str, recent_new_counts: list[int]) -> int:
        """Adaptive dedup window for a keyword given its recent drill productivity."""
        base = self.config.scrape.drill_dedup_hours
        return adaptive_dedup_hours(
            recent_new_counts, base, self.config.scrape.drill_adaptive
        )
