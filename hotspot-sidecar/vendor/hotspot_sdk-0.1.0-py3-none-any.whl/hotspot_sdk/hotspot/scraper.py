"""Hotspot leaderboard scraping — the *fetch* side of the hotspot capability.

The original app did not contain the jisou/极搜 leaderboard fetch (it lived in an
external launchd script), so this is a clean, honest reconstruction of the entry
point rather than recovered code:

    send a service word (极搜/热搜/...) to a leaderboard bot
        -> receive a ranked-list reply
        -> parse it into {keyword: rank}
        -> (optionally) feed it to a HotspotRanker for change alerts

Two parts, deliberately split so the logic is fully testable without a live account:

* :func:`parse_leaderboard` — PURE. Turns a bot's ranked-list text into ranks.
* :class:`JisouScraper` — orchestrates send+receive. The transport is INJECTABLE
  (``sender``), so tests pass recorded replies and production uses the vendored
  Telethon client. The default sender is documented as needing live verification
  against your specific bot.
"""
from __future__ import annotations

import re
from typing import Awaitable, Callable, Optional

from hotspot_sdk.adapters import OutputSink
from hotspot_sdk.config import HotspotConfig, load_config

from .monitor import HotspotRanker

# Leading rank markers we recognise: "1." "1、" "1)" "1．" "①..⑳" "🥇🥈🥉".
_CIRCLED = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳"
_MEDALS = {"🥇": 1, "🥈": 2, "🥉": 3}
_ARABIC_LINE = re.compile(r"^\s*(\d{1,2})\s*[.、)）．:：]\s*(.+?)\s*$")
_TRAILING_NOISE = re.compile(r"[\s\-—|·]*(?:🔥|📈|📉|\d[\d,.\sw万次播放阅读热度↑↓]*)\s*$")


def _clean_keyword(raw: str) -> str:
    """Strip trailing view-count / heat noise and surrounding markup from a title."""
    kw = raw.strip().strip("《》「」【】*_`").strip()
    kw = _TRAILING_NOISE.sub("", kw).strip()
    return kw


def parse_leaderboard(text: str, *, max_rank: int = 40) -> dict[str, int]:
    """Parse a bot's ranked-list reply into ``{keyword: 1-based rank}``.

    Handles the common Chinese-bot formats: ``1. kw`` / ``1、kw`` / ``1) kw`` /
    circled ``①kw`` / medal ``🥇 kw``. Explicit numeric ranks win; otherwise lines
    are numbered by order of appearance. Lines without a recognisable title are
    skipped. Returns at most ``max_rank`` entries, de-duplicated on first occurrence.

    This default targets typical jisou-style replies; if your bot's format differs,
    pass your own parser to :class:`JisouScraper` instead of tuning this.
    """
    ranking: dict[str, int] = {}
    implicit = 0
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        rank: Optional[int] = None
        keyword: Optional[str] = None

        m = _ARABIC_LINE.match(s)
        if m:
            rank = int(m.group(1))
            keyword = m.group(2)
        elif s[0] in _CIRCLED:
            rank = _CIRCLED.index(s[0]) + 1
            keyword = s[1:]
        elif s[0] in _MEDALS:
            rank = _MEDALS[s[0]]
            keyword = s[1:]

        if keyword is None:
            continue
        kw = _clean_keyword(keyword)
        if not kw:
            continue
        if rank is None:
            implicit += 1
            rank = implicit
        else:
            implicit = max(implicit, rank)
        if rank > max_rank or kw in ranking:
            continue
        ranking[kw] = rank
    return ranking


# A sender takes (bot, service_word) and returns the bot's raw reply text.
Sender = Callable[[str, str], Awaitable[str]]


class JisouScraper:
    """Fetch a leaderboard from a bot and turn it into rankings (+ optional alerts).

    Parameters
    ----------
    config: a :class:`HotspotConfig` (or anything ``load_config`` accepts).
    sink: where ranking alerts go when ``scrape`` is given a ranker.
    parser: leaderboard text -> ``{keyword: rank}`` (defaults to :func:`parse_leaderboard`).
    service_word: the word sent to trigger the leaderboard; defaults to the first of
        ``config.telegram.service_words``.
    """

    def __init__(
        self,
        config: HotspotConfig | dict | None = None,
        sink: Optional[OutputSink] = None,
        *,
        parser: Callable[[str], dict[str, int]] = parse_leaderboard,
        service_word: Optional[str] = None,
    ):
        self.config = config if isinstance(config, HotspotConfig) else load_config(config)
        self.sink = sink
        self.parser = parser
        words = self.config.telegram.service_words
        self.service_word = service_word or (words[0] if words else "极搜")

    async def fetch_ranking(self, bot: str, *, sender: Optional[Sender] = None) -> dict[str, int]:
        """Send the service word to ``bot``, parse the reply into rankings.

        ``sender`` is injectable: pass a coroutine ``(bot, word) -> reply_text`` to
        use any transport (or a recorded reply in tests). Without one, the vendored
        Telethon client is used (live; verify against your bot).
        """
        send = sender or self._default_sender
        text = await send(bot, self.service_word)
        return self.parser(text)

    async def scrape(
        self,
        bot: str,
        *,
        sender: Optional[Sender] = None,
        ranker: Optional[HotspotRanker] = None,
    ):
        """Fetch the leaderboard; if a ``ranker`` is given, diff it and return alerts.

        Returns the ranking dict when no ranker is supplied, else the alert list.
        """
        ranking = await self.fetch_ranking(bot, sender=sender)
        if ranker is None:
            return ranking
        return await ranker.process_snapshot(ranking)

    async def _default_sender(self, bot: str, word: str) -> str:
        """Live transport via the vendored Telethon client. Needs credentials.

        ⚠️ Reconstruction: the original jisou fetch was not in the app, so this
        send/receive shape (send word → take the newest incoming reply) is a sensible
        default that must be verified against your specific bot's behaviour. Override
        by passing ``sender=`` if your bot needs deep-link / callback interaction.
        """
        self.config.require_telegram()
        import tg_client  # bare import via the engine sys.path shim

        async with tg_client.make_client() as client:
            await client.send_message(bot, word)
            # Newest incoming message from the bot after our prompt.
            async for msg in client.iter_messages(bot, limit=5):
                if not getattr(msg, "out", False) and (msg.message or ""):
                    return msg.message
        return ""
