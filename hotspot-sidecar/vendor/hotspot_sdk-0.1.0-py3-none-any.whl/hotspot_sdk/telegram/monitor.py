"""Config-injected wrapper around the vendored group_monitor engine.

The engine reads everything from ``~/.openclaw/workspace/group-monitor/`` (via
``Path.home()``) and its Telethon credentials from ``TG_*`` env vars. Rather than
edit the byte-identical engine, this wrapper *bridges* the injected
:class:`~hotspot_sdk.config.HotspotConfig` into the environment the engine expects:

* redirects ``HOME`` to the caller-controlled ``data_dir`` so the engine's
  ``~/.openclaw`` tree lands under our directory, never the real home;
* sets ``TG_API_ID`` / ``TG_API_HASH`` / ``TG_SESSION_NAME`` from the config;
* pre-writes the engine ``config.json`` so the engine *loads* our values instead of
  writing its own defaults;
* installs an :class:`~hotspot_sdk.adapters.OutputSink` bridge on the engine's
  ``delivery`` seam so forwarded/recovered media is handed to the host as
  :class:`~hotspot_sdk.adapters.ForwardedMedia`.

⚠️ Process-local: the engine's ``delivery._SINK`` and the ``HOME`` redirect are
process-global mutations. Run a :class:`TelegramMonitor` inside the worker process
that owns the engine (matching the original ``tg_scan`` worker design); do not share
one across unrelated host code in the same process.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

from ..adapters import ForwardedMedia, OutputSink, resolve_sink, safe_deliver
from ..config import HotspotConfig, load_config
from . import _install_engine_aliases

_ENGINE_WORKSPACE_REL = ".openclaw/workspace/group-monitor"


class EngineConfigBridge:
    """Translate a :class:`HotspotConfig` into the engine's env + config.json.

    Kept as a separate object so the bridging is testable without a live client.
    """

    def __init__(self, config: HotspotConfig, engine_config: Optional[dict] = None):
        self.config = config
        self.engine_config = dict(engine_config or {})
        if config.data_dir:
            self.data_dir = Path(config.data_dir).expanduser()
        else:
            # Default to a private per-user dir, NOT a predictable name in shared /tmp
            # (which is world-readable and lets a local attacker pre-create/symlink it).
            self.data_dir = Path.home() / ".local" / "share" / "hotspot-sdk"
        self._saved_env: Optional[dict[str, Optional[str]]] = None

    # -- derived paths -----------------------------------------------------------
    @property
    def workspace(self) -> Path:
        return self.data_dir / _ENGINE_WORKSPACE_REL

    @property
    def config_path(self) -> Path:
        return self.workspace / "config.json"

    # -- bridging ----------------------------------------------------------------
    def build_config_dict(self) -> dict[str, Any]:
        """Merge SDK config (both engine config schemas share one json file)."""
        tg = self.config.telegram
        merged: dict[str, Any] = {
            # config.py (_Config) schema
            "push_chat_id": tg.push_chat_id,
            "push_chat_name": tg.push_chat_name,
            "push_chat_name_hint": tg.push_chat_name_hint,
            "alert_thresholds": self.config.alert_thresholds.model_dump(),
            "source_channels": list(tg.source_channels),
            "media_sample_posts_per_channel": self.config.media_sample_posts_per_channel,
            "scrape": self.config.scrape.model_dump(),
            "service_words": list(tg.service_words),
            "forward": self.config.forward.model_dump(),
        }
        # monitor_group schema extras (watched_channels, download_window, ...) come
        # from the caller since they are not modelled in the typed SDK config.
        merged.update(self.engine_config)
        return merged

    _ENV_KEYS = ("HOME", "TG_API_ID", "TG_API_HASH", "TG_SESSION_NAME")

    def apply(self) -> Path:
        """Write env + config.json so the engine boots against our values.

        Returns the engine config path. Idempotent. Records the prior values of the
        env vars it mutates (once) so :meth:`restore` can put them back — avoiding a
        permanent global ``HOME`` rewrite that would corrupt unrelated host code.
        """
        # Private dir/files: config.json is operational metadata (not credentials,
        # which only go to env) but the engine's sqlite/session also live here.
        self.workspace.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.data_dir, 0o700)
        except OSError:
            pass
        self.config_path.write_text(
            json.dumps(self.build_config_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        try:
            os.chmod(self.config_path, 0o600)
        except OSError:
            pass

        if self._saved_env is None:
            self._saved_env = {k: os.environ.get(k) for k in self._ENV_KEYS}

        # Redirect HOME so every Path.home() in the engine resolves under data_dir.
        os.environ["HOME"] = str(self.data_dir)

        tg = self.config.telegram
        if tg.api_id:
            os.environ["TG_API_ID"] = str(tg.api_id)
        if tg.api_hash:
            os.environ["TG_API_HASH"] = tg.api_hash
        if tg.session_path:
            os.environ["TG_SESSION_NAME"] = Path(tg.session_path).name
        return self.config_path

    def restore(self) -> None:
        """Undo the env mutations from :meth:`apply` (safe to call if never applied)."""
        if self._saved_env is None:
            return
        for k, v in self._saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        self._saved_env = None


class TelegramMonitor:
    """Embeddable entry point to the Telegram monitoring/forwarding engine.

    Parameters
    ----------
    config:
        A :class:`HotspotConfig` (or anything ``load_config`` accepts).
    sink:
        Where forwarded media is delivered. Defaults to a process/Collecting sink.
    engine_config:
        Engine-specific keys not modelled in the typed config — most importantly
        ``watched_channels`` (required for :meth:`run_once` to do anything) and
        ``download_window``. Merged verbatim into the engine config.json.
    """

    def __init__(
        self,
        config: HotspotConfig | dict | None = None,
        sink: Optional[OutputSink] = None,
        *,
        engine_config: Optional[dict] = None,
    ):
        self.config = config if isinstance(config, HotspotConfig) else load_config(config)
        self._sink = sink
        self.bridge = EngineConfigBridge(self.config, engine_config)
        self._set_up = False

    # -- setup -------------------------------------------------------------------
    def setup(self) -> None:
        """Bridge config into the env and install the delivery sink. Idempotent."""
        _install_engine_aliases()
        self.bridge.apply()
        self.config.require_telegram()
        self._install_sink()
        self._redirect_engine_paths()
        self._maybe_override_session_path()
        self._set_up = True

    def _redirect_engine_paths(self) -> None:
        """Point the engine's package-dir-relative writes under ``data_dir``.

        The HOME bridge already covers the engine's ``~/.openclaw`` paths, but several
        engine constants (sqlite DB, media/discussion caches, session lock) are
        resolved relative to the *installed package directory* — which is read-only in
        a normal pip install and would otherwise scatter state into site-packages.
        This mirrors the original app's ``tg_scan._redirect_engine_paths`` constant
        list. Defensive: only sets attributes that actually exist on the vendored
        modules, so it degrades safely if the engine evolves.
        """
        import importlib

        ws = self.bridge.workspace
        (ws / "sessions").mkdir(parents=True, exist_ok=True)
        db_path = str(ws / "messages.sqlite")
        # (module suffix, attribute, value) — types match the engine's originals
        # (DB_PATH is a str; cache/dir constants are Path).
        plan = [
            ("monitor_group", "DB_PATH", db_path),
            ("monitor_group", "DISCUSSION_CACHE", ws / "discussion"),
            ("forward_keyword", "DB_PATH", db_path),
            ("forward_keyword", "CACHE_DIR", ws / "media_cache"),
            ("forward_keyword", "_PROJECT_DIR", ws),
            ("fetch_discussion", "DB_PATH", db_path),
            ("fetch_discussion", "DOWNLOAD_DIR", ws / "discussion"),
            ("fetch_discussion", "_PROJECT_DIR", ws),
            ("session_lock", "LOCK_PATH", ws / "sessions" / ".session.lock"),
            ("session_lock", "YIELD_FLAG_PATH", ws / "sessions" / ".yield_request"),
        ]
        for suffix, attr, value in plan:
            try:
                mod = importlib.import_module(f"backend.vendor.group_monitor.{suffix}")
            except Exception:  # noqa: BLE001 - module may pull telethon; skip if absent
                continue
            if hasattr(mod, attr):
                setattr(mod, attr, value)

    def _install_sink(self) -> None:
        # Import via the SAME qualified path the engine uses → shared module identity,
        # so set_sink here is the set_sink the engine's landing points observe.
        from backend.vendor.group_monitor import delivery  # type: ignore

        sink = resolve_sink(self._sink)
        self._sink = sink

        async def _engine_sink(paths, caption, meta):
            item = ForwardedMedia(
                paths=list(paths),
                caption=caption or "",
                source_channel=str((meta or {}).get("channel") or ""),
                source_msg_id=int((meta or {}).get("src_msg_id") or 0),
                meta=dict(meta or {}),
            )
            return await safe_deliver(sink, item)

        delivery.set_sink(_engine_sink)

    def _maybe_override_session_path(self) -> None:
        import tg_client  # bare import via engine sys.path shim

        if self.config.telegram.session_path:
            tg_client.SESSION_PATH = str(
                Path(self.config.telegram.session_path).expanduser()
            )
        else:
            # Default the Telethon session under data_dir, never site-packages.
            tg_client.SESSION_PATH = str(self.bridge.workspace / "sessions" / "tg_monitor")

    # -- operations --------------------------------------------------------------
    async def run_once(self, *, dry_run: bool = False) -> None:
        """Run one engine monitor pass over the configured watched channels.

        Delegates to the vendored ``monitor_group.main()`` so the保命逻辑
        (session lock, dedup, protected-channel reupload fallback, FloodWait
        backoff, incidents summary) runs exactly as in the original app. Forwarded
        media is delivered through the configured sink.
        """
        if not self._set_up:
            self.setup()
        self.bridge.apply()  # (re)assert the env bridge for the duration of the pass
        import monitor_group  # bare import via engine sys.path shim

        old_argv = sys.argv
        sys.argv = ["monitor_group"] + (["--dry-run"] if dry_run else [])
        try:
            await monitor_group.main()
        finally:
            sys.argv = old_argv
            self.bridge.restore()  # don't leak HOME/TG_* into the host process

    async def forward_keyword(self, keyword: str, limit: Optional[int] = None) -> None:
        """Forward discovered content links for ``keyword`` to the push target.

        Delegates to the vendored ``forward_keyword.main()`` (protected channels
        auto-fallback to download+reupload). Results flow through the sink.
        """
        if not self._set_up:
            self.setup()
        self.bridge.apply()  # (re)assert the env bridge for the duration of the pass
        import forward_keyword  # bare import via engine sys.path shim

        argv = ["forward_keyword", keyword]
        if limit is not None:
            argv += ["--limit", str(limit)]
        old_argv = sys.argv
        sys.argv = argv
        try:
            await forward_keyword.main()
        finally:
            sys.argv = old_argv
            self.bridge.restore()  # don't leak HOME/TG_* into the host process
