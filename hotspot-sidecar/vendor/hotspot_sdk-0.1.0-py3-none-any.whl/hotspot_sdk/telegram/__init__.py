"""hotspot_sdk.telegram — Telegram monitoring / forwarding engine.

The engine (``_engine/``) is the group_monitor source vendored **byte-identical**
from the original app, so the保命逻辑 (session lock, dedup, protected-channel
download+reupload fallback, FloodWait handling) is preserved exactly. This package
only adds a thin, config-injected wrapper (:class:`TelegramMonitor`) and bridges the
engine's home-directory/env coupling so it can be embedded.

Importing this package is cheap and does NOT require ``telethon`` and does NOT touch
``~/.openclaw`` — the engine submodules (which import telethon and read config) are
imported lazily, only when you actually run a pass.
"""
from __future__ import annotations

import importlib
import sys
import types

# The vendored engine uses two import styles:
#   * bare      : ``import db``, ``from config import CFG``  (resolved via the
#                 vendored ``_engine/__init__.py`` sys.path shim)
#   * qualified : ``from backend.vendor.group_monitor import delivery``
# For the qualified style to resolve — and to point at the SAME module objects the
# wrapper manipulates — we alias the legacy package path onto the vendored engine.
_ALIAS_ROOT = "backend.vendor.group_monitor"


def _make_ns(name: str) -> types.ModuleType:
    mod = types.ModuleType(name)
    mod.__path__ = []  # namespace package; the real child is the aliased engine
    return mod


def _install_engine_aliases() -> None:
    """Make ``backend.vendor.group_monitor`` resolve to ``_engine`` (idempotent)."""
    if _ALIAS_ROOT in sys.modules:
        return
    engine = importlib.import_module(__name__ + "._engine")  # runs the sys.path shim
    backend = sys.modules.setdefault("backend", _make_ns("backend"))
    vendor = sys.modules.setdefault("backend.vendor", _make_ns("backend.vendor"))
    setattr(backend, "vendor", vendor)
    sys.modules[_ALIAS_ROOT] = engine  # share identity with _engine
    setattr(vendor, "group_monitor", engine)


# Install eagerly: pure sys.modules plumbing — no telethon, no config read, no writes.
_install_engine_aliases()


def __getattr__(name: str):
    # Lazy export so ``import hotspot_sdk.telegram`` stays telethon-free until used.
    if name in {"TelegramMonitor", "EngineConfigBridge"}:
        from .monitor import EngineConfigBridge, TelegramMonitor

        return {
            "TelegramMonitor": TelegramMonitor,
            "EngineConfigBridge": EngineConfigBridge,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["TelegramMonitor", "EngineConfigBridge"]
