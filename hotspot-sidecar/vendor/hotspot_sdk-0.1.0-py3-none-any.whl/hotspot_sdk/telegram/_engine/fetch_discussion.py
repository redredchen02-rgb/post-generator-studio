"""PoC: 拉 TG 頻道 post 底下 linked discussion group 的評論（含 media）。

TG 頻道 post 常在主體放 teaser，真 video/photo 在 linked discussion group。
用 GetDiscussionMessageRequest 不用 join group 也能拿評論。

Usage:
    fetch_discussion.py @channel_username <msg_id>
    fetch_discussion.py @channel_username <msg_id> --download    # 下載 media 到 data/discussion/
    fetch_discussion.py --batch-keyword 大杨嫂 --limit 5         # 對該詞的 top N content_links 掃一遍

輸出：有 media 的評論列表（id/date/text 前 100 字/media 類型），可選自動下載。
"""
import argparse
import asyncio
import os
import sqlite3
import sys
from pathlib import Path

from telethon.tl.functions.messages import GetDiscussionMessageRequest

import db
from config import CFG  # noqa: F401 — may be needed by future routing
from session_lock import enter_cooperative
from tg_client import make_client

_PROJECT_DIR = Path(__file__).resolve().parent
DB_PATH = str(_PROJECT_DIR / "data" / "messages.sqlite")
DOWNLOAD_DIR = _PROJECT_DIR / "data" / "discussion"

TEASER_PATTERNS = [
    "评论区", "評論區", "完整版", "完整视频", "完整視頻",
    "看评论", "看下方", "下方评论", "下方留言",
    "私信我", "进群看", "進群看", "加群看",
]


def is_teaser(text: str) -> list:
    """Return list of teaser patterns found in text (empty if none)."""
    if not text:
        return []
    return [p for p in TEASER_PATTERNS if p in text]


async def fetch_discussion_media(client, channel, post_id, max_comments=50, min_id=0):
    """Return dict with discussion metadata + list of comment messages (media-bearing ones).

    **min_id**: 用於增量 re-probe；傳入上次掃到的最大 comment msg_id，iter 只回更新的。
    回傳 `max_comment_id`（本次掃到的最大 comment msg_id，不論是否有 media），作為
    下次 re-probe 的 anchor。初次 probe 傳 min_id=0 即可。
    """
    # Probe first: does this post have any discussion linkage?
    try:
        post_msg = await client.get_messages(channel, ids=post_id)
    except Exception as e:
        return {"error": f"get_messages fail: {type(e).__name__}: {e}", "comments": [], "max_comment_id": min_id}

    if not post_msg:
        return {"error": "post not found (deleted?)", "comments": [], "max_comment_id": min_id}

    replies = getattr(post_msg, "replies", None)
    reply_count = getattr(replies, "replies", 0) if replies else 0
    if not replies or reply_count == 0:
        return {"error": f"no discussion linkage (replies={reply_count})", "comments": [], "max_comment_id": min_id}

    # Telethon shortcut: iter_messages(channel, reply_to=post_id) 自動處理 broadcast→linked group
    # 映射，bypass GetRepliesRequest 對 anchor msg_id 的限制（MsgIdInvalidError）
    comments = []
    max_comment_id = min_id
    try:
        async for reply in client.iter_messages(channel, reply_to=post_id, min_id=min_id, limit=max_comments):
            if reply.id > max_comment_id:
                max_comment_id = reply.id
            if not bool(reply.photo or reply.video or reply.document):
                continue
            _append_comment(comments, reply)
    except Exception as e:
        return {"error": f"iter_messages: {type(e).__name__}: {e}", "comments": [], "max_comment_id": min_id}

    return {
        "channel": str(getattr(channel, "username", channel)),
        "post_id": post_id,
        "discussion_group": None,
        "anchor_id": None,
        "total_media_comments": len(comments),
        "comments": comments,
        "max_comment_id": max_comment_id,
    }


def _append_comment(comments, reply):
    kind = "photo" if reply.photo else "video" if reply.video else "document"
    comments.append({
        "id": reply.id,
        "date": reply.date.isoformat() if reply.date else None,
        "text": (reply.text or "")[:100],
        "kind": kind,
        "grouped_id": reply.grouped_id,
        "file_size": getattr(getattr(reply, "file", None), "size", None),
        "raw_msg": reply,   # keep reference for download
    })


async def download_comment_media(client, discussion_peer, comment, out_dir, timeout=1800):
    """Download a single comment media with per-file timeout.

    Default timeout 1800s (30min) sized for free-tier accounts (no TG Premium)
    large-video downloads. Returns file path on success, None on timeout/error
    (caller filters None out).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    msg = comment["raw_msg"]
    dest_stem = out_dir / f"comment_{msg.id}_{comment['kind']}"
    existing = list(out_dir.glob(f"comment_{msg.id}_*"))
    if existing:
        return str(existing[0])
    try:
        path = await asyncio.wait_for(
            client.download_media(msg, file=str(dest_stem)),
            timeout=timeout,
        )
        return path
    except asyncio.TimeoutError:
        print(f"    ⏱️ download timeout comment/{msg.id} (>{timeout}s)")
        return None
    except Exception as e:
        print(f"    ❌ download fail comment/{msg.id}: {type(e).__name__}: {str(e)[:80]}")
        return None


def persist_discussion_rows(keyword, channel, post_id, comments, path_by_msg):
    """Write discussion_media table rows. path_by_msg maps comment.id → cached file path (or None)."""
    rows = []
    ch_str = channel.lstrip("@") if isinstance(channel, str) else str(channel)
    for c in comments:
        rows.append({
            "keyword": keyword,
            "parent_channel": ch_str,
            "parent_msg_id": post_id,
            "comment_msg_id": c["id"],
            "grouped_id": c.get("grouped_id"),
            "kind": c["kind"],
            "file_size": c.get("file_size"),
            "cached_path": path_by_msg.get(c["id"]),
            "text_preview": c.get("text", "")[:200],
        })
    db.save_discussion_media(DB_PATH, rows)


async def forward_discussion_to_target(client, channel, post_id, target, result, out_dir,
                                       keyword=None, reply_to_msg_id=None, is_reprobe=False):
    """Download all media-bearing comments + reupload to target chat (preserving albums).

    reply_to_msg_id: 主帖在 push chat 的 msg id，帶上後 header + 所有 album reply 到主帖
                     形成 thread 連線，跨 cycle reprobe 也回到原主帖。
    is_reprobe:      True 時 header 標「（續 +N）」識別這是延遲補抓，不是初次。
    """
    if not result["comments"]:
        return {"forwarded": 0, "groups": 0}

    # Group by grouped_id (album) so we can send together
    groups = {}
    for c in result["comments"]:
        key = c["grouped_id"] or f"single_{c['id']}"
        groups.setdefault(key, []).append(c)

    # disc_peer not needed — client.download_media(msg) 直接從 msg 物件下載，不 reference peer
    disc_peer = None

    forwarded = 0
    src_tag = f"{channel}/{post_id}"
    caption_prefix = f"💬 {src_tag} discussion"
    path_by_msg = {}

    # 2026-05-11 萊斯 spec: 取消獨立發 header 純文字訊息（無媒體預覽影響觀感），
    # 把標題文字併入第一組媒體的 caption。其餘 group 沿用 caption_prefix。
    total_items = len(result["comments"])
    if is_reprobe:
        header_text = f"💬 {src_tag} 評論區（續 +{total_items}）"
    else:
        header_text = f"💬 {src_tag} 評論區合集 · {total_items} 條"
    pending_header = header_text  # 第一個 group 消耗掉，後續為 None

    for gid, group in groups.items():
        # 2026-05-11 萊斯 spec: 全部走 download+upload+delete (DUD)，不再 native
        # forward（會帶「Forwarded from」標籤暴露來源 + 違背擬人化轉發語義）。
        # 原 native fast path 移除。
        paths = []
        for c in group:
            path = await download_comment_media(client, disc_peer, c, out_dir)
            path_by_msg[c["id"]] = path
            if path:
                paths.append(path)
            await asyncio.sleep(0.5)
        if not paths:
            continue
        # 第一組 media 的 caption 帶 header 前綴，後續組維持原 caption_prefix
        if pending_header:
            actual_caption = f"{pending_header}\n\n{caption_prefix}"
            pending_header = None
        else:
            actual_caption = caption_prefix
        # ── HotspotMonitor delivery seam（flag guard，保命零感知）──
        from backend.vendor.group_monitor import delivery as _hm_delivery
        if _hm_delivery.has_sink() and paths:
            # HotspotMonitor extension: pass grouped_id+reply_to for sink-side post grouping (CLAUDE.md #6 sanctioned narrow exception)
            _first_comment = group[0] if group else None
            _grp_id = getattr(_first_comment, "grouped_id", None) if _first_comment else None
            _rt = getattr(_first_comment, "reply_to", None) if _first_comment else None
            _reply_to_mid = getattr(_rt, "reply_to_msg_id", None) if _rt else None
            await _hm_delivery.deliver(
                list(paths), actual_caption,
                {"channel": channel, "src_msg_id": post_id, "kind": "discussion",
                 "grouped_id": _grp_id, "reply_to_msg_id": _reply_to_mid})
            forwarded += len(paths)
            continue
        # ── 原生 send_file（sink 未設＝live 行為不變）──
        try:
            if len(paths) > 1:
                await client.send_file(target, paths, album=True, caption=actual_caption,
                                       parse_mode="md", reply_to=reply_to_msg_id)
            else:
                await client.send_file(target, paths[0], caption=actual_caption,
                                       parse_mode="md", reply_to=reply_to_msg_id)
            forwarded += len(paths)
            print(f"    ✓ uploaded {len(paths)} items (group {gid}) [DUD]")
        except Exception as e:
            print(f"    ❌ upload fail ({gid}): {type(e).__name__}: {e}")
        finally:
            # DUD 即時清理（萊斯「上傳完進行刪除」要求）
            from pathlib import Path as _Path
            for p in paths:
                try:
                    _Path(p).unlink(missing_ok=True)
                except Exception:
                    pass
        await asyncio.sleep(2)

    persist_discussion_rows(keyword, channel, post_id, result["comments"], path_by_msg)
    return {"forwarded": forwarded, "groups": len(groups)}


async def resolve_target(client, target_spec):
    """Resolve target_spec (chat_id int, or name hint str) to input entity."""
    if isinstance(target_spec, int) or (isinstance(target_spec, str) and target_spec.lstrip("-").isdigit()):
        return int(target_spec)
    async for d in client.iter_dialogs(limit=200):
        if target_spec in (d.name or ""):
            return d.input_entity
    return None


async def _sweep_recent(client, hours: int, probe_limit: int, max_fetch: int):
    """Scan recent content_links not yet probed for discussion media, fetch teaser
    hits only. Save rows to discussion_media (no download, no forward) — lets
    run_cycle accumulate discussion content autonomously.
    """
    import time as _time
    from telethon.errors import FloodWaitError
    cutoff = int(_time.time()) - hours * 3600
    with sqlite3.connect(DB_PATH, timeout=30) as conn:
        rows = conn.execute(
            """SELECT cl.channel_username, cl.msg_id, cl.keyword
               FROM content_links cl
               LEFT JOIN discussion_media dm
                 ON cl.channel_username = dm.parent_channel AND cl.msg_id = dm.parent_msg_id
               WHERE cl.fetched_at >= ?
                 AND cl.channel_username != '' AND cl.msg_id IS NOT NULL
                 AND cl.channel_username NOT LIKE '+%'
                 AND dm.id IS NULL
               GROUP BY cl.channel_username, cl.msg_id
               ORDER BY cl.fetched_at DESC
               LIMIT ?""",
            (cutoff, probe_limit),
        ).fetchall()

    if not rows:
        print(f"sweep: no unprobed content_links in last {hours}h")
        return 0, 0

    print(f"sweep: {len(rows)} posts to probe, max-fetch={max_fetch}")
    by_channel = {}
    for ch, mid, kw in rows:
        by_channel.setdefault(ch, []).append((mid, kw))

    fetched = teasers = 0
    for channel, items in by_channel.items():
        if fetched >= max_fetch:
            break
        msg_ids = [mid for mid, _ in items]
        try:
            msgs = await client.get_messages(f"@{channel}", ids=msg_ids)
        except FloodWaitError as e:
            print(f"  FloodWait {e.seconds}s on get_messages — aborting sweep")
            break
        except Exception as e:
            print(f"  @{channel}: {type(e).__name__}: {str(e)[:80]}")
            continue

        for m, (mid, kw) in zip(msgs, items):
            if fetched >= max_fetch:
                break
            if m is None:
                continue
            text = m.text or ""
            teaser_hits = is_teaser(text)
            replies_n = getattr(getattr(m, "replies", None), "replies", 0) or 0
            if not (teaser_hits and replies_n > 0):
                continue
            teasers += 1
            try:
                r = await fetch_discussion_media(client, f"@{channel}", m.id, max_comments=30)
            except FloodWaitError as e:
                print(f"  FloodWait {e.seconds}s on discussion — aborting sweep")
                return fetched, teasers
            except Exception as e:
                print(f"  @{channel}/{m.id} discussion err: {type(e).__name__}")
                continue
            if r.get("error") or not r["comments"]:
                continue
            # Persist without downloading (saves bandwidth); discussion_media row
            # acts as an index others can dereference by `cached_path IS NULL` later.
            path_by_msg = {c["id"]: None for c in r["comments"]}
            persist_discussion_rows(kw, f"@{channel}", m.id, r["comments"], path_by_msg)
            fetched += 1
            print(f"  ✓ @{channel}/{m.id} ({kw}): +{len(r['comments'])} comments")
            await asyncio.sleep(2)
        await asyncio.sleep(1)

    return fetched, teasers


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("channel", nargs="?", help="@username or channel id")
    p.add_argument("msg_id", nargs="?", type=int, help="post msg id in channel")
    p.add_argument("--download", action="store_true", help="download media to data/discussion/")
    p.add_argument("--max-comments", type=int, default=50)
    p.add_argument("--batch-keyword", type=str, default=None,
                   help="Sweep top content_links for this keyword")
    p.add_argument("--limit", type=int, default=5, help="batch mode: max posts to inspect")
    p.add_argument("--forward-to", type=str, default=None,
                   help="Forward discussion media to target chat_id (e.g. -1001234567890) or name hint")
    p.add_argument("--sweep-recent", type=int, default=None, metavar="HOURS",
                   help="Autonomous mode: scan content_links from last N hours, "
                        "fetch discussion for teaser hits (no download/forward).")
    p.add_argument("--probe-limit", type=int, default=15,
                   help="sweep mode: max posts to get_messages probe")
    p.add_argument("--max-fetch", type=int, default=5,
                   help="sweep mode: max posts to call fetch_discussion on")
    args = p.parse_args()

    async with make_client() as client:
        if args.sweep_recent:
            fetched, teasers = await _sweep_recent(
                client, args.sweep_recent, args.probe_limit, args.max_fetch
            )
            print(f"sweep done: {fetched} discussion fetched (from {teasers} teaser hits)")
            return

        if args.batch_keyword:
            import sqlite3
            with sqlite3.connect(DB_PATH, timeout=30) as conn:
                rows = conn.execute(
                    """SELECT channel_username, msg_id FROM content_links
                       WHERE keyword=? AND channel_username != '' AND msg_id IS NOT NULL
                       GROUP BY channel_username, msg_id
                       LIMIT ?""",
                    (args.batch_keyword, args.limit),
                ).fetchall()
            if not rows:
                print(f"no content_links for「{args.batch_keyword}」")
                return
            print(f"Sweeping {len(rows)} posts for「{args.batch_keyword}」\n")
            for ch, mid in rows:
                print(f"--- @{ch} / msg {mid} ---")
                r = await fetch_discussion_media(client, f"@{ch}", mid, args.max_comments)
                if r.get("error"):
                    print(f"  ❌ {r['error']}\n")
                    continue
                print(f"  💬 discussion: {r['discussion_group']}  anchor={r['anchor_id']}")
                print(f"  {r['total_media_comments']} media-bearing comments")
                for c in r["comments"][:5]:
                    print(f"    • [{c['id']}] {c['kind']:5s} {c['date'][:19] if c['date'] else '?':19s}  {c['text'][:60]}")
                print()
                await asyncio.sleep(2)
            return

        if not args.channel or not args.msg_id:
            print("error: need <channel> <msg_id>  OR  --batch-keyword KW", file=sys.stderr)
            sys.exit(2)

        print(f"Fetching discussion for {args.channel} msg {args.msg_id}\n")
        r = await fetch_discussion_media(client, args.channel, args.msg_id, args.max_comments)
        if r.get("error"):
            print(f"❌ {r['error']}")
            return

        print(f"💬 Discussion: {r['discussion_group']}")
        print(f"   Anchor msg id in group: {r['anchor_id']}")
        print(f"   Media-bearing comments: {r['total_media_comments']}\n")
        for c in r["comments"]:
            size_kb = f" ({c['file_size']//1024}KB)" if c.get("file_size") else ""
            print(f"  • [msg {c['id']}] {c['kind']:8s}{size_kb}  {c['date'][:19] if c['date'] else '?'}")
            if c["text"]:
                print(f"      「{c['text']}」")

        out_dir = DOWNLOAD_DIR / f"{args.channel.lstrip('@')}_{args.msg_id}"

        if args.download and r["comments"]:
            print(f"\n⬇️  Downloading {len(r['comments'])} items to {out_dir}/")
            disc_peer = None  # not needed — download_media works off msg object directly
            path_by_msg = {}
            for c in r["comments"]:
                path = await download_comment_media(client, disc_peer, c, out_dir)
                path_by_msg[c["id"]] = path
                print(f"    ✓ {path}")
                await asyncio.sleep(1)
            persist_discussion_rows(args.batch_keyword, args.channel, args.msg_id, r["comments"], path_by_msg)
            print(f"    [DB] {len(r['comments'])} rows written to discussion_media table")

        if args.forward_to and r["comments"]:
            target = await resolve_target(client, args.forward_to)
            if target is None:
                print(f"❌ target not resolvable: {args.forward_to}")
                return
            print(f"\n📤 Forwarding {r['total_media_comments']} comment-media to {args.forward_to}")
            out = await forward_discussion_to_target(client, args.channel, args.msg_id, target, r, out_dir, keyword=args.batch_keyword)
            print(f"\n  Done. forwarded={out['forwarded']}, groups={out['groups']}")


if __name__ == "__main__":
    enter_cooperative("fetch_discussion.py", timeout=900)
    asyncio.run(main())
