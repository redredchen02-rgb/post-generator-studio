"""Delivery sink：把引擎「上傳去 TG 群」替換為「交給 HotspotMonitor 落地」。
模組級單例 flag。_SINK is None → 引擎走原生 send_file（live 行為不變）；
被 set_sink 注入 → Task 2.2 會在引擎 forward_keyword.send_post /
fetch_discussion.forward_discussion_to_target / fetch_bot_media.forward_bot_media_to_target
三個落地呼叫點插 guard 改呼叫 deliver()，不 send_file、不 unlink（檔案所有權移交 sink）。

⚠️ Process-local 邊界警告：_SINK 是 process-local 模組級狀態，只在呼叫 set_sink() 的那個進程內有效。
本設計下只允許在 --worker tg_scan 子進程內 set_sink()；主 FastAPI app 進程不得 import/設定本模組。

保命邏輯零感知。
"""
from __future__ import annotations
from typing import Awaitable, Callable, Optional, Sequence

# sink(paths, caption, meta) -> awaitable[dict]
Sink = Callable[[Sequence[str], str, dict], Awaitable[dict]]

_SINK: Optional[Sink] = None


def set_sink(fn: Sink) -> None:
    global _SINK
    _SINK = fn


def clear_sink() -> None:
    global _SINK
    _SINK = None


def has_sink() -> bool:
    return _SINK is not None


async def deliver(paths: Sequence[str], caption: str, meta: dict) -> dict:
    if _SINK is None:
        raise RuntimeError("delivery.deliver called with no sink set")
    return await _SINK(paths, caption, meta)
