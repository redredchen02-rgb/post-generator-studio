"""Group monitor: 2026-04-21 skill-B core.

Polls a list of watched TG channels / groups, forwards any new messages to
the target push chat (Protected channels auto-fallback to download+reupload
via forward_keyword.send_post). State persisted in workspace/group-monitor/.

Usage:
    monitor_group.py            # run one pass over watched_channels
    monitor_group.py --dry-run  # scan new msgs but do NOT forward

Cooperates with bot_scraper via session_lock.enter_cooperative: if bot_scraper
holds the session, we write a yield flag and wait up to 10 min.
"""
import argparse
import asyncio
import json
import logging
import os
import random
import re
import signal
import sys
import tempfile
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

from telethon.errors import ChatForwardsRestrictedError, FloodWaitError

import db
from fetch_discussion import is_teaser, fetch_discussion_media, forward_discussion_to_target
from fetch_bot_media import (
    parse_bot_deep_link,
    fetch_bot_media,
    fetch_via_comment_token,
    forward_bot_media_to_target,
    cleanup_bot_history,
    _download_resumable,            # [HotspotMonitor bot-teaser-resume patch]
    DOWNLOAD_REQUEST_SIZE,          # [HotspotMonitor bot-teaser-resume patch]
)
from telethon import utils as tl_utils  # [HotspotMonitor bot-teaser-resume patch] get_extension
from forward_keyword import parse_comment_token, strip_comment_token_tail
from session_lock import enter_cooperative
from tg_client import make_client, resolve_push_target

DISCUSSION_CACHE = Path(__file__).resolve().parent / "data" / "discussion"
DB_PATH = str(Path(__file__).resolve().parent / "data" / "messages.sqlite")

PROJECT_DIR = Path(__file__).resolve().parent
WORKSPACE = Path.home() / ".openclaw/workspace/group-monitor"
CONFIG_PATH = WORKSPACE / "config.json"
STATE_PATH = WORKSPACE / "state.json"
LOG_DIR = WORKSPACE / "logs"

OPEN_TEASER_MAX_AGE_S = 3600
OPEN_TEASER_STABLE_CLOSE = 5

DEFAULT_CONFIG = {
    "push_chat_id": 0,
    "push_chat_name_hint": "",
    "poll_interval_s": 120,
    "max_msgs_per_channel": 5,  # 2026-05-10 hardening: 20→5 (FrozenParticipant lesson)
    "max_size_mb": 2000,
    # 2026-05-11 dual-cursor DUD: scan 全天跑（30min 一輪），但 download
    # 只在 [start, end] 半開區間內執行；窗口外 media 訊息排到 pending_media 隊列，
    # 下次窗口 cycle 開頭 drain。純文字訊息不受窗口限制（下載壓力 0）。
    # null/[]/[0,24] = 不限制（向後兼容測試）。
    "download_window": [10, 20],
    # drain 隊列每 cycle 上限（避免 14h 累積後一次打爆）
    "drain_pending_max_per_cycle": 20,
    # incidents 匯總 push 目標：留 None 則 fallback 到 push_chat_id（向後相容）。
    # 萊斯之後若想分流（避免主 push 被噪音淹），把 chat_id 填進來即可。
    "incidents_chat_id": None,
    "incidents_chat_name_hint": "",
    "ad_filter": {
        "enabled": True,
        "exclude_words": [],       # 萊斯自訂補充關鍵字（累加在內建 PROMO_WORDS 之上）
        "allow_urls": [],          # 白名單 url substring（正常頻道互引用不被誤殺）
    },
    "watched_channels": [],
}


# ─── L1 廣告偵測（規則式）────────────────────────────────────
_URL_RE = re.compile(
    r"https?://|t\.me/[+\w]|\b\w+\.(com|cn|net|org|xyz|app|io|vip|top|cc|me|club|online|shop|live|pro|asia|biz|tw|hk)\b",
    re.I,
)
_EMOJI_SPAM_RE = re.compile(
    r"(😂|😀|😃|😄|💰|📲|📢|🔥|🎁|👉|✅|🌟|⭐|💥|👇|🎉){3,}"
)
_BOLD_RE = re.compile(r"\*\*([^*]+)\*\*")

PROMO_WORDS = [
    # 博彩 / 金流
    "官方", "永久", "指定", "网址", "網址", "投注", "平台", "娱乐城", "娛樂城",
    "博彩", "百家乐", "百家樂", "彩票", "棋牌", "充值", "下注",
    # 通用營銷
    "必备", "必備", "精准", "精準", "VIP", "代理", "招聘", "扫码", "掃碼",
    "限时", "限時", "优惠", "優惠", "免费", "免費", "注册", "註冊",
    "福利", "领取", "領取", "下载APP", "下載APP", "点击", "點擊",
    "教程", "教學",
    # 2026-05-12 補：博彩流水 / 邀請返水 / 客服類（@xingxuxijiaoyu/30258 漏防教訓）
    "首存", "流水", "彩金", "客服", "邀请人", "邀請人", "奖励", "獎勵",
    "返水", "返点", "返點", "提现", "提現", "存款", "送", "中奖", "中獎",
    "福利来袭", "福利來襲", "有效流水", "月流水", "首充", "充值返",
    "玩家", "介绍", "介紹", "申请", "申請",
]


_SANITIZE_URL_RE = re.compile(r"https?://|t\.me/[+\w]")


def sanitize_caption(text):
    """剝掉含 URL 的整行 + 收緊空行；常用於 caption_sanitize-eligible channel。

    起點：2026-05-06 萊斯點出 @bssp_gc 是「真內容+塞廣告 URL」混合（每條都是
    `**標題**\\n**爆射视频:****https://www.916691.xyz**` 格式）。原生 forward
    無法改 caption，要清洗必須走 re-upload。

    Strategy（最寬泛但最有效）：含 URL/邀請鏈接的整行 drop——合法標題不會在
    標題行內塞 URL；清洗後保留純標題。對沒 URL 的訊息透傳。

    Returns 清洗後字串（已 strip + 收緊空行）。空字串 caller 自行 fallback。
    """
    if not text:
        return ""
    lines = text.split("\n")
    kept = [l for l in lines if not _SANITIZE_URL_RE.search(l)]
    cleaned = "\n".join(l for l in kept if l.strip()).strip()
    return cleaned


def is_ad_like(text, extra_words=None, allow_urls=None):
    """規則式廣告偵測。Returns (is_ad: bool, reasons: list[str]).

    頂層設計：Rule 1-3 是**獨立定罪信號**（URL / 推廣詞 / emoji spam），任一
    命中即判為廣告。Rule 4 bold_heavy 只是**輔助加權證據**——單靠粗體不足以
    定罪，因為 #hashtag-heavy 的真吃瓜 post 也常整段粗體（2026-04-22 修：
    @chiguadama/13185 `#大邱庄 #大邱庄于淼` 因全部 hashtag 粗體被誤殺）。
    """
    text = text or ""
    reasons = []

    # Rule 1: URL / 邀請鏈接
    if _URL_RE.search(text):
        whitelisted = False
        if allow_urls:
            text_lower = text.lower()
            if any((u or "").lower() in text_lower for u in allow_urls):
                whitelisted = True
        if not whitelisted:
            reasons.append("url")

    # Rule 2: 推廣關鍵詞 ≥2 命中
    all_words = PROMO_WORDS + list(extra_words or [])
    hits = [w for w in all_words if w in text]
    if len(hits) >= 2:
        reasons.append(f"promo_words({','.join(hits[:3])})")

    # Rule 3: emoji 堆砌
    if _EMOJI_SPAM_RE.search(text):
        reasons.append("emoji_spam")

    # Rule 4: 粗體字占比 > 30% — **只作為輔助證據**，Rule 1-3 其一已命中才加
    # 單獨粗體不定罪（避免 hashtag-heavy 真內容誤殺）
    if reasons:
        bold_chars = sum(len(m) for m in _BOLD_RE.findall(text))
        if len(text) > 20 and bold_chars / len(text) > 0.3:
            reasons.append("bold_heavy")

    return bool(reasons), reasons
# ─────────────────────────────────────────────────────────────


def load_config():
    if not CONFIG_PATH.exists():
        WORKSPACE.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(json.dumps(DEFAULT_CONFIG, indent=2, ensure_ascii=False), encoding="utf-8")
    data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    # deep-merge missing defaults
    for k, v in DEFAULT_CONFIG.items():
        data.setdefault(k, v)
    return data


def load_state():
    if not STATE_PATH.exists():
        return {}
    try:
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(state):
    STATE_PATH.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


# ─── INCIDENTS 匯總機制 (P0-4) ────────────────────────────────
# Module-level list: 本 cycle 累積的非致命錯誤，main() 結束時匯總推 TG。
# 設計目標：FloodWait / forward err / discussion err / bot err 不再「印一行就消
# 失」，每輪 cycle 結束有一份結構化總結，可定位問題頻道與錯因分布。
# 同 process 多次 main() 調用（理論不會但保險）由 main() 入口 .clear() 兜底。
INCIDENTS = []

# [HotspotMonitor ban-detect patch] 口令群發送成功的 channel 集合
# 供 tg_scan.py run_once 讀取「recovered_channels」，讓禁言標記「粘」不 flicker。
# 本輪 main() 入口 .clear()；channel 格式 = normalize_channel 後的 @xxx。
CHANNEL_SEND_OK: set = set()

# 抑止 record_incident 內任何意外打斷主流程
_INCIDENT_MAX = 200  # 單 cycle 上限（防失控頻道把 list 衝爆記憶體）


def record_incident(kind, channel=None, msg="", extra=None):
    """記錄一條本輪 incident。純記憶體操作，O(1)，全包 try/except。

    kind 例: 'floodwait_forward' / 'forward_err' / 'discussion_fetch_err' /
             'bot_fetch_err' / 'reprobe_err' / 'scan_err' / 'target_resolve_err' …
    channel: '@xxx' 或 None
    msg: 1 行說明（typename + 關鍵數字，例如 'FloodWait 45s'）
    extra: 任意 dict，留作未來分析用
    """
    try:
        if len(INCIDENTS) >= _INCIDENT_MAX:
            return
        INCIDENTS.append({
            "kind": kind,
            "channel": channel,
            "msg": str(msg)[:200],
            "extra": extra or {},
            "ts": int(time.time()),
        })
    except Exception:
        # incident 自身爆了不能擾亂主流程
        pass
# ─────────────────────────────────────────────────────────────


_LOGGER = None


def _get_logger():
    """Lazy logger singleton.

    Uses RotatingFileHandler (5MB × 5 backup) on monitor.log to prevent
    unbounded growth. Lazy init so import-time mkdir side-effect stays
    minimal; called only on first log_line() within a process.

    launchd spawns a fresh Python every poll cycle, so handler累積/泄漏
    在跨進程模型下不存在。同一進程內以模組級單例避免重複 add_handler。
    """
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("group_monitor")
    logger.setLevel(logging.INFO)
    logger.propagate = False  # 避免冒泡到 root 造成重複輸出
    if not logger.handlers:
        handler = RotatingFileHandler(
            LOG_DIR / "monitor.log",
            maxBytes=5 * 1024 * 1024,  # 5 MB
            backupCount=5,
            encoding="utf-8",
        )
        handler.setFormatter(
            logging.Formatter("[%(asctime)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        )
        logger.addHandler(handler)
    _LOGGER = logger
    return logger


def log_line(msg):
    """Log to monitor.log (rotated) + stdout (launchd captures to launchd.out.log).

    Keeps the legacy `[ts] msg` visual format and dual-write behavior so
    既有的 watchdog tail / 萊斯眼球 tail 不破。輪替由 RotatingFileHandler
    控管（5MB × 5 backup）。
    """
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    _get_logger().info(msg)


def normalize_channel(ch):
    """Accept `@ch`, `ch`, `https://t.me/ch` → returns `@ch`."""
    s = ch.strip()
    # [HotspotMonitor by-id patch] 無 username 私有群用數字 chat_id 當 identifier
    if s.lstrip("-").isdigit():
        return s
    s = s.replace("https://t.me/", "").replace("http://t.me/", "")
    s = s.replace("t.me/", "")
    s = s.split("?")[0].split("/")[0]
    if not s.startswith("@"):
        s = "@" + s
    return s


def _chan_peer(ch):
    # [HotspotMonitor by-id patch] 數字 chat_id 字串轉 int peer 給 Telethon；@username 原樣
    if isinstance(ch, str) and ch.lstrip("-").isdigit():
        return int(ch)
    return ch


def apply_filter(msgs, include, exclude, mode, channel=None, ad_cfg=None, caption_sanitize=False):
    """mode ∈ {all, media_only, text_only}. include/exclude are keyword lists.

    **media_only** 的語義擴展：除了本體有 media 的 post，還包括 teaser post
    （含引流詞「評論區/完整版/私信我」+ replies>0）。這類 post 本體可能只是
    引流圖或純文字，真料在評論區，forward_group 會判斷走 discussion 路徑。

    **ad_cfg**: {enabled, exclude_words, allow_urls, block_documents}. 命中
    廣告規則時：跳過 + 寫 ad_samples DB + log 原因。

    **block_documents** (全局預設 True，零容忍)：純 document（非 video/photo）
    一律 skip。防 apk/exe/dmg/zip/rar/7z/ipa 等可執行/壓縮檔（2026-05-06 萊
    斯指示「什麼zip apk exe這種都不要下載，避免導致中電腦病毒」；起點是
    @xingxuxijiaoyu/30058 是 185MB .apk）。video/mp4 雖也用 Document 傳輸，
    但 m.video 會單獨命中——此規則只攔 m.document and not (m.video or m.photo)。
    """
    out = []
    ad_cfg = ad_cfg or {}
    ad_enabled = ad_cfg.get("enabled", False)
    ad_extra = ad_cfg.get("exclude_words", [])
    ad_allow = ad_cfg.get("allow_urls", [])
    block_documents = ad_cfg.get("block_documents", True)  # 預設 True 全局保護

    for m in msgs:
        text = m.text or ""
        has_media = bool(m.photo or m.video or m.document)
        replies_n = getattr(getattr(m, "replies", None), "replies", 0) or 0

        # block_documents: 純 doc（非 video/photo）直接攔——零容忍 apk/exe/zip
        if block_documents and m.document and not (m.video or m.photo):
            fname = ""
            for a in getattr(m.document, "attributes", []) or []:
                if hasattr(a, "file_name"):
                    fname = a.file_name
                    break
            mime = getattr(m.document, "mime_type", "")
            log_line(f"  🚫 doc skip {channel or '?'}/{m.id} mime={mime} fname={fname!r}")
            continue

        # 藍鏈白名單：蓝字 entity 指向 t.me/<bot>?start= 是合法 teaser anchor。
        # 但白名單只對「單一 url 原因」放行 — 真 teaser 命中 ad_filter 純因為 deep-link
        # 自帶 URL；如果同時命中 promo_words/bold_heavy，那就不是純 teaser 而是引流帖
        # （e.g. ntrqwq/1122 jisou 引流：text 含「必备/精准」+ deep-link，仍須杀）
        is_deep_link_teaser = parse_bot_deep_link(m) is not None

        # media_only 事實驅動：本體有 media 或有人留言（評論區可能藏料）才留；純文字無評論才 skip
        if mode == "media_only" and not has_media and replies_n == 0:
            continue
        if mode == "text_only" and has_media:
            continue
        if exclude and any(w in text for w in exclude):
            continue
        if include and not any(w in text for w in include):
            continue

        # L1 廣告偵測（最後一道過濾，前面 include/exclude 先走）
        if ad_enabled:
            is_ad, reasons = is_ad_like(text, ad_extra, ad_allow)
            if is_ad and is_deep_link_teaser and reasons == ["url"]:
                # 真 teaser 白名單例外：僅命中 url 單一原因放行
                is_ad = False
            # caption_sanitize 例外：「真內容+塞廣告 URL」channel（如 @bssp_gc 的
            # 「**標題**\n**爆射视频:****URL**」格式）。先嘗試清洗，清洗後若不再
            # 是 ad-like，附 _sanitize_caption 標記給下游 forward_group 走 re-upload
            # （native forward 改不了 caption，廣告會跟著轉走）
            if is_ad and caption_sanitize and "url" in reasons and has_media:
                cleaned = sanitize_caption(text)
                if cleaned:
                    still_ad, _ = is_ad_like(cleaned, ad_extra, ad_allow)
                    if not still_ad:
                        try:
                            setattr(m, "_sanitize_caption", cleaned)
                        except Exception:
                            pass
                        log_line(f"  🧼 sanitize {channel or '?'}/{m.id} → {cleaned[:60]!r}")
                        is_ad = False
            if is_ad:
                if channel:
                    try:
                        db.save_ad_sample(DB_PATH, channel, m.id, text, ",".join(reasons))
                    except Exception as e:
                        log_line(f"  ⚠️ ad_sample save fail: {type(e).__name__}")
                log_line(f"  🚫 ad skip {channel or '?'}/{m.id} reasons={reasons}")
                continue

        out.append(m)
    return out


def group_albums(msgs):
    """Group by grouped_id (TG album); singletons become 1-element groups."""
    groups = {}
    for m in msgs:
        key = m.grouped_id if m.grouped_id else ("solo", m.id)
        groups.setdefault(key, []).append(m)
    out = sorted(groups.values(), key=lambda g: min(m.id for m in g))
    return out


# telethon RPC timeout 護欄（hang sprint 2026-05-06）。10:39:28→10:56:20 那輪
# probe /30055 後黑屏 16min 被 launchd 540s 殺 = 唯一外部護欄。給 forward_messages
# / fetch_discussion_media / send_file 等裸 RPC 包 wait_for，hang lose 從 9min→單個
# RPC timeout，且能精準 log 是哪個 RPC 卡住。
RPC_TIMEOUT_FORWARD = 60.0          # native forward_messages
RPC_TIMEOUT_DISCUSSION = 120.0      # fetch_discussion_media（內部含 iter_messages）


def is_within_active_window(active_hours, now_hour=None):
    """active_hours = [start, end]（半開區間）；e.g. [10, 22] = 10:00 ~ 21:59。

    None / 空 list / 顯式 [0, 24] → 不限制（True）。

    起點：2026-05-06 萊斯指出 24/7 規律 cycle 是 TG 反 spam 紅燈（帳號 4/30
    frozen 推測有這個成分）；限定模擬人類員工工作時段，加大 user-like 側寫。

    2026-05-11 註：cycle-level skip 已從 main() 移除（被 download-window 取代）；
    此函式仍保留供 test_active_hours.py 與外部呼叫者使用。
    """
    if not active_hours:
        return True
    if len(active_hours) != 2:
        return True
    start_h, end_h = active_hours
    if start_h == 0 and end_h == 24:
        return True
    if now_hour is None:
        from datetime import datetime
        now_hour = datetime.now().hour
    return start_h <= now_hour < end_h


def msg_has_media(m):
    """單條訊息是否含可下載媒體。"""
    return bool(getattr(m, "photo", None) or getattr(m, "video", None)
                or getattr(m, "document", None))


def group_has_media(group):
    """album/single group 任一條含 media → True。一個 group 是處理單元，
    要嘛全 forward 要嘛全 enqueue（不能拆 album）。"""
    return any(msg_has_media(m) for m in group)


def is_within_download_window(window, now_hour=None):
    """window = [start, end]（半開區間）；e.g. [10, 20] = 10:00 ~ 19:59:59。

    語義跟 is_within_active_window 一樣（複用半開區間邏輯），但用途不同：
      · is_within_active_window → cycle-level（窗口外整個 cycle skip，已棄用）
      · is_within_download_window → media-level（窗口外 media 排隊，scan 仍跑）

    起點：2026-05-11 萊斯設計 dual-cursor DUD 架構（帳號凍結後復盤）。
    只 gate 下載+上傳行為，scan 與純文字 forward 不受限。
    """
    if not window:
        return True
    if len(window) != 2:
        return True
    start_h, end_h = window
    if start_h == 0 and end_h == 24:
        return True
    if now_hour is None:
        from datetime import datetime
        now_hour = datetime.now().hour
    return start_h <= now_hour < end_h


async def forward_group(client, target, channel, group, max_size_mb, forward_mode="all", force_reupload=False):
    """Forward msg group + optionally fetch discussion media for teaser posts.

    Behavior matrix (forward_mode='media_only'):
      本體有 media  → forward 本體
      本體無 media (teaser) → 跳過本體（純文字 or 引流圖不推）
      teaser + replies>0    → 額外抓 discussion，有 media 的評論一起 forward

    其他 mode 行為保留：'all' 無差別 forward、'text_only' 只純文字。

    Returns {main, discussion, replies_n, last_disc_id}. 後兩者供 caller 寫入
    open_teasers（用於日後 re-probe 補撈延遲上傳的媒體）。
    """
    group.sort(key=lambda m: m.id)
    first = group[0]

    main_n = 0
    anchor_msg_id = None  # 主帖 forward 後在 push chat 的第一條 msg id，用作 reply_to anchor

    # caption_sanitize 路由：apply_filter 已標記 _sanitize_caption 的訊息，必須
    # 走 send_post re-upload（native forward 帶不掉廣告 caption）。
    # force_reupload 是 channel 級 escape hatch（萊斯按 channel 顆粒度 escalate
    # hang 反覆復現的 channel 走 download-then-upload 路徑）。
    sanitize_caption_text = getattr(first, "_sanitize_caption", None)
    if sanitize_caption_text is not None or force_reupload:
        from forward_keyword import send_post
        # 2026-05-11 BUG FIX: drain queue 撈出的 msg 沒 _sanitize_caption 標記，
        # 若這裡 caption_override=None 又不傳 force_reupload=True，send_post 會走
        # native fast path 變回「轉傳自」標籤——萊斯截圖看到的就是這個 bug。
        # 兩條都傳，確保強制 DUD 不走 native。
        override = sanitize_caption_text  # 可能 None → send_post 從 m.text 抽
        path_label = "caption-sanitized" if sanitize_caption_text else "force-reupload"
        cached_paths = []
        try:
            try:
                _result, n, _skip = await send_post(
                    client, target, channel.lstrip("@"), group, max_size_mb,
                    caption_override=override,
                    return_cached_paths=cached_paths,
                    force_reupload=True,
                )
                main_n = n
                log_line(f"  🧼 reupload {channel}/{first.id} {path_label} n={n}")
            except FloodWaitError as e:
                log_line(f"  ⚠️ FloodWait {e.seconds}s on sanitize-reupload — abort group")
                record_incident("floodwait_forward", channel, f"FloodWait {e.seconds}s",
                                extra={"seconds": e.seconds, "msg_id": first.id, "path": "sanitize"})
                return {"main": 0, "discussion": 0, "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": None}
            except Exception as e:
                log_line(f"  ❌ sanitize-reupload err ({channel}/{first.id}): {type(e).__name__}: {e}")
                record_incident("forward_err", channel, f"{type(e).__name__}: {str(e)[:120]}",
                                extra={"msg_id": first.id, "path": "sanitize"})
                return {"main": 0, "discussion": 0, "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": None}
        finally:
            from pathlib import Path as _Path
            for p in cached_paths:
                try:
                    _Path(p).unlink(missing_ok=True)
                except Exception:
                    pass
        # sanitize 訊息屬於「真內容+塞廣告」channel，本體即內容；不抓 discussion
        return {"main": main_n, "discussion": 0, "replies_n": 0,
                "last_disc_id": 0, "anchor_msg_id": None}

    # 2026-05-11 萊斯設計：主帖一律走 DUD（download+upload+delete），不再 native forward。
    # 純文字（無 media）group 也走 send_post，內部 cached_paths 為空，等同零成本。
    # try/finally 確保 cache 即時清空（萊斯「上傳完進行刪除」需求）。
    from forward_keyword import send_post
    cached_paths = []
    try:
        try:
            _result, n, _skip = await asyncio.wait_for(
                send_post(
                    client, target, channel.lstrip("@"), group, max_size_mb,
                    return_cached_paths=cached_paths,
                    force_reupload=True,
                ),
                timeout=RPC_TIMEOUT_FORWARD + 180.0,  # +180s for download/upload overhead
            )
            main_n = n
            # send_post DUD 路徑沒回 anchor msg id；reprobe reply_to 設 None 是 OK
            # 的，P0 header 仍帶 source。
            anchor_msg_id = None
        except asyncio.TimeoutError:
            log_line(f"  ⏱️ DUD send_post timeout {channel}/{first.id}")
            record_incident("rpc_timeout", channel,
                            f"DUD send_post >{RPC_TIMEOUT_FORWARD + 180.0:.0f}s",
                            extra={"msg_id": first.id, "rpc": "send_post"})
            return {"main": 0, "discussion": 0, "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": None}
        except FloodWaitError as e:
            log_line(f"  ⚠️ FloodWait {e.seconds}s on DUD — abort group")
            record_incident("floodwait_forward", channel, f"FloodWait {e.seconds}s",
                            extra={"seconds": e.seconds, "msg_id": first.id})
            return {"main": 0, "discussion": 0, "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": None}
        except Exception as e:
            log_line(f"  ❌ DUD err ({channel}/{first.id}): {type(e).__name__}: {e}")
            record_incident("forward_err", channel, f"{type(e).__name__}: {str(e)[:120]}",
                            extra={"msg_id": first.id})
            return {"main": 0, "discussion": 0, "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": None}
    finally:
        # DUD 即時清理本地 cache，無論成功失敗（失敗時 cleanup.py 1d TTL 兜底）
        from pathlib import Path as _Path
        for p in cached_paths:
            try:
                _Path(p).unlink(missing_ok=True)
            except Exception:
                pass

    # 藍鏈分支：teaser entities 含 bot deep-link → bot 私信取媒體。
    # [HotspotMonitor bot-teaser-resume patch] 不再 inline fetch+下載——一帖 bot teaser
    # 常是 15~23 個大影片，inline 下載塞爆單一 scan cycle → 超 1800s 子進程 timeout 被殺 →
    # 游標不前進 → 下輪從頭重下同一帖，永遠跑不完、整條監控死鎖（2026-06-04 實證根因）。
    # 改：掃描端只「解析 deep-link + 入 pending_bot_teaser 佇列」秒過，bot-media 下載交給
    # drain_bot_teaser_queue 跨 cycle 續傳（.partial）+ 全下完一次性 sink 投遞（exactly-once）。
    deep_link = parse_bot_deep_link(first)
    if deep_link:
        bot_username, token = deep_link
        try:
            _cap = (getattr(first, "message", None) or "")[:900].strip() or None
        except Exception:
            _cap = None
        db.enqueue_bot_teaser(
            DB_PATH, channel, first.id, bot_username, token,
            target_chat_id=0,  # sink-mode：本地落地不需 TG target（欄位保留供未來 TG send）
            caption=_cap, anchor_msg_id=anchor_msg_id,
        )
        log_line(f"  🔗 {channel}/{first.id} bot deep-link @{bot_username} → 入續傳佇列"
                 f"（async drain，不阻塞掃描）")
        return {"main": main_n, "discussion": 0,
                "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": anchor_msg_id}

    # 2026-05-15「评论区口令型」teaser（吃瓜大妈 @chiguadama 为典范）：
    # caption 含「评论区发送口令：`<token>` 获取视频」→ 走 fetch_via_comment_token
    # 自动在 disc 发 token、解析 bot reply 中 deep-link、复用 fetch_bot_media 拉资源。
    # 必须放在蓝链分支之后、Discussion probe 之前——蓝链优先级最高，口令次之，最后兜底 disc。
    comment_token = parse_comment_token(first)
    if comment_token:
        bot_n = 0
        log_line(f"  🎫 {channel}/{first.id} comment_token: {comment_token!r}")
        try:
            ctoken_result = await fetch_via_comment_token(
                client, channel, first.id, comment_token,
            )
        except Exception as e:
            log_line(f"  🎫 {channel}/{first.id} fetch_via_comment_token crashed: "
                     f"{type(e).__name__}: {e}")
            record_incident("ctoken_fetch_err", channel,
                            f"{type(e).__name__}: {str(e)[:120]}",
                            extra={"msg_id": first.id, "token": comment_token})
            ctoken_result = {"media": [], "ads": [], "error": str(e),
                             "bot_username": None, "token_hash": None,
                             "bot_entity": None}

        if ctoken_result.get("banned"):
            # [HotspotMonitor ban-detect patch] 帳號在此口令群被禁言，記錄 incident 供上層持久化
            log_line(f"  🚫 {channel}/{first.id} 帳號在此群被禁言，無法發送口令")
            record_incident("channel_banned", channel,
                            ctoken_result.get("error", "帳號在此群被禁言"),
                            extra={"msg_id": first.id, "token": comment_token})
            return {"main": main_n, "discussion": 0,
                    "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": anchor_msg_id,
                    "banned": True}
        # [HotspotMonitor ban-detect patch] end
        if ctoken_result.get("error"):
            log_line(f"  🎫 {channel}/{first.id} ctoken err: {ctoken_result['error']}")
        else:
            # [HotspotMonitor ban-detect patch] 口令發送成功 → 記錄 channel_send_ok
            # 讓 tg_scan.py 收集 recovered_channels，清除曾有的禁言標記
            try:
                CHANNEL_SEND_OK.add(channel if isinstance(channel, str) else str(channel))
            except Exception:
                pass
            n_media = len(ctoken_result.get("media", []))
            n_ads = len(ctoken_result.get("ads", []))
            log_line(f"  🎫 {channel}/{first.id} ctoken bot=@{ctoken_result.get('bot_username')} "
                     f"hash={ctoken_result.get('token_hash')} → {n_media} media, {n_ads} ads filtered")
            if n_media > 0:
                try:
                    post_cap = strip_comment_token_tail(
                        getattr(first, "raw_text", None) or getattr(first, "message", "") or ""
                    )
                    out = await forward_bot_media_to_target(
                        client, target, channel, first.id, ctoken_result,
                        ctoken_result["bot_username"], ctoken_result["token_hash"],
                        reply_to_msg_id=anchor_msg_id, is_reprobe=False,
                        post_caption=post_cap,
                    )
                    bot_n = out.get("forwarded", 0)
                    if bot_n:
                        log_line(f"  🎫 {channel}/{first.id} +{bot_n} 口令 media ({out.get('groups', 0)} groups)")
                except Exception as e:
                    log_line(f"  🎫 {channel}/{first.id} ctoken forward err: {type(e).__name__}: {e}")
                    record_incident("ctoken_forward_err", channel,
                                    f"{type(e).__name__}: {str(e)[:120]}",
                                    extra={"msg_id": first.id,
                                           "bot": ctoken_result.get("bot_username")})

            if ctoken_result.get("bot_entity"):
                await cleanup_bot_history(client, ctoken_result["bot_entity"])

        return {"main": main_n, "discussion": bot_n,
                "replies_n": 0, "last_disc_id": 0, "anchor_msg_id": anchor_msg_id}

    # Discussion probe：有人留言就 probe，fetch_discussion_media 內部自己 filter 有 media 的 reply
    disc_n = 0
    last_disc_id = 0
    replies_n = getattr(getattr(first, "replies", None), "replies", 0) or 0
    if replies_n > 0:
        try:
            r = await asyncio.wait_for(
                fetch_discussion_media(
                    client, channel, first.id,
                    max_comments=min(max(replies_n + 20, 50), 200),
                ),
                timeout=RPC_TIMEOUT_DISCUSSION,
            )
        except asyncio.TimeoutError:
            log_line(f"  ⏱️ fetch_discussion timeout {channel}/{first.id} (>{RPC_TIMEOUT_DISCUSSION:.0f}s)")
            record_incident("rpc_timeout", channel,
                            f"fetch_discussion_media >{RPC_TIMEOUT_DISCUSSION:.0f}s",
                            extra={"msg_id": first.id, "rpc": "fetch_discussion_media"})
            r = {"error": "timeout", "comments": [], "max_comment_id": 0}
        except Exception as e:
            log_line(f"  💬 {channel}/{first.id} discussion fetch err: {type(e).__name__}")
            record_incident("discussion_fetch_err", channel,
                            f"{type(e).__name__}: {str(e)[:120]}",
                            extra={"msg_id": first.id})
            r = {"error": str(e), "comments": [], "max_comment_id": 0}
        media_count = len(r.get("comments", []))
        last_disc_id = r.get("max_comment_id", 0)
        log_line(f"  💬 probe {channel}/{first.id} replies={replies_n} media_found={media_count}")
        if not r.get("error") and r.get("comments"):
            cache_dir = DISCUSSION_CACHE / f"{channel.lstrip('@')}_{first.id}"
            try:
                out = await forward_discussion_to_target(
                    client, channel, first.id, target, r, cache_dir, keyword=None,
                    reply_to_msg_id=anchor_msg_id, is_reprobe=False,
                )
                disc_n = out.get("forwarded", 0)
                if disc_n:
                    log_line(f"  💬 {channel}/{first.id} +{disc_n} discussion media ({out.get('groups', 0)} groups)")
            except Exception as e:
                log_line(f"  💬 {channel}/{first.id} discussion forward err: {type(e).__name__}")
                record_incident("discussion_forward_err", channel,
                                f"{type(e).__name__}: {str(e)[:120]}",
                                extra={"msg_id": first.id})

    return {"main": main_n, "discussion": disc_n, "replies_n": replies_n,
            "last_disc_id": last_disc_id, "anchor_msg_id": anchor_msg_id}


async def reprobe_open_teasers(client, ch, target, open_teasers):
    """Re-probe previously seen teaser posts to catch delayed discussion uploads.

    吃瓜 content 上傳順序：先發主帖 → 再上評論區媒體（間隔數秒到數十分鐘）。
    monitor_one_channel 首輪看到 post 時 replies 可能為 0 或僅部分，之後新增
    的評論不會被 iter_messages(min_id=last_seen_id) 重新掃到。這個函式專門回
    頭 check 所有未關閉的 teaser，用 min_id=last_disc_msg_id 拿增量。

    關閉條件任一：
      · age > OPEN_TEASER_MAX_AGE_S (1h 硬兜底；吃瓜上傳通常當下完成)
      · stable_cycles >= OPEN_TEASER_STABLE_CLOSE (連續 5 cycle 無新增 = 10min 穩定)
      · post 被刪

    Mutates open_teasers dict in-place. Returns count of newly forwarded media.
    """
    if not open_teasers:
        return 0

    now = int(time.time())
    post_ids = [int(pid) for pid in open_teasers.keys()]

    # Batch fetch 一次抓所有 open teaser 的最新 replies count（單 RPC）
    try:
        post_msgs = await client.get_messages(_chan_peer(ch), ids=post_ids)  # [by-id]
    except FloodWaitError as e:
        log_line(f"  ⚠️ {ch} reprobe FloodWait {e.seconds}s — skip this cycle")
        record_incident("floodwait_reprobe", ch, f"FloodWait {e.seconds}s",
                        extra={"seconds": e.seconds})
        return 0
    except Exception as e:
        log_line(f"  ⚠️ {ch} reprobe get_messages fail: {type(e).__name__}")
        record_incident("reprobe_err", ch, f"{type(e).__name__}: {str(e)[:120]}")
        return 0

    if not isinstance(post_msgs, list):
        post_msgs = [post_msgs]

    to_close = []
    added = 0
    for pid, post_msg in zip(post_ids, post_msgs):
        pid_str = str(pid)
        entry = open_teasers[pid_str]

        if now - entry.get("first_seen_ts", now) > OPEN_TEASER_MAX_AGE_S:
            to_close.append((pid_str, "aged-out"))
            continue
        if post_msg is None:
            to_close.append((pid_str, "post-deleted"))
            continue

        current_replies = getattr(getattr(post_msg, "replies", None), "replies", 0) or 0
        if current_replies > entry.get("last_reply_count", 0):
            delta = current_replies - entry["last_reply_count"]
            try:
                r = await fetch_discussion_media(
                    client, ch, pid,
                    max_comments=min(max(delta + 20, 50), 200),
                    min_id=entry.get("last_disc_msg_id", 0),
                )
            except Exception as e:
                log_line(f"  💬 reprobe {ch}/{pid} fetch err: {type(e).__name__}")
                record_incident("reprobe_disc_fetch_err", ch,
                                f"{type(e).__name__}: {str(e)[:120]}",
                                extra={"msg_id": pid})
                entry["stable_cycles"] = entry.get("stable_cycles", 0) + 1
                continue

            media_count = len(r.get("comments", []))
            log_line(f"  💬 reprobe {ch}/{pid}: replies {entry['last_reply_count']}→{current_replies}, +{media_count} media")

            if not r.get("error") and r.get("comments"):
                cache_dir = DISCUSSION_CACHE / f"{ch.lstrip('@')}_{pid}"
                try:
                    out = await forward_discussion_to_target(
                        client, ch, pid, target, r, cache_dir, keyword=None,
                        reply_to_msg_id=entry.get("anchor_msg_id"), is_reprobe=True,
                    )
                    added += out.get("forwarded", 0)
                except Exception as e:
                    log_line(f"  💬 reprobe {ch}/{pid} forward err: {type(e).__name__}")
                    record_incident("reprobe_disc_forward_err", ch,
                                    f"{type(e).__name__}: {str(e)[:120]}",
                                    extra={"msg_id": pid})

            entry["last_reply_count"] = current_replies
            entry["last_disc_msg_id"] = max(entry.get("last_disc_msg_id", 0), r.get("max_comment_id", 0))
            entry["stable_cycles"] = 0
        else:
            entry["stable_cycles"] = entry.get("stable_cycles", 0) + 1
            if entry["stable_cycles"] >= OPEN_TEASER_STABLE_CLOSE:
                to_close.append((pid_str, f"stable-{entry['stable_cycles']}"))

        await asyncio.sleep(1)

    for pid_str, reason in to_close:
        log_line(f"  🔒 close open_teaser {ch}/{pid_str} ({reason})")
        open_teasers.pop(pid_str, None)

    return added


async def monitor_one_channel(client, target, target_chat_id, watched, state, cfg, dry_run=False):
    """雙游標 + window-gated DUD 主邏輯。

    target_chat_id: raw int chat id（給 enqueue_pending 寫 DB 用，不是 InputPeer object）
    state[ch] 雙游標 schema:
      · last_seen_id      → scan cursor: iter_messages 完成即推到 max_id
      · delivered_seen_id → deliver cursor: 每個 group 成功 deliver/enqueue 後推進
                            （null/缺失時 fallback to last_seen_id 兼容舊 state）
    """
    ch_raw = watched["channel"]
    ch = normalize_channel(ch_raw)
    if not watched.get("enabled", True):
        return (ch, 0, 0, "disabled")

    ch_state = state.get(ch, {})
    open_teasers = dict(ch_state.get("open_teasers", {}))
    last_seen = ch_state.get("last_seen_id", 0)
    # delivered_seen 雙游標：舊 state 沒這欄位 → 取 last_seen_id 視為「過去都已 deliver」
    delivered_seen = ch_state.get("delivered_seen_id", last_seen)

    # Phase 1: re-probe 現存 open teasers（補撈延遲上傳的評論媒體）
    reprobe_added = 0
    if open_teasers and not dry_run:
        reprobe_added = await reprobe_open_teasers(client, ch, target, open_teasers)

    # Phase 2: 掃新 post
    try:
        new_msgs = []
        async for m in client.iter_messages(_chan_peer(ch), min_id=last_seen, limit=cfg["max_msgs_per_channel"]):  # [by-id]
            new_msgs.append(m)
    except FloodWaitError as e:
        log_line(f"  ⚠️ {ch} FloodWait {e.seconds}s — skip this cycle")
        record_incident("floodwait_scan", ch, f"FloodWait {e.seconds}s",
                        extra={"seconds": e.seconds})
        state[ch] = {**ch_state, "open_teasers": open_teasers, "last_check_ts": int(time.time()),
                     "forwarded_total": ch_state.get("forwarded_total", 0) + reprobe_added,
                     "delivered_seen_id": delivered_seen}
        return (ch, 0, reprobe_added, "floodwait")
    except Exception as e:
        log_line(f"  ❌ {ch} fetch fail: {type(e).__name__}: {str(e)[:120]}")
        record_incident("scan_err", ch, f"{type(e).__name__}: {str(e)[:120]}")
        state[ch] = {**ch_state, "open_teasers": open_teasers, "last_check_ts": int(time.time()),
                     "forwarded_total": ch_state.get("forwarded_total", 0) + reprobe_added,
                     "delivered_seen_id": delivered_seen}
        return (ch, 0, reprobe_added, f"err:{type(e).__name__}")

    if not new_msgs:
        state[ch] = {
            "last_seen_id": last_seen,
            "delivered_seen_id": delivered_seen,
            "last_check_ts": int(time.time()),
            "forwarded_total": ch_state.get("forwarded_total", 0) + reprobe_added,
            "open_teasers": open_teasers,
        }
        return (ch, 0, reprobe_added, "no-new")

    new_msgs.sort(key=lambda m: m.id)
    max_id = new_msgs[-1].id

    filtered = apply_filter(
        new_msgs,
        watched.get("filter_include", []),
        watched.get("filter_exclude", []),
        watched.get("forward_mode", "all"),
        channel=ch,
        ad_cfg=cfg.get("ad_filter", {}),
        caption_sanitize=watched.get("caption_sanitize", False),
    )

    log_line(f"  📥 {ch}: +{len(new_msgs)} new (after filter: {len(filtered)})")

    # 雙游標語義：被 filter 過濾掉的訊息明確不處理 = 算 delivered
    # （否則 media_only 模式下純文字 post 會永久卡 scan/delivered gap）
    filtered_ids = {m.id for m in filtered}
    skipped_ids = [m.id for m in new_msgs if m.id not in filtered_ids]
    if skipped_ids:
        delivered_seen = max(delivered_seen, max(skipped_ids))

    # window 判斷：每個 channel 進來時 re-evaluate（cycle 短不會跨邊界但邏輯獨立）
    window_open = is_within_download_window(cfg.get("download_window"))

    forwarded = 0
    enqueued_n = 0
    if filtered and not dry_run:
        mode = watched.get("forward_mode", "all")
        force_reupload = watched.get("force_reupload", False)
        for group in group_albums(filtered):
            group_max_id = max(m.id for m in group)
            has_m = group_has_media(group)
            grouped_id = getattr(group[0], "grouped_id", None)

            # 窗口外 + 含 media → 排隊不下載
            if has_m and not window_open:
                try:
                    for m in group:
                        db.enqueue_pending(
                            DB_PATH, ch, m.id,
                            target_chat_id=target_chat_id,
                            forward_mode=mode,
                            grouped_id=grouped_id,
                        )
                    enqueued_n += len(group)
                    delivered_seen = max(delivered_seen, group_max_id)
                    log_line(f"  📥→📦 {ch}/{group[0].id} +{len(group)} enqueued (out of window)")
                except Exception as e:
                    log_line(f"  ❌ enqueue fail {ch}/{group[0].id}: {type(e).__name__}: {e}")
                    record_incident("enqueue_err", ch, f"{type(e).__name__}: {str(e)[:120]}",
                                    extra={"msg_id": group[0].id})
                    # enqueue fail → delivered_seen 不推進，下個 cycle 重新掃
                continue

            # 窗口內含 media，或純文字（無 media）→ 直接 forward
            r = await forward_group(
                client, target, ch, group, cfg["max_size_mb"], mode,
                force_reupload=force_reupload,
            )
            forwarded += r["main"] + r["discussion"]

            if r.get("main", 0) > 0:
                # forward 成功 → 推進 delivered cursor
                delivered_seen = max(delivered_seen, group_max_id)
            elif has_m:
                # forward fail + 有 media → enqueue 重試（drain queue 接手）
                try:
                    for m in group:
                        db.enqueue_pending(
                            DB_PATH, ch, m.id,
                            target_chat_id=target_chat_id,
                            forward_mode=mode,
                            grouped_id=grouped_id,
                        )
                    enqueued_n += len(group)
                    delivered_seen = max(delivered_seen, group_max_id)
                    log_line(f"  📥→📦 {ch}/{group[0].id} +{len(group)} enqueued (forward retry)")
                except Exception as e:
                    log_line(f"  ❌ retry-enqueue fail {ch}/{group[0].id}: {type(e).__name__}: {e}")
            else:
                # 純文字 forward fail → 接受 loss（無 media 重試成本/收益不對等）
                # delivered_seen 仍推進（避免下次重複嘗試同一條）
                delivered_seen = max(delivered_seen, group_max_id)

            # 本體 media 成功 forward 或當下已有 replies → 進 open_teasers 池
            # 底層邏輯：吃瓜/NSFW 主帖剛發時 replies 常為 0，評論區 media 會後續湧入；
            # 若只在 replies>0 才進池，monitor 120s 週期通常撞到 replies=0 → 永遠漏抓
            if r.get("main", 0) > 0 or r.get("replies_n", 0) > 0:
                first_id = group[0].id
                open_teasers[str(first_id)] = {
                    "first_seen_ts": int(time.time()),
                    "last_reply_count": r.get("replies_n", 0),
                    "last_disc_msg_id": r.get("last_disc_id", 0),
                    "stable_cycles": 0,
                    "anchor_msg_id": r.get("anchor_msg_id"),  # 主帖在 push chat 的 msg id，給 reprobe reply_to 用
                }

            await asyncio.sleep(1.5)

    state[ch] = {
        "last_seen_id": max_id,
        "delivered_seen_id": delivered_seen,
        "last_check_ts": int(time.time()),
        "forwarded_total": ch_state.get("forwarded_total", 0) + forwarded + reprobe_added,
        "open_teasers": open_teasers,
    }
    status = "ok"
    if enqueued_n:
        status = f"ok+enq{enqueued_n}"
    return (ch, len(new_msgs), forwarded + reprobe_added, status)


async def drain_pending_queue(client, cfg, default_target, max_items=20):
    """窗口內 cycle 開頭呼叫：從 pending_media 撈最舊 N 條，逐條 DUD。

    成功 → mark_pending_done (DB 刪行)
    失敗 → mark_pending_fail (attempts++, 達 5 次標 dead)
    成功推進 delivered_seen_id 由 caller 在 monitor_one_channel 處理（drain 不碰 state.json）

    返回 (drained_n, success_n, fail_n)。
    """
    rows = db.drain_next_pending(DB_PATH, limit=max_items)
    if not rows:
        return (0, 0, 0)

    log_line(f"📦 drain_pending: {len(rows)} item(s) to retry")
    success_n = fail_n = 0

    # 預解析 per-category targets 一次（drain 跨 channel）
    targets_by_chat_id = {cfg["push_chat_id"]: default_target}
    for cat, spec in cfg.get("push_targets", {}).items():
        cid = spec.get("chat_id")
        if cid and cid not in targets_by_chat_id:
            try:
                t, _, _ = await resolve_push_target(client, cid, spec.get("name_hint", ""))
                targets_by_chat_id[cid] = t
            except Exception:
                pass  # fallback 到 default_target

    # 2026-05-15 album 聚合：原邏輯 row-by-row 把同 album 的兄弟拆散單發，
    # 導致 caption holder（album 第一條）和其他純 video 子訊息分別上傳，
    # 子訊息抽不到 m.text → caption 只剩 📎 原帖尾綴。
    # 修法：按 (channel, grouped_id) 聚合 rows，整 album 一次 forward_group，
    # 同 grouped_id 的 pending rows 一起 mark_done。solo（grouped_id is None）
    # 走原 single-msg 路徑不變。
    pending_groups = {}  # key = (ch, grouped_id) | (ch, "solo", msg_id) → [rows]
    for r in rows:
        if r.get("grouped_id"):
            key = (r["channel"], r["grouped_id"])
        else:
            key = (r["channel"], "solo", r["msg_id"])
        pending_groups.setdefault(key, []).append(r)

    for key, group_rows in pending_groups.items():
        ch = group_rows[0]["channel"]
        msg_ids = sorted([r["msg_id"] for r in group_rows])
        target = targets_by_chat_id.get(group_rows[0]["target_chat_id"], default_target)
        is_album = len(key) == 2  # (ch, grouped_id)
        label = f"{ch}/{msg_ids[0]}" + (f" +{len(msg_ids)-1} album" if is_album and len(msg_ids) > 1 else "")
        try:
            msgs = await client.get_messages(_chan_peer(ch), ids=msg_ids)  # [by-id]
            # get_messages with list 回 list；None 代表已删
            live_msgs = [m for m in msgs if m is not None]
            if not live_msgs:
                for r in group_rows:
                    db.mark_pending_done(DB_PATH, r["id"])
                log_line(f"  📦 {label} ghost (deleted) → done")
                continue
            live_msgs.sort(key=lambda m: m.id)

            r = await forward_group(
                client, target, ch, live_msgs, cfg["max_size_mb"],
                group_rows[0].get("forward_mode") or "all",
                force_reupload=True,
            )
            if r.get("main", 0) > 0:
                for row in group_rows:
                    db.mark_pending_done(DB_PATH, row["id"])
                success_n += len(group_rows)
                log_line(f"  📦→✅ {label} drained")
            else:
                for row in group_rows:
                    db.mark_pending_fail(DB_PATH, row["id"], "forward_group returned 0")
                fail_n += len(group_rows)
        except FloodWaitError as e:
            # [vendorPatchNote gm-4] FloodWait 是純限流(transient)，不是內容壞掉。
            # 原本走 mark_pending_fail → attempts++ → 達 _PENDING_DEAD_THRESHOLD(5)
            # 被永久標 dead 丟棄；單帳號~1MB/s 跨國大影片連續限流時會誤殺好帖。
            # 修法：FloodWait 不 attempts++、不入 dead 判定——row 原樣留在佇列
            # （dead=0，FIFO enqueued_at 不變），下個 cycle 退避後續傳。
            # 不呼叫 db.mark_pending_fail（db.py 本輪不分配給本單元，無「不增
            # attempts」介面，故直接跳過 mark 達成不累計），改記 incident 留審計。
            record_incident("pending_drain_floodwait", ch, f"FloodWait {e.seconds}s",
                            extra={"msg_ids": msg_ids, "seconds": e.seconds})
            log_line(f"  📦 FloodWait {e.seconds}s on {label} — abort drain（限流不計 attempts）")
            break  # 整個 drain 中斷，避免連環 FloodWait
        except Exception as e:
            for row in group_rows:
                db.mark_pending_fail(DB_PATH, row["id"], f"{type(e).__name__}: {e}")
            fail_n += len(group_rows)
            log_line(f"  📦 drain err {label}: {type(e).__name__}: {e}")
        await asyncio.sleep(2.0)  # 比正常 forward 間隔長，drain 更保守

    log_line(f"📦 drain done: {success_n} ok, {fail_n} fail")
    return (len(rows), success_n, fail_n)


# ─── [HotspotMonitor bot-teaser-resume patch] 大檔 bot-media 下載慢車道 ──────────
# big-lane Phase D 適配 HM local-sink：bot teaser（一帖 15~23 個大影片）不再 inline
# 下載塞爆單一 scan cycle，而是入 pending_bot_teaser 佇列，由此 drain 跨 cycle 續傳，
# 全部下好才一次性 sink 投遞（exactly-once，避開 sink url 去重把後半丟掉）。
BOT_DL_BUDGET_S = int(os.environ.get("HOTSPOT_BOT_DL_BUDGET_S", "600"))
# 並發下載路數：追上舊 inline 碼的吞吐（人類 TG client 本就 4 並發 chunk），
# 避免串行龜速跟不上發帖。與續傳不衝突——gather 內每個 `_download_resumable` 各管自己的 .partial。
BOT_DL_CONCURRENCY = int(os.environ.get("HOTSPOT_BOT_DL_CONCURRENCY", "4"))
_BOT_CACHE_DIR = Path(tempfile.gettempdir()) / "hm_botmedia"


async def drain_bot_teaser_queue(client, cfg, default_target, max_teasers=1):
    """每 cycle 處理最老 max_teasers 帖 pending_bot_teaser（預設 1 帖/cycle）。

    兩階段（D→deliver）：
      1. 重 fetch media list（telethon 物件不可跨 process 持久，必重抓 /start）。
      2. 下「未下完」media：budget 內、`.partial` 斷點續傳、單檔 stall timeout。
      3. 全部非 oversize media 都下好 → 一次性 sink 投遞 → mark done；否則存進度留下輪續。

    回 (processed_teasers, delivered_media)。
    """
    teasers = db.drain_next_bot_teaser(DB_PATH, limit=max_teasers)
    if not teasers:
        return (0, 0)
    _BOT_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    delivered_total = 0

    for t in teasers:
        ch, post_id = t["channel"], t["post_id"]
        bot_username, token = t["bot_username"], t["token"]
        try:
            downloaded_ids = set(json.loads(t.get("delivered_ids") or "[]"))
        except (json.JSONDecodeError, TypeError):
            downloaded_ids = set()

        # 1. 重 fetch（FloodWait → 退避中止整 drain；其他 err → 該帖 attempts++）
        try:
            bot_result = await fetch_bot_media(client, bot_username, token)
        except FloodWaitError as e:
            # [vendorPatchNote gm-4] FloodWait 是純限流(transient)，不是內容壞掉。
            # 原本走 mark_bot_teaser_fail → attempts++ → 達 BIG_TEASER_DEAD_THRESHOLD(8)
            # 被永久標 dead；大帖(15~23 大影片)跨國連續限流時誤殺，與 big-lane
            # 「大帖跨多 cycle 屬正常、避免誤殺」初衷相違。
            # 修法：FloodWait 不 attempts++、不入 dead 判定——teaser row 原樣留佇列
            # （dead=0，delivered_ids 進度不變），下個 cycle 退避後續抓。
            # 不呼叫 db.mark_bot_teaser_fail（db.py 本輪不分配，無「不增 attempts」
            # 介面，故直接跳過 mark 達成不累計），仍記 incident 留審計。
            log_line(f"  🚛 bot-teaser {ch}/{post_id} fetch FloodWait {e.seconds}s — 退避中止 drain（限流不計 attempts）")
            record_incident("bot_teaser_floodwait", ch, f"FloodWait {e.seconds}s",
                            extra={"msg_id": post_id, "seconds": e.seconds})
            return (1, delivered_total)
        except Exception as e:
            log_line(f"  🚛 bot-teaser {ch}/{post_id} fetch err: {type(e).__name__}: {e}")
            db.mark_bot_teaser_fail(DB_PATH, t["id"], f"{type(e).__name__}: {str(e)[:120]}")
            continue

        if bot_result.get("error"):
            db.mark_bot_teaser_fail(DB_PATH, t["id"], f"fetch err: {str(bot_result['error'])[:120]}")
            continue
        media = bot_result.get("media", [])
        if not media:
            log_line(f"  🚛 bot-teaser {ch}/{post_id} 重抓 0 media → mark done")
            db.mark_bot_teaser_done(DB_PATH, t["id"])
            if bot_result.get("bot_entity"):
                try:
                    await cleanup_bot_history(client, bot_result["bot_entity"])
                except Exception:
                    pass
            continue

        # 2. 下未下完的：並發 BOT_DL_CONCURRENCY 路、budget 內、單檔 .partial 續傳
        deadline = time.monotonic() + BOT_DL_BUDGET_S
        max_size_mb = cfg.get("max_size_mb", 4096)
        path_by_id = {}
        non_oversize_ids = []
        to_download = []  # (m, stem, ext, size_bytes)
        for m in media:
            doc = getattr(m, "document", None)
            size_mb = (doc.size / 1024 / 1024) if (doc and doc.size) else 0
            if size_mb > max_size_mb:
                continue  # oversize 不算 done 判定（引擎本就跳過、列 token 手動自取）
            non_oversize_ids.append(m.id)
            stem = _BOT_CACHE_DIR / f"{ch.lstrip('@')}_{post_id}_{m.id}"
            try:
                ext = tl_utils.get_extension(m.media) or ""
            except Exception:
                ext = ""
            final = stem.parent / f"{stem.name}{ext}"
            if m.id in downloaded_ids and final.exists():
                path_by_id[m.id] = str(final)  # 之前 cycle 下好的 cache-hit
                continue
            to_download.append((m, stem, ext, doc.size if doc else 0))

        sem = asyncio.Semaphore(BOT_DL_CONCURRENCY)

        async def _dl_task(m, stem, ext, sz):
            async with sem:
                if time.monotonic() >= deadline:
                    return (m.id, None)  # budget 用盡 → 跳過本輪，.partial 下輪續
                p = await _download_resumable(
                    client, m, stem, ext=ext, total_size=sz, req_size=DOWNLOAD_REQUEST_SIZE)
                return (m.id, p)

        if to_download:
            results = await asyncio.gather(
                *[_dl_task(_m, _stem, _ext, _sz) for (_m, _stem, _ext, _sz) in to_download],
                return_exceptions=True)
            for r in results:
                if isinstance(r, asyncio.CancelledError):
                    raise r  # SIGTERM → 傳播（.partial 已由 _download_resumable 保留）
                if isinstance(r, BaseException):
                    continue  # 單檔例外（內部已記 log）→ 跳過，下輪續
                mid, p = r
                if p:
                    path_by_id[mid] = p
                    downloaded_ids.add(mid)

        # 3. 持久化進度
        db.update_bot_teaser_delivered(DB_PATH, t["id"], list(downloaded_ids))

        # 4. 全下完 → 一次性 sink 投遞（exactly-once）
        done_n = sum(1 for mid in non_oversize_ids if mid in downloaded_ids)
        all_done = bool(non_oversize_ids) and done_n == len(non_oversize_ids)
        if all_done:
            ordered = [path_by_id[m.id] for m in media if m.id in path_by_id]
            caption = t.get("caption") or f"📎 原帖 {ch}/{post_id}"
            from backend.vendor.group_monitor import delivery as _hm_delivery
            # [vendorPatchNote gm-3] 清檔的 finally 提到 all_done 分支頂層：
            # 本帖一旦進 all_done 即會 mark_bot_teaser_done 結案、永不再被 drain，
            # 故無論 has_sink 與否（no-sink 是合法狀態：sink 只在 tg_scan worker 設）
            # 或 ordered 是否空，已落地 _BOT_CACHE_DIR 的完成檔都得在此清掉，
            # 否則檔案無人 unlink 永久遺留。原碼把 unlink 巢狀包進
            # `if has_sink() and ordered:` 內，no-sink/空 ordered 路徑直接漏清。
            try:
                if _hm_delivery.has_sink() and ordered:
                    await _hm_delivery.deliver(
                        list(ordered), caption,
                        {"channel": ch, "src_msg_id": post_id, "kind": "bot_media",
                         "grouped_id": None, "reply_to_msg_id": t.get("anchor_msg_id")})
                    delivered_total += len(ordered)
                    log_line(f"  🚛→✅ bot-teaser {ch}/{post_id} 全 {len(ordered)} media 續傳完成、送達")
            finally:
                for p in ordered:
                    try:
                        Path(p).unlink(missing_ok=True)
                    except Exception:
                        pass
            db.mark_bot_teaser_done(DB_PATH, t["id"])
        elif not non_oversize_ids:
            # 全 media 都 oversize（>max_size_mb）或無可下載 media → 無本地可落地內容。
            # 不能落「下輪續傳」分支：那會讓本帖 attempts 永不增、dead 永標不上，每 cycle
            # 重 fetch_bot_media（重發 /start RPC）成永久殭屍帖。視為結案 mark done。
            log_line(f"  🚛 bot-teaser {ch}/{post_id} 全 {len(media)} media 皆 oversize/無可落地 → 結案 mark done")
            db.mark_bot_teaser_done(DB_PATH, t["id"])
        else:
            log_line(f"  🚛 bot-teaser {ch}/{post_id} 進度 {done_n}/{len(non_oversize_ids)} media（下輪續傳）")

        if bot_result.get("bot_entity"):
            try:
                await cleanup_bot_history(client, bot_result["bot_entity"])
            except Exception:
                pass

    return (len(teasers), delivered_total)


async def push_incidents_summary(client, cfg, default_target):
    """匯總 INCIDENTS 推到 incidents_chat（fallback default_target）。

    設計：
      · N == 0 → 只寫 log，不打擾 TG
      · N > 0  → format 訊息推 TG；resolve 失敗 fallback default_target
      · 全包 try/except，**任何錯誤不擾亂主流程**（萊斯紅線）
      · 不用 backtick 包 @username（萊斯踩坑：backtick 包 @handle 會變 monospace 不可點）
    """
    try:
        n = len(INCIDENTS)
        if n == 0:
            log_line("本輪 incidents: 0 條")
            return

        # aggregate by kind
        by_kind = {}
        for inc in INCIDENTS:
            by_kind.setdefault(inc["kind"], []).append(inc)

        # 2026-05-11 萊斯要求告警全中文，不夾英文 kind
        KIND_ZH = {
            "scan_err": "掃描頻道失敗",
            "floodwait_scan": "掃描被 Telegram 限速",
            "rpc_timeout": "通訊逾時",
            "floodwait_forward": "上傳被 Telegram 限速",
            "forward_err": "推送失敗",
            "target_resolve_err": "目的地群找不到",
            "drain_err": "重試隊列異常",
            "enqueue_err": "排隊失敗",
            "bot_fetch_err": "藍鏈機器人取媒體失敗",
            "bot_forward_err": "藍鏈媒體推送失敗",
            "reprobe_err": "回頭補抓失敗",
            "reprobe_disc_fetch_err": "回頭補抓評論失敗",
            "floodwait_reprobe": "回頭補抓被限速",
            "channel_banned": "帳號被禁言",  # [HotspotMonitor ban-detect patch]
        }
        lines = [f"📊 本輪監控發現 {n} 個小問題"]
        for kind in sorted(by_kind.keys()):
            items = by_kind[kind]
            name_zh = KIND_ZH.get(kind, kind)
            lines.append(f"· {name_zh}：{len(items)} 次")
        # 取前 3 條 sample（按時序）做明細
        lines.append("")
        lines.append("詳細：")
        for inc in INCIDENTS[:3]:
            ch = inc.get("channel") or "-"
            name_zh = KIND_ZH.get(inc["kind"], inc["kind"])
            # 注意：@username 不可包 backtick（會變 monospace 不可點）
            lines.append(f"  [{name_zh}] {ch} — {inc['msg']}")
        if n > 3:
            lines.append(f"  …（其餘 {n - 3} 條請看主程序日誌）")

        text = "\n".join(lines)
        log_line(f"本輪 incidents: {n} 條 — by_kind={ {k: len(v) for k, v in by_kind.items()} }")

        # resolve incidents target；缺值或失敗都 fallback default_target
        inc_chat_id = cfg.get("incidents_chat_id")
        inc_hint = cfg.get("incidents_chat_name_hint") or ""
        target = default_target
        if inc_chat_id:
            try:
                target, name, _ = await resolve_push_target(client, inc_chat_id, inc_hint)
                log_line(f"incidents target: {name!r}")
            except Exception as e:
                log_line(f"incidents target resolve fail → fallback default ({type(e).__name__}: {e})")
                target = default_target

        try:
            await client.send_message(target, text, link_preview=False)
        except Exception as e:
            log_line(f"incidents push fail: {type(e).__name__}: {e}")
    except Exception as e:
        # 兜底：summary 自身爆了也不能讓 cycle 死掉
        try:
            log_line(f"push_incidents_summary outer fail: {type(e).__name__}: {e}")
        except Exception:
            pass


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dry-run", action="store_true", help="scan but do not forward")
    args = p.parse_args()

    # 跨 main() 重入隔離（同 process 多次調用的保險；launchd 模式每次新 process 已不需要）
    INCIDENTS.clear()
    CHANNEL_SEND_OK.clear()  # [HotspotMonitor ban-detect patch]

    cfg = load_config()
    state = load_state()
    watched = cfg.get("watched_channels", [])
    if not watched:
        log_line("no watched_channels in config — nothing to do")
        return

    # 2026-05-11 起 active_hours cycle-level skip 已棄用（被 download_window
    # media-level gate 取代）；此處保留 advisory log 提示舊配置仍存在。
    legacy_active_hours = cfg.get("active_hours")
    if legacy_active_hours:
        log_line(f"⚠️ legacy 'active_hours'={legacy_active_hours} ignored — "
                 f"now using 'download_window' (media-level gate)")

    download_window = cfg.get("download_window")
    in_window = is_within_download_window(download_window) if download_window else True
    log_line(f"download_window={download_window} now_in_window={in_window}")

    enabled_n = sum(1 for w in watched if w.get("enabled", True))
    log_line(f"monitor start: {enabled_n}/{len(watched)} channel(s) enabled" + (" [DRY]" if args.dry_run else ""))

    # SIGTERM/SIGINT → 不直接砍 process（會跳過 Telethon disconnect，留 Telegram
    # session 熱著導致下輪重連被判 misuse → database is locked 螺旋），而是 set
    # 一個 Event，下面只取消 inner cycle task，主 task 不取消，讓 async with 的
    # __aexit__（Telethon disconnect()）在健康 loop 內依序跑完。
    loop = asyncio.get_running_loop()
    _shutdown = asyncio.Event()
    for _sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(_sig, _shutdown.set)
        except (NotImplementedError, ValueError):
            pass

    async with make_client() as client:
        async def _cycle():
            default_target, default_name, _ = await resolve_push_target(client, cfg["push_chat_id"], cfg["push_chat_name_hint"])
            log_line(f"target (default): {default_name!r}")

            # Per-category routing: 每個 category 可指定自己的 push target，fallback 到 default
            targets_by_cat = {}
            for cat, spec in cfg.get("push_targets", {}).items():
                try:
                    t, name, _ = await resolve_push_target(client, spec["chat_id"], spec.get("name_hint", ""))
                    targets_by_cat[cat] = t
                    log_line(f"target [{cat}]: {name!r}")
                except Exception as e:
                    log_line(f"target [{cat}] resolve fail: {type(e).__name__}: {e}")
                    record_incident("target_resolve_err", None,
                                    f"category={cat} {type(e).__name__}: {str(e)[:120]}",
                                    extra={"category": cat})

            # 窗口內 cycle 開頭 drain pending queue（窗口外的歷史 media 在這裡還清舊賬）
            if in_window and not args.dry_run:
                try:
                    await drain_pending_queue(
                        client, cfg, default_target,
                        max_items=cfg.get("drain_pending_max_per_cycle", 20),
                    )
                except Exception as e:
                    log_line(f"⚠️ drain_pending_queue crashed: {type(e).__name__}: {e}")
                    record_incident("drain_err", None, f"{type(e).__name__}: {str(e)[:120]}")

                # [HotspotMonitor bot-teaser-resume patch] 大檔 bot-media 慢車道 drain：
                # 每 cycle 續傳一帖 pending_bot_teaser，與掃描解耦、不阻塞 cycle。
                try:
                    await drain_bot_teaser_queue(client, cfg, default_target)
                except Exception as e:
                    log_line(f"⚠️ drain_bot_teaser_queue crashed: {type(e).__name__}: {e}")
                    record_incident("drain_err", None, f"bot_teaser: {type(e).__name__}: {str(e)[:120]}")

            # per-channel category target chat_id 反查（給 monitor_one_channel enqueue 用）
            cat_to_chat_id = {cat: spec["chat_id"]
                              for cat, spec in cfg.get("push_targets", {}).items()
                              if spec.get("chat_id")}

            _new = _fwd = 0
            for i, w in enumerate(watched):
                if i > 0:
                    await asyncio.sleep(1)
                t = targets_by_cat.get(w.get("category"), default_target)
                target_chat_id = cat_to_chat_id.get(w.get("category"), cfg["push_chat_id"])
                ch, n_new, n_fwd, status = await monitor_one_channel(
                    client, t, target_chat_id, w, state, cfg, dry_run=args.dry_run
                )
                _new += n_new
                _fwd += n_fwd

            # client 還活著時 push 匯總（避免重新拿 session lock；不阻塞主流程）
            await push_incidents_summary(client, cfg, default_target)
            return _new, _fwd

        work = asyncio.ensure_future(_cycle())
        stopper = asyncio.ensure_future(_shutdown.wait())
        done, _pending = await asyncio.wait(
            {work, stopper}, return_when=asyncio.FIRST_COMPLETED
        )
        if not stopper.done():
            stopper.cancel()
        if work in done:
            total_new, total_fwd = work.result()
        else:
            log_line("⚠️ SIGTERM 收到 — 中止本輪，Telethon 將乾淨斷線（釋放 Telegram session）")
            work.cancel()
            try:
                await work
            except asyncio.CancelledError:
                pass
            total_new = total_fwd = -1
    # 離開 async with → Telethon __aexit__/disconnect()：先停 keepalive 再
    # _save_states_and_entities()，無並發 task 搶同一 session conn → 不再 locked

    save_state(state)
    if total_new < 0:
        log_line("monitor aborted by SIGTERM — state saved（DUD pending/游標保留，下輪續跑）")
    else:
        log_line(f"monitor done: total new={total_new}, forwarded={total_fwd}")


def _apply_startup_jitter(min_s: float = 60.0, max_s: float = 180.0) -> float:
    """Sleep a random delay before this cycle starts. Scatters the launchd
    cron-aligned burst so successive forwards don't show a regular cadence
    that TG spam detection picks up.

    Hardening lineage:
      2026-04-30 帳號凍結 → first jitter 5-60s
      2026-05-10 FrozenParticipant → 60-180s + StartInterval 5min→15min"""
    delay = random.uniform(min_s, max_s)
    time.sleep(delay)
    return delay


if __name__ == "__main__":
    _delay = _apply_startup_jitter()
    print(f"[jitter] slept {_delay:.1f}s before cycle", flush=True)
    enter_cooperative("monitor_group.py", timeout=600)
    asyncio.run(main())
