"""Single source for Telethon client + push target resolution.

Replaces 5+ copies of
    load_dotenv(...); API_ID=int(os.environ[...]); TelegramClient(SESSION,...)
and
    async for d in client.iter_dialogs(limit=200): if d.id == ... ...

Usage:
    from tg_client import make_client, resolve_push_target

    async with make_client() as client:
        target, dialog_name, how = await resolve_push_target(client, cfg_id, cfg_hint)
        await client.send_message(target, "...")
"""
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient

PROJECT_DIR = Path(__file__).resolve().parent

_ENV_LOADED = False


def _ensure_env():
    global _ENV_LOADED
    if not _ENV_LOADED:
        load_dotenv(PROJECT_DIR / ".env")
        _ENV_LOADED = True


def _session_name() -> str:
    """Read session name from .env (TG_SESSION_NAME), default 'monitor_session'."""
    _ensure_env()
    return os.environ.get("TG_SESSION_NAME", "monitor_session")


# Lazy-resolved (calls _ensure_env via _session_name on first access)
SESSION_PATH = str(PROJECT_DIR / "sessions" / _session_name())


def _harden_session_busy_timeout(client: TelegramClient, ms: int = 10000) -> None:
    """Set sqlite busy_timeout on Telethon's session connection (additive).

    Telethon's SQLiteSession opens its conn with sqlite3.connect(file,
    check_same_thread=False) and NO timeout= arg → busy_timeout=0. On a
    mid-cycle connection drop, the _keepalive_loop task and the disconnect
    coro both call _save_states_and_entities() on the same session conn and
    race; the loser gets `database is locked` thrown *immediately*. Setting
    busy_timeout makes the loser wait/retry for `ms` instead of crashing the
    cycle's incident push. Best-effort: never let hardening break the client.
    """
    try:
        conn = getattr(client.session, "_conn", None)
        if conn is not None:
            conn.execute(f"PRAGMA busy_timeout = {int(ms)}")
    except Exception:
        pass


def make_client() -> TelegramClient:
    """Return a Telethon client bound to the shared session.

    Does NOT start/connect — caller uses `async with make_client() as client`
    or manual `await client.connect()` (e.g. bot_scraper for yield support).
    """
    _ensure_env()
    api_id = int(os.environ["TG_API_ID"])
    api_hash = os.environ["TG_API_HASH"]
    client = TelegramClient(SESSION_PATH, api_id, api_hash)
    _harden_session_busy_timeout(client)
    return client


async def resolve_push_target(client, target_id: int, name_hint: str = ""):
    """Resolve push target by id or name-hint fallback.

    Walks up to 200 dialogs in one pass matching either criterion (handles
    supergroup id migrations where the old id no longer resolves). Falls back
    to client.get_input_entity(target_id) for chats not in dialog list.

    Returns (input_entity, dialog_name_or_None, how_matched)
      how_matched ∈ {"id", "name", "get_input_entity"}
    """
    async for d in client.iter_dialogs(limit=200):
        if d.id == target_id:
            return d.input_entity, d.name, "id"
        if name_hint and name_hint in (d.name or ""):
            return d.input_entity, d.name, "name"
    entity = await client.get_input_entity(target_id)
    return entity, None, "get_input_entity"
