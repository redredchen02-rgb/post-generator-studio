import json
import os
import sqlite3
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    msg_id INTEGER NOT NULL,
    text TEXT,
    date INTEGER,
    views INTEGER,
    forwards INTEGER,
    fwd_from TEXT,
    fetched_at INTEGER,
    UNIQUE(channel, msg_id)
);
CREATE INDEX IF NOT EXISTS idx_channel_date ON messages(channel, date);
CREATE INDEX IF NOT EXISTS idx_date ON messages(date);

CREATE TABLE IF NOT EXISTS state (
    channel TEXT PRIMARY KEY,
    last_msg_id INTEGER,
    last_fetched_at INTEGER
);

CREATE TABLE IF NOT EXISTS trending_keywords (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    source TEXT NOT NULL,
    rank INTEGER,
    fetched_at INTEGER,
    s_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_kw_source_time ON trending_keywords(source, fetched_at);
CREATE INDEX IF NOT EXISTS idx_kw_term ON trending_keywords(keyword);

CREATE TABLE IF NOT EXISTS discovered_channels (
    username TEXT NOT NULL,
    source TEXT NOT NULL,
    name TEXT,
    url TEXT,
    kind TEXT,
    subscribers TEXT,
    first_seen INTEGER,
    last_seen INTEGER,
    PRIMARY KEY (username, source)
);
CREATE INDEX IF NOT EXISTS idx_dc_username ON discovered_channels(username);

CREATE TABLE IF NOT EXISTS bot_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bot TEXT NOT NULL,
    action TEXT NOT NULL,
    text TEXT,
    buttons_json TEXT,
    fetched_at INTEGER
);

CREATE TABLE IF NOT EXISTS discussion_media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT,
    parent_channel TEXT NOT NULL,
    parent_msg_id INTEGER NOT NULL,
    comment_msg_id INTEGER NOT NULL,
    grouped_id INTEGER,
    kind TEXT,
    file_size INTEGER,
    cached_path TEXT,
    text_preview TEXT,
    fetched_at INTEGER,
    UNIQUE(parent_channel, parent_msg_id, comment_msg_id)
);
CREATE INDEX IF NOT EXISTS idx_dm_keyword ON discussion_media(keyword);
CREATE INDEX IF NOT EXISTS idx_dm_parent ON discussion_media(parent_channel, parent_msg_id);

CREATE TABLE IF NOT EXISTS ad_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    msg_id INTEGER NOT NULL,
    text TEXT,
    reasons TEXT,
    detected_at INTEGER NOT NULL,
    UNIQUE(channel, msg_id)
);
CREATE INDEX IF NOT EXISTS idx_ad_channel_time ON ad_samples(channel, detected_at);

CREATE TABLE IF NOT EXISTS drill_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    fetched_at INTEGER NOT NULL,
    new_links_count INTEGER DEFAULT 0,
    total_returned INTEGER DEFAULT 0,
    rank INTEGER
);
CREATE INDEX IF NOT EXISTS idx_ds_keyword_time ON drill_stats(keyword, fetched_at);

CREATE TABLE IF NOT EXISTS content_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT,
    title TEXT,
    url TEXT,
    channel_username TEXT,
    msg_id INTEGER,
    kind TEXT,
    duration TEXT,
    nsfw INTEGER DEFAULT 0,
    source TEXT,
    fetched_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_cl_keyword ON content_links(keyword);
CREATE INDEX IF NOT EXISTS idx_cl_channel ON content_links(channel_username);
CREATE INDEX IF NOT EXISTS idx_cl_source_time ON content_links(source, fetched_at);
-- Dedup: same url + keyword + source never stored twice. Requires dedup migration
-- first if existing rows have dupes. Safe to CREATE IF NOT EXISTS even when empty.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_cl_url_kw_src ON content_links(url, keyword, source);

-- 2026-05-11 window-gated DUD: media 訊息掃到時若不在下載窗口內，
-- 排到此隊列待下個窗口 cycle drain。UNIQUE(channel, msg_id) 自動去重，
-- attempts 超過 _PENDING_DEAD_THRESHOLD 標 dead 不再重試。
CREATE TABLE IF NOT EXISTS pending_media (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    channel         TEXT NOT NULL,
    msg_id          INTEGER NOT NULL,
    grouped_id      INTEGER,
    target_chat_id  INTEGER NOT NULL,
    forward_mode    TEXT,
    enqueued_at     INTEGER NOT NULL,
    attempts        INTEGER DEFAULT 0,
    last_attempt_at INTEGER,
    last_error      TEXT,
    dead            INTEGER DEFAULT 0,
    UNIQUE(channel, msg_id)
);
CREATE INDEX IF NOT EXISTS idx_pending_media_drain ON pending_media(dead, enqueued_at);

-- [HotspotMonitor bot-teaser-resume patch] 大檔 bot-media 下載解耦+續傳佇列
-- （big-lane Phase D 適配 HM local-sink）。一帖 bot teaser（@bbcaiuu_bot 口令型，
-- 15~23 個大影片）下載塞不進單一 scan cycle → 整帖入此佇列，游標照推、cycle 收工，
-- 之後每 cycle drain 一帖、跨 cycle 續傳（delivered_ids 累積、.partial 斷點），全下完
-- 才 mark done。UNIQUE(channel,post_id) 冪等去重；attempts 超 BIG_TEASER_DEAD_THRESHOLD 標 dead。
CREATE TABLE IF NOT EXISTS pending_bot_teaser (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    channel         TEXT NOT NULL,
    post_id         INTEGER NOT NULL,
    bot_username    TEXT NOT NULL,
    token           TEXT NOT NULL,
    target_chat_id  INTEGER NOT NULL,
    caption         TEXT,
    anchor_msg_id   INTEGER,
    delivered_ids   TEXT DEFAULT '[]',
    enqueued_at     INTEGER NOT NULL,
    attempts        INTEGER DEFAULT 0,
    last_attempt_at INTEGER,
    last_error      TEXT,
    dead            INTEGER DEFAULT 0,
    UNIQUE(channel, post_id)
);
CREATE INDEX IF NOT EXISTS idx_pending_bot_teaser_drain ON pending_bot_teaser(dead, enqueued_at);
"""


def connect(path):
    """Single entry-point for sqlite3 connection across the project.

    Opens with a 30s busy-timeout (default 5s is too short for concurrent
    writers like bot_scraper cycle + digest). WAL mode is persistent at DB
    level — set once in init_db, all subsequent connections inherit it.
    """
    conn = sqlite3.connect(path, timeout=30)
    return conn


def init_db(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with connect(path) as conn:
        # Persistent DB-level config; survives process restarts.
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")  # safe under WAL, 2-3× write throughput
        conn.executescript(SCHEMA)
        cols = {r[1] for r in conn.execute("PRAGMA table_info(trending_keywords)")}
        if "s_id" not in cols:
            conn.execute("ALTER TABLE trending_keywords ADD COLUMN s_id TEXT")
        dc_cols = {r[1] for r in conn.execute("PRAGMA table_info(discovered_channels)")}
        if "channel_title" not in dc_cols:
            conn.execute("ALTER TABLE discovered_channels ADD COLUMN channel_title TEXT")
        if "title_refreshed_at" not in dc_cols:
            conn.execute("ALTER TABLE discovered_channels ADD COLUMN title_refreshed_at INTEGER")


def get_last_msg_id(path, channel):
    with connect(path) as conn:
        row = conn.execute(
            "SELECT last_msg_id FROM state WHERE channel=?", (channel,)
        ).fetchone()
        return row[0] if row else 0


# ─── pending_media queue (window-gated DUD) ─────────────────────────
_PENDING_DEAD_THRESHOLD = 5  # attempts 達到即標 dead，停止重試


def enqueue_pending(path, channel, msg_id, target_chat_id, forward_mode=None, grouped_id=None):
    """冪等：UNIQUE(channel, msg_id) 已存在 → INSERT OR IGNORE 自動 noop。"""
    with connect(path) as conn:
        conn.execute(
            """INSERT OR IGNORE INTO pending_media
               (channel, msg_id, grouped_id, target_chat_id, forward_mode, enqueued_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (channel, msg_id, grouped_id, target_chat_id, forward_mode, int(time.time())),
        )


def drain_next_pending(path, limit=20):
    """FIFO 取出未 dead 的 pending rows。Caller 自行處理後呼叫 mark_pending_done/fail。"""
    with connect(path) as conn:
        rows = conn.execute(
            """SELECT id, channel, msg_id, grouped_id, target_chat_id, forward_mode, attempts
               FROM pending_media
               WHERE dead = 0
               ORDER BY enqueued_at ASC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        return [
            {"id": r[0], "channel": r[1], "msg_id": r[2], "grouped_id": r[3],
             "target_chat_id": r[4], "forward_mode": r[5], "attempts": r[6]}
            for r in rows
        ]


def mark_pending_done(path, pending_id):
    with connect(path) as conn:
        conn.execute("DELETE FROM pending_media WHERE id=?", (pending_id,))


def mark_pending_fail(path, pending_id, err_str):
    """attempts++; 若 >= threshold 標 dead。"""
    now = int(time.time())
    with connect(path) as conn:
        conn.execute(
            """UPDATE pending_media
               SET attempts = attempts + 1,
                   last_attempt_at = ?,
                   last_error = ?,
                   dead = CASE WHEN attempts + 1 >= ? THEN 1 ELSE 0 END
               WHERE id = ?""",
            (now, str(err_str)[:500], _PENDING_DEAD_THRESHOLD, pending_id),
        )


# ─── pending_bot_teaser queue ───────────────────────────────────────
# [HotspotMonitor bot-teaser-resume patch] 大檔 bot-media 下載解耦+續傳。
# attempts 上限比 normal pending（5）寬，因大帖跨多 cycle 屬正常，避免誤殺。
BIG_TEASER_DEAD_THRESHOLD = 8


def enqueue_bot_teaser(path, channel, post_id, bot_username, token, target_chat_id,
                       caption=None, anchor_msg_id=None, delivered_ids=None):
    """冪等：UNIQUE(channel, post_id) 已存在 → INSERT OR IGNORE 自動 noop
    （既有 row 的 delivered_ids 累積由 update_bot_teaser_delivered 負責，不被覆蓋）。"""
    with connect(path) as conn:
        conn.execute(
            """INSERT OR IGNORE INTO pending_bot_teaser
               (channel, post_id, bot_username, token, target_chat_id,
                caption, anchor_msg_id, delivered_ids, enqueued_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (channel, post_id, bot_username, token, target_chat_id, caption,
             anchor_msg_id, json.dumps(sorted(set(delivered_ids or []))), int(time.time())),
        )


def drain_next_bot_teaser(path, limit=1):
    """FIFO 取未 dead 的 bot teaser（預設 1 帖/cycle，比照 big-lane 慢車道一次一個）。"""
    with connect(path) as conn:
        rows = conn.execute(
            """SELECT id, channel, post_id, bot_username, token, target_chat_id,
                      caption, anchor_msg_id, delivered_ids, attempts
               FROM pending_bot_teaser
               WHERE dead = 0
               ORDER BY enqueued_at ASC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        cols = ("id", "channel", "post_id", "bot_username", "token", "target_chat_id",
                "caption", "anchor_msg_id", "delivered_ids", "attempts")
        return [dict(zip(cols, r)) for r in rows]


def update_bot_teaser_delivered(path, teaser_id, delivered_ids):
    """覆寫 delivered_ids（caller 傳已累積的完整 set）。"""
    with connect(path) as conn:
        conn.execute(
            "UPDATE pending_bot_teaser SET delivered_ids = ? WHERE id = ?",
            (json.dumps(sorted(set(delivered_ids or []))), teaser_id),
        )


def mark_bot_teaser_done(path, teaser_id):
    with connect(path) as conn:
        conn.execute("DELETE FROM pending_bot_teaser WHERE id = ?", (teaser_id,))


def mark_bot_teaser_fail(path, teaser_id, err_str):
    """attempts++; 若 >= BIG_TEASER_DEAD_THRESHOLD 標 dead。"""
    now = int(time.time())
    with connect(path) as conn:
        conn.execute(
            """UPDATE pending_bot_teaser
               SET attempts = attempts + 1,
                   last_attempt_at = ?,
                   last_error = ?,
                   dead = CASE WHEN attempts + 1 >= ? THEN 1 ELSE 0 END
               WHERE id = ?""",
            (now, str(err_str)[:500], BIG_TEASER_DEAD_THRESHOLD, teaser_id),
        )


def pending_stats(path):
    """For watchdog metric: alive count, dead count, oldest enqueue age (sec)."""
    with connect(path) as conn:
        row = conn.execute(
            """SELECT
                 SUM(CASE WHEN dead=0 THEN 1 ELSE 0 END) AS alive,
                 SUM(CASE WHEN dead=1 THEN 1 ELSE 0 END) AS dead_n,
                 MIN(CASE WHEN dead=0 THEN enqueued_at END) AS oldest_alive
               FROM pending_media"""
        ).fetchone()
        alive = row[0] or 0
        dead_n = row[1] or 0
        oldest_age = (int(time.time()) - row[2]) if row[2] else 0
        return {"alive": alive, "dead": dead_n, "oldest_age_sec": oldest_age}


def prune_pending(path, dead_older_than_days=7, alive_older_than_days=30):
    """週期性 cleanup：dead rows 老於 7d 刪除；alive 老於 30d 視為遺失也刪。"""
    now = int(time.time())
    with connect(path) as conn:
        c1 = conn.execute(
            "DELETE FROM pending_media WHERE dead=1 AND enqueued_at < ?",
            (now - dead_older_than_days * 86400,),
        ).rowcount
        c2 = conn.execute(
            "DELETE FROM pending_media WHERE dead=0 AND enqueued_at < ?",
            (now - alive_older_than_days * 86400,),
        ).rowcount
        return c1, c2


def alive_bot_teaser_stems(path):
    """存活（dead=0）pending_bot_teaser 對應的 cache stem 集合
    （`<channel無@>_<post_id>` 前綴，比照 _BOT_CACHE_DIR 命名）。
    供 cleanup 掃孤兒 .partial 時對照「哪些 stem 仍屬存活 teaser、不可誤刪」。"""
    with connect(path) as conn:
        rows = conn.execute(
            "SELECT channel, post_id FROM pending_bot_teaser WHERE dead=0"
        ).fetchall()
    return {f"{str(ch).lstrip('@')}_{pid}" for ch, pid in rows}


def prune_bot_teaser(path, dead_older_than_days=7, alive_older_than_days=30):
    """週期性 cleanup：比照 prune_pending——dead teaser 老於 7d 刪除；
    alive 老於 30d 視為遺失也刪。pending_bot_teaser 原本無任何 prune，
    teaser 標 dead 後 row 永久殘留、其 .partial 半成品也再不會被清。"""
    now = int(time.time())
    with connect(path) as conn:
        c1 = conn.execute(
            "DELETE FROM pending_bot_teaser WHERE dead=1 AND enqueued_at < ?",
            (now - dead_older_than_days * 86400,),
        ).rowcount
        c2 = conn.execute(
            "DELETE FROM pending_bot_teaser WHERE dead=0 AND enqueued_at < ?",
            (now - alive_older_than_days * 86400,),
        ).rowcount
        return c1, c2


def save_messages(path, messages):
    if not messages:
        return
    now = int(time.time())
    rows = [{**m, "fetched_at": now} for m in messages]
    with connect(path) as conn:
        conn.executemany(
            """INSERT OR IGNORE INTO messages
               (channel, msg_id, text, date, views, forwards, fwd_from, fetched_at)
               VALUES (:channel, :msg_id, :text, :date, :views, :forwards, :fwd_from, :fetched_at)""",
            rows,
        )


def update_state(path, channel, last_msg_id):
    now = int(time.time())
    with connect(path) as conn:
        conn.execute(
            """INSERT INTO state (channel, last_msg_id, last_fetched_at)
               VALUES (?, ?, ?)
               ON CONFLICT(channel) DO UPDATE SET
                 last_msg_id=excluded.last_msg_id,
                 last_fetched_at=excluded.last_fetched_at""",
            (channel, last_msg_id, now),
        )


def stats(path):
    with connect(path) as conn:
        total = conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        per_ch = conn.execute(
            "SELECT channel, COUNT(*) FROM messages GROUP BY channel ORDER BY 2 DESC"
        ).fetchall()
        return total, per_ch


def save_keywords(path, keywords, source):
    now = int(time.time())
    rows = [(k["keyword"], source, k["rank"], now, k.get("s_id")) for k in keywords]
    with connect(path) as conn:
        conn.executemany(
            "INSERT INTO trending_keywords (keyword, source, rank, fetched_at, s_id) VALUES (?,?,?,?,?)",
            rows,
        )


def get_latest_s_id(path, keyword):
    """Return most recent s_id observed for keyword, or None if never seen."""
    with connect(path) as conn:
        row = conn.execute(
            "SELECT s_id FROM trending_keywords WHERE keyword=? AND s_id IS NOT NULL "
            "ORDER BY fetched_at DESC LIMIT 1",
            (keyword,),
        ).fetchone()
        return row[0] if row else None


def recently_drilled_keywords(path, within_seconds):
    """Set of keywords with content_links fetched within the last N seconds (dedup window)."""
    cutoff = int(time.time()) - within_seconds
    with connect(path) as conn:
        rows = conn.execute(
            "SELECT DISTINCT keyword FROM content_links WHERE fetched_at >= ?",
            (cutoff,),
        ).fetchall()
        return {r[0] for r in rows if r[0]}


def keywords_in_window(path, window_seconds, max_rank=None):
    """(keyword, best_rank, latest_s_id) for keywords seen in last window."""
    cutoff = int(time.time()) - window_seconds
    q = (
        "SELECT keyword, MIN(rank) as best_rank, "
        "(SELECT s_id FROM trending_keywords tk2 WHERE tk2.keyword=tk.keyword AND tk2.s_id IS NOT NULL "
        " ORDER BY fetched_at DESC LIMIT 1) as s_id "
        "FROM trending_keywords tk WHERE fetched_at >= ?"
    )
    params = [cutoff]
    if max_rank is not None:
        q += " AND rank <= ?"
        params.append(max_rank)
    q += " GROUP BY keyword ORDER BY best_rank"
    with connect(path) as conn:
        return conn.execute(q, params).fetchall()


def keywords_with_zero_links(path, window_seconds, max_rank=None):
    """Keywords that appeared in trending within window but have 0 content_links entries."""
    cutoff = int(time.time()) - window_seconds
    q = (
        "SELECT DISTINCT tk.keyword, MIN(tk.rank) as best_rank "
        "FROM trending_keywords tk "
        "LEFT JOIN content_links cl ON tk.keyword = cl.keyword "
        "WHERE tk.fetched_at >= ? AND cl.id IS NULL"
    )
    params = [cutoff]
    if max_rank is not None:
        q += " AND tk.rank <= ?"
        params.append(max_rank)
    q += " GROUP BY tk.keyword ORDER BY best_rank"
    with connect(path) as conn:
        return conn.execute(q, params).fetchall()


def save_channels(path, channels):
    now = int(time.time())
    with connect(path) as conn:
        for c in channels:
            conn.execute(
                """INSERT INTO discovered_channels (username, source, name, url, kind, subscribers, first_seen, last_seen)
                   VALUES (:username, :source, :name, :url, :kind, :subscribers, :now, :now)
                   ON CONFLICT(username, source) DO UPDATE SET
                     name=excluded.name, url=excluded.url, kind=excluded.kind,
                     subscribers=excluded.subscribers, last_seen=excluded.last_seen""",
                {**c, "now": now},
            )


def save_bot_log(path, bot, action, text, buttons_json):
    now = int(time.time())
    with connect(path) as conn:
        conn.execute(
            "INSERT INTO bot_logs (bot, action, text, buttons_json, fetched_at) VALUES (?,?,?,?,?)",
            (bot, action, text, buttons_json, now),
        )


def save_content_links(path, links):
    if not links:
        return
    now = int(time.time())
    rows = [{**l, "fetched_at": now} for l in links]
    with connect(path) as conn:
        conn.executemany(
            """INSERT OR IGNORE INTO content_links
               (keyword, title, url, channel_username, msg_id, kind, duration, nsfw, source, fetched_at)
               VALUES (:keyword, :title, :url, :channel_username, :msg_id, :kind, :duration, :nsfw, :source, :fetched_at)""",
            rows,
        )


def save_discussion_media(path, rows):
    """rows: list of dicts with keys keyword/parent_channel/parent_msg_id/comment_msg_id/grouped_id/kind/file_size/cached_path/text_preview."""
    if not rows:
        return
    now = int(time.time())
    payload = [{**r, "fetched_at": now} for r in rows]
    with connect(path) as conn:
        conn.executemany(
            """INSERT OR IGNORE INTO discussion_media
               (keyword, parent_channel, parent_msg_id, comment_msg_id, grouped_id, kind, file_size, cached_path, text_preview, fetched_at)
               VALUES (:keyword, :parent_channel, :parent_msg_id, :comment_msg_id, :grouped_id, :kind, :file_size, :cached_path, :text_preview, :fetched_at)""",
            payload,
        )


def get_discussion_media_for_post(path, parent_channel, parent_msg_id):
    """Return cached discussion media rows for a given parent post."""
    with connect(path) as conn:
        rows = conn.execute(
            """SELECT comment_msg_id, grouped_id, kind, file_size, cached_path, text_preview
               FROM discussion_media WHERE parent_channel=? AND parent_msg_id=?
               ORDER BY comment_msg_id""",
            (parent_channel, parent_msg_id),
        ).fetchall()
    return rows


def save_ad_sample(path, channel, msg_id, text, reasons):
    """Persist an ad-identified msg for later review / rule-tuning."""
    now = int(time.time())
    with connect(path) as conn:
        conn.execute(
            """INSERT OR IGNORE INTO ad_samples (channel, msg_id, text, reasons, detected_at)
               VALUES (?, ?, ?, ?, ?)""",
            (channel, msg_id, (text or "")[:2000], reasons, now),
        )


def recent_ad_samples(path, limit=20):
    with connect(path) as conn:
        return conn.execute(
            "SELECT channel, msg_id, text, reasons, detected_at FROM ad_samples "
            "ORDER BY detected_at DESC LIMIT ?",
            (limit,),
        ).fetchall()


def count_content_links_for_keyword(path, keyword):
    """Fast count used as before/after delta probe around a drill."""
    with connect(path) as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM content_links WHERE keyword=?", (keyword,)
        ).fetchone()[0]


def save_drill_stat(path, keyword, new_links_count, total_returned, rank=None):
    """Record one drill outcome so adaptive dedup can learn per-keyword activity."""
    now = int(time.time())
    with connect(path) as conn:
        conn.execute(
            """INSERT INTO drill_stats (keyword, fetched_at, new_links_count, total_returned, rank)
               VALUES (?, ?, ?, ?, ?)""",
            (keyword, now, new_links_count, total_returned, rank),
        )


def recent_drill_stats(path, keyword, within_seconds=48 * 3600, limit=3):
    """Last N drill outcomes for keyword within window. Returns list of
    (new_links_count, total_returned, fetched_at) tuples, newest first."""
    cutoff = int(time.time()) - within_seconds
    with connect(path) as conn:
        return conn.execute(
            """SELECT new_links_count, total_returned, fetched_at
               FROM drill_stats WHERE keyword=? AND fetched_at >= ?
               ORDER BY fetched_at DESC LIMIT ?""",
            (keyword, cutoff, limit),
        ).fetchall()


def last_drill_time_for_keyword(path, keyword):
    """Most recent drill timestamp for this keyword. Prefers drill_stats
    (dedicated table) but falls back to content_links.fetched_at so the
    adaptive dedup works correctly during the transition window before
    drill_stats accumulates data."""
    with connect(path) as conn:
        row = conn.execute(
            "SELECT MAX(fetched_at) FROM drill_stats WHERE keyword=?", (keyword,)
        ).fetchone()
        if row and row[0]:
            return row[0]
        row = conn.execute(
            "SELECT MAX(fetched_at) FROM content_links WHERE keyword=?", (keyword,)
        ).fetchone()
        return row[0] if row and row[0] else None


def keyword_counts(path, source=None, since=None):
    q = "SELECT keyword, COUNT(*) c FROM trending_keywords WHERE 1=1"
    params = []
    if source:
        q += " AND source=?"
        params.append(source)
    if since:
        q += " AND fetched_at>=?"
        params.append(since)
    q += " GROUP BY keyword ORDER BY c DESC"
    with connect(path) as conn:
        return conn.execute(q, params).fetchall()
