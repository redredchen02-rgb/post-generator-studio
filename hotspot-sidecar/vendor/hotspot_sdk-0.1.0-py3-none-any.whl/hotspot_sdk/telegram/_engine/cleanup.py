"""group-monitor 磁碟 + DB cleanup。

底層邏輯：
- data/discussion/<channel>_<post>/ 是 fetch_discussion 下載的評論區媒體，按目錄 mtime prune
- data/media_cache/ 是 forward_keyword.py protected fallback 的 reupload cache，按檔 mtime prune
- DB 表 ad_samples / discussion_media 老樣本按 captured_at / fetched_at prune
- launchd 排程每天 04:30，避開 nsfw cleanup 04:00

Usage:
    cleanup.py                  # apply defaults
    cleanup.py --dry-run        # report only
    cleanup.py --cache-days 3   # override TTL
"""
import argparse
import shutil
import sqlite3
import tempfile
import time
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent
CACHE_DIR = PROJECT_DIR / "data/media_cache"
DISCUSSION_CACHE = PROJECT_DIR / "data/discussion"
DB_PATH = PROJECT_DIR / "data/messages.sqlite"
# [HotspotMonitor bot-teaser-resume patch] 大檔 bot-media 續傳 cache（須與
# monitor_group._BOT_CACHE_DIR 一致：tempfile.gettempdir()/hm_botmedia）。
# dead/已刪 teaser 的 <stem>.partial 半成品在 monitor_group 內再不會被 unlink，
# 須由 cleanup 對照存活 teaser stem 集合 + mtime TTL 掃孤兒。
BOT_CACHE_DIR = Path(tempfile.gettempdir()) / "hm_botmedia"

WORKSPACE = Path.home() / ".openclaw/workspace/group-monitor"
LOG_DIR = WORKSPACE / "logs"


def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def prune_cache(days, dry_run):
    if not CACHE_DIR.exists():
        return (0, 0, 0)
    cutoff = time.time() - days * 86400
    freed = removed = kept = 0
    for p in CACHE_DIR.iterdir():
        if not p.is_file():
            continue
        mtime = p.stat().st_mtime
        size = p.stat().st_size
        if mtime < cutoff:
            print(f"  [cache] rm {p.name} ({human_size(size)}, age {(time.time()-mtime)/86400:.1f}d)")
            if not dry_run:
                p.unlink()
            freed += size
            removed += 1
        else:
            kept += 1
    return removed, kept, freed


def prune_discussion_cache(days, dry_run):
    if not DISCUSSION_CACHE.exists():
        return (0, 0, 0)
    cutoff = time.time() - days * 86400
    freed = removed = kept = 0
    for d in DISCUSSION_CACHE.iterdir():
        if not d.is_dir():
            continue
        mtime = d.stat().st_mtime
        if mtime < cutoff:
            size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
            age_d = (time.time() - mtime) / 86400
            print(f"  [disc] rm {d.name}/ ({human_size(size)}, age {age_d:.1f}d)")
            if not dry_run:
                shutil.rmtree(d)
            freed += size
            removed += 1
        else:
            kept += 1
    return removed, kept, freed


def prune_bot_cache(days, alive_stems, dry_run):
    """掃 BOT_CACHE_DIR 清孤兒 bot-media 半成品 / 完成檔。

    刪除條件（任一即刪）：
      · 檔 stem（去掉最後一段 _<m.id> 與副檔名後的 <channel>_<post_id>）不屬於任何
        存活 teaser（alive_stems）→ 該 teaser 已 done/dead/被 prune，殘檔成孤兒。
      · mtime 老於 N 天（TTL 兜底：即使 alive，卡死太久的半成品也清，下輪重下）。
    對照 alive_stems 集合避免誤刪正在續傳的存活 teaser 新鮮 .partial。
    """
    if not BOT_CACHE_DIR.exists():
        return (0, 0, 0)
    cutoff = time.time() - days * 86400
    freed = removed = kept = 0
    for p in BOT_CACHE_DIR.iterdir():
        if not p.is_file():
            continue
        # stem 還原：<channel>_<post>_<m.id>[.partial|.<ext>] → 去最後一段與副檔名
        base = p.name[:-len(".partial")] if p.name.endswith(".partial") else p.stem
        stem = base.rsplit("_", 1)[0] if "_" in base else base
        mtime = p.stat().st_mtime
        size = p.stat().st_size
        orphan = stem not in alive_stems
        stale = mtime < cutoff
        if orphan or stale:
            why = "orphan" if orphan else f"stale {(time.time()-mtime)/86400:.1f}d"
            print(f"  [botcache] rm {p.name} ({human_size(size)}, {why})")
            if not dry_run:
                p.unlink()
            freed += size
            removed += 1
        else:
            kept += 1
    return removed, kept, freed


def prune_old_db_rows(table, ts_col, days, dry_run):
    if not DB_PATH.exists():
        return 0
    cutoff = int(time.time() - days * 86400)
    with sqlite3.connect(DB_PATH, timeout=30) as conn:
        cur = conn.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
        if not cur.fetchone():
            return 0
        n = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE {ts_col} < ?", (cutoff,)).fetchone()[0]
        if n > 0 and not dry_run:
            conn.execute(f"DELETE FROM {table} WHERE {ts_col} < ?", (cutoff,))
        print(f"  [db] {table} older than {days}d: {n} {'(pruned)' if not dry_run else '(dry)'}")
    return n


def rotate_logs(max_size_mb, dry_run):
    """Rotate launchd-style stdout/stderr logs. Skips RotatingFileHandler-managed
    `monitor.log` (and its `.1`/`.2`/... backups), which monitor_group.py owns;
    racing it would orphan the live logger's fd onto an archived inode.
    """
    rotated = []
    if not LOG_DIR.exists():
        return rotated
    for p in LOG_DIR.glob("*.log"):
        if p.name == "monitor.log":
            continue
        size = p.stat().st_size
        if size > max_size_mb * 1024 * 1024:
            archive = p.with_suffix(f".log.{time.strftime('%Y%m%d')}")
            print(f"  [log] rotate {p.name} ({human_size(size)}) → {archive.name}")
            if not dry_run:
                p.rename(archive)
                p.touch()
            rotated.append(p.name)
    return rotated


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dry-run", action="store_true")
    # 2026-05-11 DUD: cache TTL 7d→1d (DUD 即時刪兜底, 1d 處理 fail 餘留)
    p.add_argument("--cache-days", type=int, default=1)
    p.add_argument("--discussion-days", type=int, default=7)
    p.add_argument("--ad-samples-days", type=int, default=14)
    p.add_argument("--disc-media-days", type=int, default=30)
    p.add_argument("--log-max-mb", type=int, default=10)
    p.add_argument("--pending-dead-days", type=int, default=7,
                   help="pending_media dead rows 老於 N 天刪除")
    p.add_argument("--pending-alive-days", type=int, default=30,
                   help="pending_media alive rows 老於 N 天視為遺失刪除")
    p.add_argument("--bot-cache-days", type=int, default=2,
                   help="bot-media 續傳 cache .partial mtime TTL（孤兒則不論年齡即刪）")
    p.add_argument("--vacuum", action="store_true")
    args = p.parse_args()

    print(f"cleanup starting ({'DRY RUN' if args.dry_run else 'LIVE'})")
    print(f"project dir: {PROJECT_DIR}\n")

    print(f"[1] media_cache prune (age > {args.cache_days}d)")
    rm, kp, fr = prune_cache(args.cache_days, args.dry_run)
    print(f"    removed {rm}, kept {kp}, freed {human_size(fr)}")

    print(f"\n[2] discussion cache prune (age > {args.discussion_days}d)")
    drm, dkp, dfr = prune_discussion_cache(args.discussion_days, args.dry_run)
    print(f"    removed {drm} dirs, kept {dkp}, freed {human_size(dfr)}")

    print(f"\n[3] launchd logs rotate (> {args.log_max_mb}MB)")
    rot = rotate_logs(args.log_max_mb, args.dry_run)
    print(f"    rotated: {rot or '(none)'}")

    print(f"\n[4] ad_samples DB prune (> {args.ad_samples_days}d)")
    prune_old_db_rows("ad_samples", "detected_at", args.ad_samples_days, args.dry_run)

    print(f"\n[5] discussion_media DB prune (> {args.disc_media_days}d)")
    prune_old_db_rows("discussion_media", "fetched_at", args.disc_media_days, args.dry_run)

    print(f"\n[6] pending_media prune (dead>{args.pending_dead_days}d, alive>{args.pending_alive_days}d)")
    if not args.dry_run and DB_PATH.exists():
        try:
            import db
            c1, c2 = db.prune_pending(str(DB_PATH),
                                       dead_older_than_days=args.pending_dead_days,
                                       alive_older_than_days=args.pending_alive_days)
            print(f"    dead pruned: {c1}, alive pruned: {c2}")
            stats = db.pending_stats(str(DB_PATH))
            print(f"    remaining: alive={stats['alive']} dead={stats['dead']} "
                   f"oldest_age={stats['oldest_age_sec']}s")
        except Exception as e:
            print(f"    pending_media prune err: {type(e).__name__}: {e}")
    else:
        print("    skipped (dry-run or DB missing)")

    # [HotspotMonitor bot-teaser-resume patch] pending_bot_teaser 原本無 prune
    # → dead teaser DB row + 其 .partial 半成品永久殘留。此處補上。
    print(f"\n[7] pending_bot_teaser prune (dead>{args.pending_dead_days}d, alive>{args.pending_alive_days}d)")
    alive_stems = set()
    if not args.dry_run and DB_PATH.exists():
        try:
            import db
            t1, t2 = db.prune_bot_teaser(str(DB_PATH),
                                         dead_older_than_days=args.pending_dead_days,
                                         alive_older_than_days=args.pending_alive_days)
            print(f"    dead pruned: {t1}, alive pruned: {t2}")
            alive_stems = db.alive_bot_teaser_stems(str(DB_PATH))
        except Exception as e:
            print(f"    pending_bot_teaser prune err: {type(e).__name__}: {e}")
    elif DB_PATH.exists():
        # dry-run 仍讀存活 stem 集合，讓 botcache 報告不誤標孤兒
        try:
            import db
            alive_stems = db.alive_bot_teaser_stems(str(DB_PATH))
        except Exception:
            alive_stems = set()
        print("    skipped (dry-run)")
    else:
        print("    skipped (DB missing)")

    print(f"\n[8] bot-media cache sweep (orphan or mtime > {args.bot_cache_days}d)")
    brm, bkp, bfr = prune_bot_cache(args.bot_cache_days, alive_stems, args.dry_run)
    print(f"    removed {brm}, kept {bkp}, freed {human_size(bfr)}")

    if args.vacuum and not args.dry_run and DB_PATH.exists():
        print("\n[9] VACUUM SQLite")
        with sqlite3.connect(DB_PATH, timeout=30) as conn:
            conn.execute("VACUUM")
        print(f"    DB size: {human_size(DB_PATH.stat().st_size)}")


if __name__ == "__main__":
    main()
