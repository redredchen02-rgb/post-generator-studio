"""Forward discovered content links for a specific keyword to target chat.

Default: 3 posts, sorted by kind priority (mixed album > video > image > other),
target = the configured push chat. Protected channels auto-fallback to download+reupload.

Usage:
    forward_keyword.py <keyword>                           # default 3 posts → Test chat
    forward_keyword.py 大杨嫂 --limit 10
    forward_keyword.py 大杨嫂 --kind video                 # DB filter
    forward_keyword.py 大杨嫂 --nsfw-only
    forward_keyword.py 大杨嫂 --to -1001234567890          # target override
    forward_keyword.py 大杨嫂 --max-size 4000              # premium → 4GB
"""
import argparse
import asyncio
import os
import sqlite3
import sys
import time
from pathlib import Path

from telethon.errors import ChatForwardsRestrictedError
from telethon.tl.types import DocumentAttributeVideo

from config import CFG
from session_lock import enter_cooperative
from tg_client import make_client, resolve_push_target

_PROJECT_DIR = Path(__file__).resolve().parent
DB_PATH = str(_PROJECT_DIR / "data" / "messages.sqlite")
CACHE_DIR = _PROJECT_DIR / "data" / "media_cache"

DEFAULT_TARGET = CFG.push_chat_id
DEFAULT_TARGET_NAME_HINT = CFG.push_chat_name_hint
DEFAULT_LIMIT = CFG.forward["default_limit"]
DEFAULT_MAX_REUPLOAD_MB = CFG.forward["default_max_size_mb"]
CANDIDATE_MULTIPLIER = CFG.forward["candidate_multiplier"]
ALBUM_WINDOW = CFG.forward["album_window"]


# 2026-05-15「评论区口令型」teaser（吃瓜大妈 @chiguadama 为典范）：
# caption 包含「评论区发送口令：`<token>` 获取视频」格式，token 用 backtick code
# 标记。下游 fetch_via_comment_token 在 disc reply token 拿 bot deep-link 拉资源。
# 多种字面写法都见过（：全角/半角、是否带空格），keyword 列表覆盖。
COMMENT_TOKEN_HINTS = (
    "评论区发送口令",
    "评论区口令",
    "评论区发送暗号",
    "发送口令",
)


def parse_comment_token(msg):
    """从主帖 caption 抽「评论区发送口令：`<token>` 获取视频」中的 token。

    判定条件：
      • msg.raw_text 含 COMMENT_TOKEN_HINTS 任一子串
      • msg.entities 有 MessageEntityCode，其 offset 在 hint 起始位置之后
        （取第一个匹配的 code entity）

    注意：entity offset 是 raw_text 的索引，不是 markdown-formatted text；
    必须用 m.raw_text / m.message 切片，否则会带上 backtick 等格式字符
    （2026-05-15 萊斯测试踩坑）。

    Returns:
      token string (stripped) or None
    """
    raw = getattr(msg, "raw_text", None) or getattr(msg, "message", "") or ""
    if not raw or not getattr(msg, "entities", None):
        return None
    hint_offset = -1
    for h in COMMENT_TOKEN_HINTS:
        idx = raw.find(h)
        if idx >= 0:
            hint_offset = idx
            break
    if hint_offset < 0:
        return None
    # Telegram MessageEntity.offset/length 以 UTF-16 code unit 計，而 Python str
    # 以 code point 索引。主帖在 code entity 之前含 supplementary-plane 字元（emoji
    # 等，UTF-16 占 2 單位、code point 占 1）時，直接 raw[off:off+len] 會錯位、抽錯
    # token。故先把 raw 編成 utf-16-le（每 code unit = 2 bytes），用 *2 對齊切片後
    # 再 decode 回來。hint_offset 仍用 raw.find（code-point），故 entity 比較須換成
    # 同樣 UTF-16 基準的 hint offset。
    raw_u16 = raw.encode("utf-16-le")
    hint_offset_u16 = len(raw[:hint_offset].encode("utf-16-le")) // 2
    for e in msg.entities:
        if type(e).__name__ == "MessageEntityCode" and e.offset > hint_offset_u16:
            token = raw_u16[e.offset * 2:(e.offset + e.length) * 2].decode(
                "utf-16-le", "ignore"
            ).strip()
            if token:
                return token
    return None


def strip_comment_token_tail(text):
    """去掉「评论区发送口令：`xxx` 获取视频」引流尾巴，保留正文 + hashtag。

    2026-05-15 萊斯：bot 拉来的资源 forward 到群必须带主帖完整文案（标题/
    hashtag），不能只有内部 debug 文案。截断到第一个 hint 子串之前。
    """
    if not text:
        return ""
    cut = len(text)
    for h in COMMENT_TOKEN_HINTS:
        idx = text.find(h)
        if 0 <= idx < cut:
            cut = idx
    return text[:cut].strip()


# =====================================================
# DB
# =====================================================

def load_candidates(keyword, n, kind=None, nsfw_only=False):
    # GROUP BY (channel, msg_id) collapses duplicates when same post was recorded
    # under multiple keyword rows. MAX(nsfw) = "any NSFW variant counts"; oldest
    # id comes first among non-NSFW so we prefer the earliest scraped instance.
    # (Previous `SELECT DISTINCT ... ORDER BY id` with id outside SELECT was
    # SQLite UB and could return unstable ordering.)
    with sqlite3.connect(DB_PATH, timeout=30) as conn:
        q = """SELECT channel_username, msg_id,
                      MAX(title) AS title, MAX(kind) AS kind, MAX(nsfw) AS nsfw
               FROM content_links
               WHERE keyword = ? AND channel_username != '' AND msg_id IS NOT NULL"""
        params = [keyword]
        if kind:
            q += " AND kind = ?"
            params.append(kind)
        if nsfw_only:
            q += " AND nsfw = 1"
        q += " GROUP BY channel_username, msg_id ORDER BY nsfw DESC, MIN(id) LIMIT ?"
        params.append(n)
        return conn.execute(q, params).fetchall()


# =====================================================
# FETCH + GROUP + RANK
# =====================================================

async def fetch_posts(client, candidates):
    """Fetch messages grouped by (channel, grouped_id or solo_id).
    For albums, expand to ALL items sharing the grouped_id (± ALBUM_WINDOW)."""
    from collections import OrderedDict

    by_channel = {}
    for ch, mid, _, _, _ in candidates:
        by_channel.setdefault(ch, []).append(mid)

    # Step 1: fetch known candidates
    initial = OrderedDict()  # (channel, gid) -> list
    for channel, mids in by_channel.items():
        try:
            msgs = await client.get_messages(channel, ids=mids)
        except Exception as e:
            print(f"  @{channel}: fetch fail: {type(e).__name__}: {e}")
            continue
        msgs = [m for m in msgs if m is not None]
        for m in msgs:
            gid = m.grouped_id if m.grouped_id else ("solo", m.id)
            initial.setdefault((channel, gid), []).append(m)

    # Step 2: expand albums — fetch window around known items for any group with grouped_id
    posts = OrderedDict()
    for (channel, gid), msgs in initial.items():
        if isinstance(gid, tuple):  # solo
            posts[(channel, gid)] = msgs
            continue
        known_ids = [m.id for m in msgs]
        low = max(1, min(known_ids) - ALBUM_WINDOW)
        high = max(known_ids) + ALBUM_WINDOW
        window = list(range(low, high + 1))
        try:
            nearby = await client.get_messages(channel, ids=window)
        except Exception as e:
            print(f"  @{channel}: album expand fail: {type(e).__name__}")
            posts[(channel, gid)] = msgs
            continue
        full = [m for m in nearby if m is not None and m.grouped_id == gid]
        full.sort(key=lambda m: m.id)
        posts[(channel, gid)] = full if full else msgs
    return posts


def score_post(msgs):
    """Priority: mixed (video + photo) > video > photo > other."""
    has_video = any(getattr(m, "video", None) for m in msgs)
    has_photo = any(getattr(m, "photo", None) for m in msgs)
    has_audio = any(getattr(m, "audio", None) for m in msgs)
    if has_video and has_photo:
        return 4
    if has_video:
        return 3
    if has_photo:
        return 2
    if has_audio:
        return 1
    return 0


def post_label(msgs):
    kinds = []
    if any(getattr(m, "video", None) for m in msgs):
        kinds.append("📹")
    if any(getattr(m, "photo", None) for m in msgs):
        kinds.append("🖼")
    if any(getattr(m, "audio", None) for m in msgs):
        kinds.append("🎧")
    if not kinds:
        kinds.append("📄")
    return "".join(kinds)


# =====================================================
# FORWARD / REUPLOAD
# =====================================================

async def download_cached(client, msg, channel, size_mb=0):
    """Download msg media to persistent cache, skip if already cached.
    For files > 50MB, print progress every ~5 seconds."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    prefix = f"{channel}_{msg.id}"
    existing = list(CACHE_DIR.glob(f"{prefix}.*"))
    if existing:
        return str(existing[0]), True

    state = {"last_print": time.time(), "last_mb": 0}

    def progress_cb(current, total):
        now = time.time()
        if size_mb > 50 and total > 0 and now - state["last_print"] > 5:
            mb_d = current / 1024 / 1024
            mb_t = total / 1024 / 1024
            pct = 100 * current / total
            rate = (mb_d - state["last_mb"]) / (now - state["last_print"])
            print(f"      dl {mb_d:.0f}/{mb_t:.0f}MB ({pct:.0f}%) {rate:.1f}MB/s", flush=True)
            state["last_print"] = now
            state["last_mb"] = mb_d

    path = await client.download_media(msg, file=str(CACHE_DIR / prefix), progress_callback=progress_cb)
    return path, False


async def send_post(client, target, channel, msgs, max_size_mb, caption_override=None,
                    return_cached_paths=None, force_reupload=False):
    """Forward album/single-msg to target. Protected chat → download+reupload with cache.

    caption_override (Optional[str]): 若提供，強制走 download+reupload 路徑並用此
    字串作 caption 主體（保留 📎 原帖尾綴）。caller 通常是 caption_sanitize 流
    （native forward 改不了 caption，廣告會跟著轉走）。

    return_cached_paths (Optional[list]): 若提供（empty list），下載成功的本地路徑
    append 進去；caller 應在 send_file 完成後逐一 unlink（DUD 即時清理 cache 用）。
    None = 行為不變。Cache hit 也會 append（DUD 完成即視為 cache 不再需要）。

    force_reupload (bool): True 強制走 download+reupload 路徑（即使 caption_override
    為 None），用於 monitor_group.py 全強制 DUD 模式（萊斯 2026-05-11 設計）。
    """
    msgs.sort(key=lambda m: m.id)

    # caption_override 或 force_reupload 都 skip native forward；
    #   - caption_override：caption 要清洗，native 帶廣告
    #   - force_reupload：DUD 強制模式（隱藏來源 + 擬人化轉發行為）
    if caption_override is None and not force_reupload:
        try:
            await asyncio.wait_for(
                client.forward_messages(target, msgs),
                timeout=30.0,
            )
            return ("forwarded", len(msgs), 0)
        except ChatForwardsRestrictedError:
            pass
        except asyncio.TimeoutError:
            print(f"    ⏱️ send_post forward_messages timeout (>30s)")
            return ("error", 0, len(msgs))
        except Exception as e:
            print(f"    fwd err: {type(e).__name__}: {e}")
            return ("error", 0, len(msgs))

    # Download + reupload with persistent cache
    paths = []
    skipped = 0
    cached_count = 0
    for m in msgs:
        size_mb = (m.document.size / 1024 / 1024) if (m.document and m.document.size) else 0
        if size_mb > max_size_mb:
            print(f"    skip msg {m.id}: {size_mb:.0f}MB > --max-size {max_size_mb}MB")
            skipped += 1
            continue
        try:
            if size_mb > 50:
                print(f"    fetching {m.id} ({size_mb:.0f}MB)...", flush=True)
            p, was_cached = await download_cached(client, m, channel, size_mb)
            if p:
                paths.append(p)
                # DUD caller 收集 cache 路徑供 upload 後 unlink
                if return_cached_paths is not None:
                    return_cached_paths.append(p)
                if was_cached:
                    cached_count += 1
                    if size_mb > 50:
                        print(f"    cache hit {m.id}", flush=True)
                elif size_mb > 50:
                    print(f"    downloaded {m.id}", flush=True)
        except Exception as e:
            print(f"    dl fail {m.id}: {type(e).__name__}: {e}")
            skipped += 1

    if not paths:
        return ("failed", 0, len(msgs))

    # Caption with TG autolink (no markdown) — avoids two failure modes:
    #   1) `_[source: @x/N]_` gets eaten by md parser because `[]` reads as
    #      incomplete link syntax → literal underscores leak into rendered msg.
    #   2) Scraped post text often contains unbalanced `**` / `_` from truncation
    #      at 900 chars, which collapses the whole caption md parse.
    # TG server auto-detects https://t.me/... URLs as MessageEntityUrl regardless
    # of parse_mode, so plain text + URL renders as a clickable link cleanly.
    src_url = f"https://t.me/{channel}/{msgs[0].id}"
    body = ""
    src_msg_id = msgs[0].id
    if caption_override is not None:
        # caption_sanitize 路徑：用清洗後字串作 body，src 鎖第一條訊息
        body = caption_override[:900]
        src_msg_id = msgs[0].id
        src_url = f"https://t.me/{channel}/{src_msg_id}"
    else:
        for m in msgs:
            if m.text:
                body = m.text[:900]
                src_msg_id = m.id
                src_url = f"https://t.me/{channel}/{m.id}"
                break
    # 2026-05-15 caption-pick trace（萊斯回報 album body 漏抽 root cause 待定位）：
    # 每次 send_post 打一行 holder/body_len/msgs/gids，下一輪 album 來就能定位
    # 是 group_albums 拆錯、apply_filter 砍光 holder、還是 m.text raw 確實空。
    try:
        _ids = ",".join(str(m.id) for m in msgs)
        _gids = ",".join(str(m.grouped_id) for m in msgs)
        _tlens = ",".join(str(len(m.text or "")) for m in msgs)
        print(f"    caption_pick: src={src_msg_id} body_len={len(body)} "
              f"msgs=[{_ids}] gids=[{_gids}] text_lens=[{_tlens}]")
    except Exception:
        pass
    caption = (body + "\n\n" if body else "") + f"📎 原帖 @{channel}/{src_msg_id} · {src_url}"

    # ── HotspotMonitor delivery seam（flag guard，保命零感知）──
    from backend.vendor.group_monitor import delivery as _hm_delivery
    if _hm_delivery.has_sink() and paths:
        _src_id = msgs[0].id if msgs else None
        # HotspotMonitor extension: pass grouped_id+reply_to for sink-side post grouping (CLAUDE.md #6 sanctioned narrow exception)
        _first_msg = msgs[0] if msgs else None
        _grouped_id = getattr(_first_msg, "grouped_id", None) if _first_msg else None
        _reply_to = getattr(_first_msg, "reply_to", None) if _first_msg else None
        _reply_to_msg_id = getattr(_reply_to, "reply_to_msg_id", None) if _reply_to else None
        await _hm_delivery.deliver(
            list(paths), caption,
            {"channel": channel, "src_msg_id": _src_id, "kind": "post",
             "grouped_id": _grouped_id, "reply_to_msg_id": _reply_to_msg_id})
        return ("forwarded", len(paths), 0)
    # ── 原生 send_file（sink 未設＝live 行為不變）──

    # 2026-05-11 萊斯「人類慢慢上傳」spec: send_file timeout 180s→1200s，
    # 跨國 ~1MB/s 頻寬下 250MB 影片需 4-5 min，舊 180s = 中途強制中止永遠 fail。
    # wrapper 已拉長到 2700s 對齊。
    #
    # 2026-05-15 video attributes 透傳：
    #   裸 send_file 不會帶 DocumentAttributeVideo (duration/w/h/supports_streaming)，
    #   TG client 端會降級成 document → 黑縮圖 + 必須先下載才能播。
    #   修法：
    #     單檔路徑 → 從原 msg 抽 DocumentAttributeVideo 顯式 attributes= 透傳。
    #     album 路徑 → 依賴 hachoir 自動嗅探每個 file 的 metadata（已 pip install）。
    #   兩條路都加 supports_streaming=True 作 belt-and-suspenders。
    def _video_attrs(m):
        if not m.document:
            return None
        for a in m.document.attributes:
            if isinstance(a, DocumentAttributeVideo):
                # 強制 supports_streaming=True（即使源是 False，重傳也應可流式）
                return DocumentAttributeVideo(
                    duration=a.duration, w=a.w, h=a.h,
                    round_message=a.round_message,
                    supports_streaming=True,
                    nosound=a.nosound,
                )
        return None

    try:
        if len(paths) > 1:
            await asyncio.wait_for(
                client.send_file(target, paths, album=True, caption=caption,
                                 supports_streaming=True),
                timeout=1200.0,
            )
        else:
            attrs = _video_attrs(msgs[0])
            extra = {"attributes": [attrs]} if attrs else {}
            await asyncio.wait_for(
                client.send_file(target, paths[0], caption=caption,
                                 supports_streaming=True, **extra),
                timeout=1200.0,
            )
        if cached_count:
            print(f"    reuploaded × {len(paths)} ({cached_count} from cache)")
        return ("reuploaded", len(paths), skipped)
    except asyncio.TimeoutError:
        print(f"    ⏱️ send_file timeout (>1200s) — cache 已留檔下次可重試")
        return ("reupload_timeout", 0, len(msgs))
    except Exception as e:
        print(f"    reupload fail: {type(e).__name__}: {e}")
        return ("reupload_err", 0, len(msgs))


# =====================================================
# MAIN
# =====================================================

async def main():
    p = argparse.ArgumentParser()
    p.add_argument("keyword")
    p.add_argument("--limit", type=int, default=DEFAULT_LIMIT, help=f"posts to forward (default {DEFAULT_LIMIT})")
    p.add_argument("--to", type=int, default=DEFAULT_TARGET)
    p.add_argument("--kind", choices=["video", "image", "audio", "file"])
    p.add_argument("--nsfw-only", action="store_true")
    p.add_argument("--max-size", type=int, default=DEFAULT_MAX_REUPLOAD_MB,
                   help=f"max MB for download+reupload (default {DEFAULT_MAX_REUPLOAD_MB}MB = MTProto 2GB limit)")
    args = p.parse_args()

    n_candidates = args.limit * CANDIDATE_MULTIPLIER
    candidates = load_candidates(args.keyword, n_candidates, args.kind, args.nsfw_only)

    # Check if we need to auto-drill first (keyword still in Top 40 but no content_links)
    need_drill = False
    if not candidates:
        with sqlite3.connect(DB_PATH, timeout=30) as conn:
            in_hot = conn.execute(
                """SELECT 1 FROM trending_keywords
                   WHERE keyword=? AND fetched_at=(SELECT MAX(fetched_at) FROM trending_keywords)
                   LIMIT 1""",
                (args.keyword,),
            ).fetchone()
        if in_hot:
            need_drill = True
        else:
            filt = []
            if args.kind: filt.append(f"kind={args.kind}")
            if args.nsfw_only: filt.append("nsfw=1")
            print(f"「{args.keyword}」{' ' + ', '.join(filt) if filt else ''} — 無資料（該詞可能已退榜）")
            sys.exit(1)

    async with make_client() as client:
        # Inline drill if needed (keyword in Top 40 but DB empty)
        if need_drill:
            print(f"「{args.keyword}」尚未 drill，現在用同一 session 直接抓（約 30s）...", flush=True)
            from drill_keyword import lookup_s_id, drill
            s_id = await lookup_s_id(client, args.keyword)
            if s_id:
                await drill(client, args.keyword, s_id, pages=2)
                candidates = load_candidates(args.keyword, n_candidates, args.kind, args.nsfw_only)
            if not candidates:
                print(f"「{args.keyword}」 — drill 完仍無資料，跳過")
                return

        print(f"Pulling {len(candidates)} candidates for「{args.keyword}」, target limit={args.limit} posts...\n")

        try:
            target_entity, dialog_name, how = await resolve_push_target(
                client, args.to, DEFAULT_TARGET_NAME_HINT
            )
            print(f"Target: {dialog_name!r} (resolved by {how})\n")
        except Exception as e:
            print(f"Can't resolve target {args.to}: {e}")
            sys.exit(1)

        posts = await fetch_posts(client, candidates)
        if not posts:
            print("no accessible posts (all deleted/unreachable)")
            sys.exit(1)

        ranked = sorted(
            posts.items(),
            key=lambda kv: (-score_post(kv[1]), kv[0][0]),   # by score desc, then channel name for stable
        )
        picked = ranked[: args.limit]

        print(f"Ranked {len(posts)} posts, forwarding top {len(picked)}:")
        for i, ((channel, gid), msgs) in enumerate(picked, 1):
            label = post_label(msgs)
            sc = score_post(msgs)
            is_album = not isinstance(gid, tuple)
            print(f"  [{i}] @{channel:<20s}  score={sc}  {label} × {len(msgs)}  {'album' if is_album else 'solo'}")

        # Header
        await client.send_message(
            target_entity,
            f"🔍 **{args.keyword}** — 轉發 {len(picked)} 則（按混合/影/圖排序）",
            parse_mode="md", link_preview=False,
        )

        from fetch_discussion import (
            is_teaser,
            fetch_discussion_media,
            forward_discussion_to_target,
        )
        DISCUSSION_CACHE = _PROJECT_DIR / "data" / "discussion"

        stats = {"forwarded": 0, "reuploaded": 0, "failed": 0, "discussion_extra": 0}
        for (channel, gid), msgs in picked:
            result, ok, skipped = await send_post(client, target_entity, channel, msgs, args.max_size)
            label = post_label(msgs)
            if result == "forwarded":
                stats["forwarded"] += ok
                print(f"  @{channel}: {label} × {ok} forwarded ✓")
            elif result == "reuploaded":
                stats["reuploaded"] += ok
                stats["failed"] += skipped
                print(f"  @{channel}: {label} × {ok} reuploaded ✓  (skipped {skipped})")
            else:
                stats["failed"] += (len(msgs) - ok)
                print(f"  @{channel}: {result}")
            await asyncio.sleep(2.0)

            # Teaser signal pre-step: check if post text hints at 評論區 + has replies
            first = msgs[0] if msgs else None
            if first is None:
                continue
            text = first.text or ""
            teaser_hits = is_teaser(text)
            replies_n = getattr(getattr(first, "replies", None), "replies", 0) or 0
            if teaser_hits and replies_n > 0:
                print(f"    💬 teaser hit {teaser_hits} + replies={replies_n}, fetching discussion...")
                try:
                    r = await fetch_discussion_media(client, f"@{channel}", first.id, max_comments=30)
                    if r.get("error") or not r["comments"]:
                        print(f"    💬 no media in discussion ({r.get('error', 'empty')})")
                    else:
                        out_dir = DISCUSSION_CACHE / f"{channel}_{first.id}"
                        out = await forward_discussion_to_target(
                            client, f"@{channel}", first.id, target_entity, r, out_dir,
                            keyword=args.keyword,
                        )
                        stats["discussion_extra"] += out["forwarded"]
                        print(f"    💬 discussion +{out['forwarded']} media ({out['groups']} groups)")
                except Exception as e:
                    print(f"    💬 discussion fetch err: {type(e).__name__}: {e}")
                await asyncio.sleep(2.0)

        print(
            f"\nDone. fwd={stats['forwarded']}  reup={stats['reuploaded']}  "
            f"fail={stats['failed']}  discussion={stats['discussion_extra']}"
        )


if __name__ == "__main__":
    enter_cooperative("forward_keyword.py", timeout=1500)
    asyncio.run(main())
