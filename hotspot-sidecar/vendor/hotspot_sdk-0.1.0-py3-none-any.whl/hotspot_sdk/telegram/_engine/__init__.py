"""Vendor package: group-monitor engine modules.

Vendored byte-identical from ~/group-monitor (live launchd source, untouched).
The engine modules use bare imports (import db, from config import CFG, etc.)
designed to run with ~/group-monitor/ on sys.path.  This __init__.py injects
the vendor dir into sys.path so those bare names resolve correctly when imported
as backend.vendor.group_monitor.* — without touching vendored source bytes.
"""
from __future__ import annotations
import sys
from pathlib import Path

_VENDOR_DIR = str(Path(__file__).resolve().parent)
if _VENDOR_DIR not in sys.path:
    sys.path.insert(0, _VENDOR_DIR)
