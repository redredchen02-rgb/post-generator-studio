"""group-monitor Telethon session file lock.

Single physical `.session` file is shared by monitor_group / forward_keyword /
fetch_discussion / fetch_bot_media. Two concurrent Telethon clients on the same
session can break auth state (server sees "another login" and kicks one side).

Note: cooperative-yield primitives (request_yield/check_yield/release_and_wait_yield_gone)
are inherited from the nsfw-keyword-monitor sibling project. group-monitor has
no long-running counterpart that consumes the yield flag, so those primitives
are currently dormant — kept for parity in case a long-lived scraper is added later.

Usage at top of any Telethon script:

    from session_lock import acquire_session_lock
    lock = acquire_session_lock()   # exits(5) if another process holds it

Releases automatically on process exit (file lock is by OS, not explicit close).
"""
import atexit
import errno
import os
import sys
import time
from pathlib import Path

# ── [HotspotMonitor win-fcntl-portable patch] 跨平台獨佔檔鎖 ──
# 原 `import fcntl` 在 Windows 直接 ModuleNotFoundError（fcntl Unix-only）→ TG worker
# 一 import session_lock 就炸 → Win 的 TG 監控整個跑不了。改平台分派：
#   Unix    → fcntl.flock（advisory，whole-file）
#   Windows → msvcrt.locking（鎖一個高 offset 哨兵 byte，避開 holder text 區，
#             免 mandatory range lock 擋住別 process 讀 holder 診斷字串）
# 進程死亡 → OS 自動釋放（兩平台皆然），與原 flock 語義一致。
_LOCK_SENTINEL_OFFSET = 1 << 20  # 1MB：遠超 holder text(~40B)
if sys.platform == "win32":
    import msvcrt

    def _try_lock_ex(fh) -> bool:
        """非阻塞取得獨佔鎖；成功 True，已被佔 False。"""
        try:
            fh.seek(_LOCK_SENTINEL_OFFSET)
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False

    def _unlock(fh) -> None:
        try:
            fh.seek(_LOCK_SENTINEL_OFFSET)
            msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
else:
    import fcntl

    def _try_lock_ex(fh) -> bool:
        """非阻塞取得獨佔鎖；成功 True，已被佔 False。"""
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError as e:
            if e.errno in (errno.EAGAIN, errno.EACCES):
                return False
            raise

    def _unlock(fh) -> None:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass

PROJECT_DIR = Path(__file__).resolve().parent
LOCK_PATH = PROJECT_DIR / "sessions" / ".session.lock"
YIELD_FLAG_PATH = PROJECT_DIR / "sessions" / ".yield_request"


def request_yield(requester: str):
    """Forward-side: signal to current lock holder (bot_scraper) that someone wants session."""
    YIELD_FLAG_PATH.parent.mkdir(parents=True, exist_ok=True)
    YIELD_FLAG_PATH.write_text(f"pid={os.getpid()} script={requester} ts={int(time.time())}\n", encoding="utf-8")


def clear_yield_request():
    """Forward-side: clear the flag once lock is acquired (so bot_scraper can reclaim after)."""
    try:
        YIELD_FLAG_PATH.unlink()
    except FileNotFoundError:
        pass


def check_yield() -> bool:
    """Bot_scraper-side: is someone waiting for the session? Call at safe yield points."""
    return YIELD_FLAG_PATH.exists()


def release_and_wait_yield_gone(fh, max_wait_seconds: int = 900, poll_seconds: float = 2.0) -> bool:
    """Bot_scraper-side: at a yield point, release flock and poll until yield requester finishes.

    Returns True if yield_request cleared (forward done), False if timed out (reacquire anyway).
    Caller must call `reacquire(fh)` afterward to get flock back.
    """
    _unlock(fh)
    start = time.time()
    while time.time() - start < max_wait_seconds:
        if not YIELD_FLAG_PATH.exists():
            return True
        time.sleep(poll_seconds)
    return False


def reacquire(fh, max_wait_seconds: int = 60) -> bool:
    """Bot_scraper-side: after yielding, re-acquire the flock before continuing."""
    start = time.time()
    while time.time() - start < max_wait_seconds:
        if _try_lock_ex(fh):
            return True
        time.sleep(1)
    return False


def _probe_lock_busy() -> bool:
    """Non-blocking check: is another process currently holding the session lock?

    Returns True if busy (so caller should write a yield flag to request release).
    """
    if not LOCK_PATH.exists():
        return False
    try:
        with open(str(LOCK_PATH), "a+") as fh:
            if _try_lock_ex(fh):
                _unlock(fh)
                return False
            return True
    except Exception:
        return False


def enter_cooperative(script_name: str, *, timeout: int = 1500):
    """Cooperative session acquisition for all Telethon scripts that may race
    against the long-running bot_scraper cycle.

    If the lock is busy, write `.yield_request` flag so bot_scraper releases
    at its next yield point, then wait up to `timeout` seconds for the flock.
    On acquire, clear the flag so bot_scraper can reclaim after.

    Skips lock entirely when `--help` / `-h` is in argv so users can discover
    CLI options without fighting the bot_scraper cycle.

    Use this instead of raw `acquire_session_lock(...)` for short-lived scripts
    (digest, fetch_discussion, forward_keyword, refresh_channel_titles).
    """
    if any(h in sys.argv for h in ("-h", "--help")):
        return None

    busy = _probe_lock_busy()
    if busy:
        request_yield(script_name)
        # Ensure the flag is removed on any exit path (success, timeout exit(5),
        # or unexpected crash) so bot_scraper doesn't mis-yield on the next cycle.
        atexit.register(clear_yield_request)
        print(
            f"[session_lock] session busy — yield request sent by {script_name}, waiting...",
            flush=True,
        )

    start = time.time()
    fh = acquire_session_lock(script_name=script_name, wait=True, timeout=timeout)
    clear_yield_request()
    waited = int(time.time() - start)
    if waited > 2:
        print(f"[session_lock] waited {waited}s for session\n", flush=True)
    return fh


def acquire_session_lock(*, script_name=None, wait=False, timeout=30):
    """Acquire exclusive flock on sessions/.session.lock.

    wait=False (default): exit immediately if lock held.
    wait=True: poll up to `timeout` seconds, then exit.
    """
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Use "r+" / create-if-missing; don't truncate before locking — otherwise
    # a failed locker clobbers the holder info.
    if not LOCK_PATH.exists():
        LOCK_PATH.touch()
    fh = open(LOCK_PATH, "r+")
    script = script_name or os.path.basename(sys.argv[0] or "unknown")

    start = time.time()
    while True:
        if _try_lock_ex(fh):
            break
        if not wait or (time.time() - start) > timeout:
            # Read holder info for helpful error
            try:
                holder = LOCK_PATH.read_text(encoding="utf-8").strip() or "unknown"
            except Exception:
                holder = "unknown"
            print(
                f"[session_lock] another script holds the session lock: {holder}\n"
                f"  → this script ({script}) exits to avoid auth conflict",
                file=sys.stderr,
                flush=True,
            )
            sys.exit(5)
        time.sleep(1)

    # Record holder
    fh.seek(0)
    fh.truncate()
    fh.write(f"pid={os.getpid()} script={script} acquired={int(time.time())}\n")
    fh.flush()

    # Hold open handle until process exits; keep it alive via ref
    def _release():
        try:
            _unlock(fh)
            fh.close()
        except Exception:
            pass

    atexit.register(_release)
    return fh


if __name__ == "__main__":
    # Manual probe: show current holder (if any)
    if LOCK_PATH.exists():
        print(LOCK_PATH.read_text(encoding="utf-8") or "(empty lock file)")
    else:
        print("(no lock file)")
