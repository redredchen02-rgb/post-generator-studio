"""Config loader: reads ~/.openclaw/workspace/group-monitor/config.json.

All scripts (monitor_group, forward_keyword, fetch_discussion, fetch_bot_media)
should use this instead of hardcoding target chat IDs / service words / etc.

Usage:
    from config import CFG
    target = CFG.push_chat_id            # int
    target_name = CFG.push_chat_name     # str
    service_words = CFG.service_words    # set[str]
"""
import json
import os
from pathlib import Path

WORKSPACE = Path.home() / ".openclaw/workspace/group-monitor"
CONFIG_PATH = WORKSPACE / "config.json"


DEFAULTS = {
    "push_chat_id": 0,                      # MUST be set in config.json (INSTALL.md Step 8). 0 = unset → fails safe, never auto-routes anywhere
    "push_chat_name": "",
    "push_chat_name_hint": "",              # substring used for dialog lookup (set to your push chat name)
    "alert_thresholds": {
        "rank_jump": 5,
        "rank_drop": 5,                     # new 2026-04-21: push 📉 on rank drop ≥ N
        "new_entry_top": 40,                # new entries alert up to top N (was 10)
    },
    "source_channels": ["@dgjum"],
    "media_sample_posts_per_channel": 3,
    "scrape": {
        "sample_keywords": 40,              # drill all 40 trending (was 10 — caused rank 11-40 blind spot)
        "pages_per_keyword": 2,
        "drill_dedup_hours": 6,             # tail (rank > top_n) dedup window
        "always_drill_top_n": 5,            # "top N treated as head tier" — now with shorter dedup, not dedup-bypass
        "top_n_dedup_hours": 4,             # head tier dedup window (2026-04-21: was bypass, caused大杨嫂 24h drill 19× 37% 重複)
        "drill_adaptive": {                 # 2026-04-21 phase 2: adjust dedup per-keyword based on past drill productivity
            "enabled": True,
            "hot_threshold": 10,            # avg new_count ≥ this → halve dedup (keyword producing lots)
            "cold_threshold": 3,            # avg new_count < this → double dedup (keyword stagnating)
            "window_count": 2,              # use last N drill_stats rows for averaging
        },
        "watch_keywords": [],               # 萊斯 in-focus keywords — always drill if on board
        "filter_sample_keywords": 2,        # [F] kind/sort filter drill applies to top N
        "enable_yield": True,               # cooperative yield: bot_scraper releases flock for forward/digest
        "bot_scrape_timeout_s": 2400,       # wrap subprocess timeout for bot_scraper.py
        "discussion_sweep": {               # 2026-04-21 auto-sweep teaser posts per cycle
            "enabled": True,
            "hours": 1,                     # only scan content_links fetched within last N hours
            "probe_limit": 15,              # max posts to get_messages probe
            "max_fetch": 5,                 # max posts to actually fetch discussion on
            "timeout_s": 300,               # subprocess wrap timeout
        },
        "interest_categories": [
            "成人内容", "主播直播", "影视资源",
            "资源分享", "二次元动漫", "情感交流",
        ],
    },
    "service_words": [
        "極搜", "极搜", "jisou", "Jisou", "JISOU",
        "熱搜", "热搜", "熱搜榜", "热搜榜",
        "榜", "榜單", "榜单", "排行", "排行榜",
        "熱點", "热点", "今日熱點", "今日热点",
        "最新", "新進", "新进", "diff", "Diff",
        "看熱搜", "看熱搜榜", "看榜", "看極搜",
    ],
    "forward": {
        "default_limit": 3,
        "default_max_size_mb": 2000,          # MTProto 2GB; TG Premium can go 4096
        "candidate_multiplier": 10,
        "album_window": 10,
    },
}


def _deep_merge(base, override):
    """Override dict values in base. Missing keys in override keep base default."""
    out = dict(base)
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(base[k], v)
        else:
            out[k] = v
    return out


def _validate(data):
    """Light-weight shape/range validation — no pydantic dependency.

    Returns list of error messages; empty list means valid. Only flags things
    that would silently break runtime (wrong type, out-of-range threshold,
    missing critical key). Users can still add their own keys freely.
    """
    errors = []

    def check(path, value, expected_type, predicate=None, predicate_desc=""):
        if not isinstance(value, expected_type):
            errors.append(f"{path}: expected {expected_type.__name__}, got {type(value).__name__}")
            return
        if predicate and not predicate(value):
            errors.append(f"{path}: {predicate_desc} (got {value!r})")

    check("push_chat_id", data.get("push_chat_id"), int,
          lambda v: v != 0, "must be non-zero")

    at = data.get("alert_thresholds", {})
    if not isinstance(at, dict):
        errors.append(f"alert_thresholds: expected dict, got {type(at).__name__}")
    else:
        for k in ("rank_jump", "rank_drop", "new_entry_top"):
            if k in at:
                check(f"alert_thresholds.{k}", at[k], int,
                      lambda v: 1 <= v <= 40, "must be 1-40")

    sc = data.get("scrape", {})
    if not isinstance(sc, dict):
        errors.append(f"scrape: expected dict, got {type(sc).__name__}")
    else:
        if "sample_keywords" in sc:
            check("scrape.sample_keywords", sc["sample_keywords"], int,
                  lambda v: 1 <= v <= 40, "must be 1-40 (40 recommended, <40 reintroduces rank 11-40 blind spot)")
        if "pages_per_keyword" in sc:
            check("scrape.pages_per_keyword", sc["pages_per_keyword"], int,
                  lambda v: 1 <= v <= 10, "must be 1-10")
        if "drill_dedup_hours" in sc:
            check("scrape.drill_dedup_hours", sc["drill_dedup_hours"], int,
                  lambda v: 0 <= v <= 72, "must be 0-72")
        if "top_n_dedup_hours" in sc:
            check("scrape.top_n_dedup_hours", sc["top_n_dedup_hours"], int,
                  lambda v: 0 <= v <= 48, "must be 0-48")
        da = sc.get("drill_adaptive", {})
        if da and not isinstance(da, dict):
            errors.append(f"scrape.drill_adaptive: expected dict, got {type(da).__name__}")
        elif da:
            if "enabled" in da:
                check("scrape.drill_adaptive.enabled", da["enabled"], bool)
            if "hot_threshold" in da:
                check("scrape.drill_adaptive.hot_threshold", da["hot_threshold"], int,
                      lambda v: v > 0, "must be positive")
            if "cold_threshold" in da:
                check("scrape.drill_adaptive.cold_threshold", da["cold_threshold"], int,
                      lambda v: v >= 0, "must be non-negative")
            if "window_count" in da:
                check("scrape.drill_adaptive.window_count", da["window_count"], int,
                      lambda v: 1 <= v <= 10, "must be 1-10")
        if "enable_yield" in sc:
            check("scrape.enable_yield", sc["enable_yield"], bool)
        ds = sc.get("discussion_sweep", {})
        if ds and not isinstance(ds, dict):
            errors.append(f"scrape.discussion_sweep: expected dict, got {type(ds).__name__}")
        elif ds:
            if "enabled" in ds:
                check("scrape.discussion_sweep.enabled", ds["enabled"], bool)
            if "probe_limit" in ds:
                check("scrape.discussion_sweep.probe_limit", ds["probe_limit"], int,
                      lambda v: 1 <= v <= 100, "must be 1-100")
            if "max_fetch" in ds:
                check("scrape.discussion_sweep.max_fetch", ds["max_fetch"], int,
                      lambda v: 1 <= v <= 50, "must be 1-50")

    if "service_words" in data:
        sw = data["service_words"]
        if not isinstance(sw, list) or not all(isinstance(s, str) for s in sw):
            errors.append("service_words: expected list of strings")

    return errors


class _Config:
    def __init__(self):
        self._data = dict(DEFAULTS)
        if CONFIG_PATH.exists():
            try:
                loaded = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                self._data = _deep_merge(DEFAULTS, loaded)
            except Exception as e:
                print(f"[config] WARN failed to load {CONFIG_PATH}: {e}", flush=True)
        else:
            # Write defaults so users can edit
            WORKSPACE.mkdir(parents=True, exist_ok=True)
            CONFIG_PATH.write_text(json.dumps(DEFAULTS, indent=2, ensure_ascii=False), encoding="utf-8")

        # Shape/range validation — print warnings but don't hard-fail so a stale
        # install can still boot; user sees explicit pointer to what to fix.
        errs = _validate(self._data)
        if errs:
            print(f"[config] WARN {CONFIG_PATH} has {len(errs)} schema issue(s):", flush=True)
            for e in errs:
                print(f"  - {e}", flush=True)

    # Top-level accessors
    @property
    def push_chat_id(self): return self._data["push_chat_id"]
    @property
    def push_chat_name(self): return self._data.get("push_chat_name", "")
    @property
    def push_chat_name_hint(self): return self._data.get("push_chat_name_hint", "")
    @property
    def alert_thresholds(self): return self._data["alert_thresholds"]
    @property
    def source_channels(self): return self._data["source_channels"]
    @property
    def media_sample_posts_per_channel(self): return self._data["media_sample_posts_per_channel"]
    @property
    def scrape(self): return self._data["scrape"]
    @property
    def service_words(self): return set(self._data.get("service_words", DEFAULTS["service_words"]))
    @property
    def forward(self): return self._data.get("forward", DEFAULTS["forward"])

    def raw(self): return dict(self._data)


CFG = _Config()
