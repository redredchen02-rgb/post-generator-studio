"""藍鏈 category 抓取 — bot deep-link teaser 解析 + /start 觸發 + 媒體收回 + 廣告過濾。

業務流（@ntrqwq → @bbcaiuu_bot 是典範）：
  1. 頻道 teaser 帖文裡有 MessageEntityTextUrl 蓝色字 → t.me/<bot>?start=<token>
  2. user 點蓝字 → bot 收 /start <token> → 私信回媒體（album 或 single）
  3. bot 經常前後夾擊引流廣告（text-only + button → 跳另一個 bot）

我們做的：
  • 解析 teaser entities → (bot, token)
  • 用監控帳號發 /start <token> 給 bot
  • iter_messages 收回，quiet-timeout 8s 視為 done
  • 過濾廣告（text-only + bot link button）
  • forward 真媒體到 push target，header reply 主帖 anchor
  • DeleteHistoryRequest 清痕跡，dialog 不污染

API：
  • parse_bot_deep_link(msg) → (bot, token) | None
  • async fetch_bot_media(client, bot, token) → {media, ads, error}
  • async forward_bot_media_to_target(client, target, channel, post_id, bot_result, reply_to_msg_id)
"""
import asyncio
import os
import re
import tempfile
import time
from pathlib import Path

from telethon.errors import (
    ChatForwardsRestrictedError,
    ChatWriteForbiddenError,
    FloodWaitError,
    UserBannedInChannelError,
)
from telethon.tl.functions.messages import DeleteHistoryRequest, GetDiscussionMessageRequest
from telethon.tl.types import DocumentAttributeVideo


DEEP_LINK_RE = re.compile(r"https?://t\.me/([a-zA-Z0-9_]+)\?start=([a-zA-Z0-9_-]+)")

# 2026-05-15「评论区口令型」typical flow（吃瓜大妈 @chiguadama → @dianbao1bot）：
#   1. 主帖 caption 含「评论区发送口令：`<token>` 获取视频」（token 是中文短词）
#   2. 监控在 disc 发送 token 字符串 + reply_to=disc 中主帖 forwarded copy id
#   3. disc admin bot (实际就是 dianbao1bot user 身份) 0.5s 内 reply quote msg
#      + inline button url = t.me/<bot>?start=<hash>（hash 是 8 字符短串）
#   4. 解析 button URL → 复用 fetch_bot_media 走 /start <hash> 拿资源
#   5. cleanup：撤回自己 disc 发言 + DeleteHistoryRequest 清 bot 私聊
COMMENT_TOKEN_BOT_REPLY_POLL_S = 5.0  # disc bot 实测 0.5s reply，5s 足够兜底

# 2026-05-15 萊斯：bot 媒体并发 download（人类 TG client 本就多线程并发 chunk）。
# 4 路平衡帶寬 + 不打爆 + human-like（TG app 默认 4 并发）；大视频多时显著缩 wall-clock。
DOWNLOAD_CONCURRENCY = 4

# [HotspotMonitor bot-teaser-resume patch] 大檔 bot-media 下載解耦+續傳常數
# （big-lane Phase D 適配 HM local-sink）。
# request_size 須為 4KB 倍數且整除 1MB（telethon iter_download 限制）；512KB = 斷點對齊邊界。
DOWNLOAD_REQUEST_SIZE = 512 * 1024
# 單檔 stall 上限：超過此秒數無新 chunk 即視為卡死 → 中止本輪保 .partial 供下輪續。
# 防一個半開連線/壞檔吊死整輪（原 download_media 無 timeout，gather 等全部 → 整 cycle 卡死的元兇）。
BOT_DL_FILE_TIMEOUT_S = int(os.environ.get("HOTSPOT_BOT_DL_FILE_TIMEOUT_S", "120"))


async def _download_resumable(client, media, dest_stem, *, ext="",
                              file_timeout_s=BOT_DL_FILE_TIMEOUT_S,
                              total_size=0, req_size=DOWNLOAD_REQUEST_SIZE):
    """跨 cycle 斷點續傳下載（port 自上游 forward_keyword.download_cached）。

    dest_stem: 不含副檔名的目標路徑；本函式管理 `<stem>.partial` 與完成檔 `<stem><ext>`。
    回完成檔路徑 str；未下完回 None（保留非空 .partial 供下輪續）。
    file_timeout_s: 單 chunk stall 上限（無新 chunk 超時即中止本輪，非整檔總時長）。

    斷點語義：`.partial` 已有 bytes → 從 512KB 對齊下取整 offset 續傳（丟末尾不完整塊保證對齊）。
    SIGTERM(CancelledError) → 保 .partial 並向上傳播（讓 monitor_group 乾淨斷線），下輪續。
    """
    dest_stem = Path(dest_stem)
    final_path = dest_stem.parent / f"{dest_stem.name}{ext}"
    if final_path.exists():
        return str(final_path)  # cache-hit：完成檔已在，不重下

    dest_stem.parent.mkdir(parents=True, exist_ok=True)
    partial = dest_stem.parent / f"{dest_stem.name}.partial"

    offset = 0
    if partial.exists():
        cur = partial.stat().st_size
        offset = (cur // req_size) * req_size
        if offset != cur:
            with open(partial, "r+b") as _f:
                _f.truncate(offset)
        if offset > 0:
            print(f"    ↻ resume bot-media {dest_stem.name} from {offset/1024/1024:.0f}MB", flush=True)

    def _keep_or_clean():
        # 0-byte partial（未吐任何 chunk）無續傳價值，刪掉避免污染 cache；有內容則保留。
        try:
            if partial.exists() and partial.stat().st_size == 0:
                partial.unlink()
        except OSError:
            pass

    agen = client.iter_download(media, offset=offset, request_size=req_size)
    done = offset
    last_print = time.time()
    try:
        with open(partial, "ab" if offset else "wb") as f:
            while True:
                try:
                    chunk = await asyncio.wait_for(agen.__anext__(), timeout=file_timeout_s)
                except StopAsyncIteration:
                    break
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                now = time.time()
                if total_size > 50 * 1024 * 1024 and now - last_print > 5:
                    print(f"      dl {done/1024/1024:.0f}/{total_size/1024/1024:.0f}MB "
                          f"({100 * done / total_size:.0f}%)", flush=True)
                    last_print = now
    except asyncio.TimeoutError:
        print(f"    ⏱️ bot-media {dest_stem.name} stall >{file_timeout_s}s — 本輪中止保 partial", flush=True)
        _keep_or_clean()
        return None
    except Exception as e:  # noqa: BLE001 — 任何下載例外都放棄本輪、保 partial 續下輪
        print(f"    ❌ bot-media {dest_stem.name} download fail: {type(e).__name__}: {e}", flush=True)
        _keep_or_clean()
        return None
    except BaseException:  # CancelledError(SIGTERM) → 保 partial 並傳播
        _keep_or_clean()
        raise
    finally:
        aclose = getattr(agen, "aclose", None)
        if aclose is not None:
            try:
                await aclose()
            except Exception:
                pass

    os.rename(str(partial), str(final_path))
    return str(final_path)

# Per-process cache of resolved bot entities. Avoids repeated ResolveUsername
# RPCs (a hard-rate-limited API; one prior incident hit FloodWait 4249s).
# Lifetime = process lifetime, which matches a single launchd cycle.
_BOT_ENTITY_CACHE: dict = {}


def parse_bot_deep_link(msg):
    """Parse first bot deep-link from msg.entities. Returns (bot_username, token) or None.

    Looks at MessageEntityTextUrl (anchor 蓝字 hyperlink). Plain-text URLs in body
    are ignored — teaser convention is always anchor 「点击蓝色字体观看」.
    """
    if not msg or not msg.entities:
        return None
    for e in msg.entities:
        if type(e).__name__ != "MessageEntityTextUrl":
            continue
        url = getattr(e, "url", None)
        if not url:
            continue
        m = DEEP_LINK_RE.match(url)
        if m:
            return m.group(1), m.group(2)
    return None


def _is_ad_reply(msg):
    """Bot 端引流廣告判定：text-only 且有 button URL 指向另一個 t.me/<bot>?start=。"""
    if msg.media:
        return False
    if not msg.buttons:
        return False
    for row in msg.buttons:
        for btn in row:
            url = getattr(btn, "url", None)
            if url and "t.me/" in url:
                return True
    return False


async def fetch_bot_media(client, bot_username, token, collect_window_s=8, max_wait_s=30):
    """Send /start <token> to bot, collect reply media until quiet for collect_window_s.

    Returns {
        "media": [list of media-bearing reply msgs],
        "ads":   [list of ad reply msgs],
        "all":   [all replies in order],
        "elapsed": float,
        "error": str or None,
    }
    """
    bot_ent = _BOT_ENTITY_CACHE.get(bot_username)
    if bot_ent is None:
        try:
            bot_ent = await client.get_entity(bot_username)
        except Exception as e:
            return {"media": [], "ads": [], "all": [], "elapsed": 0,
                    "error": f"resolve {bot_username}: {type(e).__name__}: {e}"}
        _BOT_ENTITY_CACHE[bot_username] = bot_ent

    cmd = f"/start {token}"
    try:
        sent = await client.send_message(bot_ent, cmd)
    except FloodWaitError as e:
        return {"media": [], "ads": [], "all": [], "elapsed": 0,
                "error": f"FloodWait {e.seconds}s on send /start"}
    except Exception as e:
        return {"media": [], "ads": [], "all": [], "elapsed": 0,
                "error": f"send /start: {type(e).__name__}: {e}"}

    t0 = time.time()
    seen_ids = {sent.id}
    replies = []
    last_change = t0

    while True:
        elapsed = time.time() - t0
        if elapsed > max_wait_s:
            break
        if replies and (time.time() - last_change) > collect_window_s:
            break
        await asyncio.sleep(1.5)
        try:
            new = []
            async for m in client.iter_messages(bot_ent, limit=20):
                if m.id in seen_ids or m.out:
                    continue
                seen_ids.add(m.id)
                new.append(m)
        except Exception as e:
            return {"media": [], "ads": [], "all": replies, "elapsed": time.time() - t0,
                    "error": f"iter_messages: {type(e).__name__}: {e}"}
        if new:
            new.sort(key=lambda m: m.id)
            replies.extend(new)
            last_change = time.time()

    media = [m for m in replies if m.media and not _is_ad_reply(m)]
    ads = [m for m in replies if _is_ad_reply(m)]

    return {
        "media": media,
        "ads": ads,
        "all": replies,
        "elapsed": time.time() - t0,
        "error": None,
        "bot_entity": bot_ent,
    }


async def cleanup_bot_history(client, bot_entity):
    """Delete chat history with bot to keep the bot-account dialog list clean."""
    try:
        await client(DeleteHistoryRequest(peer=bot_entity, max_id=0, just_clear=False, revoke=True))
        return True
    except Exception:
        return False


async def fetch_via_comment_token(client, channel, anchor_msg_id, token,
                                  poll_window_s=COMMENT_TOKEN_BOT_REPLY_POLL_S,
                                  fetch_collect_window_s=8, fetch_max_wait_s=30,
                                  cleanup_own_send=True):
    """评论区口令 → disc bot reply → bot deep-link → 拉资源 全链路。

    参数：
      channel: 源 channel @username or InputPeer（用 GetDiscussionMessageRequest 拿 thread）
      anchor_msg_id: 主帖在源 channel 的 msg id (e.g. 14273)
      token: 主帖 caption 抽出来的中文 token (e.g. '碎叫叫')
      poll_window_s: 等 disc bot reply 的窗口，默认 5s
      cleanup_own_send: 是否撤回自己在 disc 发的 token msg（默认 True 减少 footprint）

    返回（基本与 fetch_bot_media 对齐）：
      {
        "media": [...], "ads": [...], "all": [...],
        "bot_username": str|None, "token_hash": str|None,
        "bot_entity": entity|None, "error": str|None,
        "disc_msg_id": int|None,  # disc 中主帖 forwarded copy
        "disc_bot_reply_id": int|None,  # disc 中 bot 那条 quote reply id
      }
    """
    result = {
        "media": [], "ads": [], "all": [],
        "bot_username": None, "token_hash": None,
        "bot_entity": None, "disc_msg_id": None, "disc_bot_reply_id": None,
        "error": None,
        "banned": False,  # [HotspotMonitor ban-detect patch] 帳號在該群被禁言
    }

    # Step 1: resolve disc thread + 主帖 forwarded copy
    try:
        disc_resp = await client(GetDiscussionMessageRequest(peer=channel, msg_id=anchor_msg_id))
    except Exception as e:
        result["error"] = f"GetDiscussion: {type(e).__name__}: {e}"
        return result
    if not getattr(disc_resp, "messages", None) or not getattr(disc_resp, "chats", None):
        result["error"] = "no disc thread"
        return result
    disc_entity = disc_resp.chats[0]
    disc_msg_id = disc_resp.messages[0].id
    result["disc_msg_id"] = disc_msg_id

    # Step 2: send token to disc，reply_to=主帖 forwarded copy
    try:
        sent = await client.send_message(disc_entity, token, reply_to=disc_msg_id)
    except FloodWaitError as e:
        result["error"] = f"disc-send FloodWait {e.seconds}s"
        return result
    # [HotspotMonitor ban-detect patch] 帳號在口令群被禁言 → 標記 banned=True
    # 口令群本質是開放評論觸發口令，"只准管理員發言" 的誤報不存在，踩到即真禁言
    except (ChatWriteForbiddenError, UserBannedInChannelError) as e:
        result["banned"] = True
        result["error"] = f"disc-send banned: {type(e).__name__}"
        return result
    # [HotspotMonitor ban-detect patch] end
    except Exception as e:
        result["error"] = f"disc-send: {type(e).__name__}: {e}"
        return result

    # Step 3: poll disc 找 bot reply（含 button URL 指向 deep-link）
    bot_reply = None
    button_url = None
    deadline = time.time() + poll_window_s
    while time.time() < deadline:
        await asyncio.sleep(0.5)
        try:
            async for m in client.iter_messages(disc_entity, min_id=sent.id, limit=10):
                if m.id == sent.id or m.out:
                    continue
                if not m.buttons:
                    continue
                for row in m.buttons:
                    for b in row:
                        u = getattr(b, "url", None)
                        if u and DEEP_LINK_RE.match(u):
                            bot_reply = m
                            button_url = u
                            break
                    if bot_reply:
                        break
                if bot_reply:
                    break
        except Exception:
            pass  # transient iter err — 继续 poll
        if bot_reply:
            break

    # Step 4: cleanup 自己在 disc 发言（best-effort，避免污染 disc）
    if cleanup_own_send:
        try:
            await client.delete_messages(disc_entity, [sent.id], revoke=True)
        except Exception:
            pass

    if not bot_reply or not button_url:
        result["error"] = "no disc bot reply with deep-link in poll window"
        return result

    result["disc_bot_reply_id"] = bot_reply.id

    # Step 5: parse deep-link → bot_username + token_hash
    m = DEEP_LINK_RE.match(button_url)
    if not m:
        result["error"] = f"deep-link parse failed: {button_url}"
        return result
    bot_username = m.group(1)
    token_hash = m.group(2)
    result["bot_username"] = bot_username
    result["token_hash"] = token_hash

    # Step 6: 复用现有 fetch_bot_media 走 /start <hash>
    fetch_r = await fetch_bot_media(
        client, bot_username, token_hash,
        collect_window_s=fetch_collect_window_s,
        max_wait_s=fetch_max_wait_s,
    )
    result["media"] = fetch_r.get("media", [])
    result["ads"] = fetch_r.get("ads", [])
    result["all"] = fetch_r.get("all", [])
    result["bot_entity"] = fetch_r.get("bot_entity")
    if fetch_r.get("error"):
        result["error"] = f"fetch_bot_media: {fetch_r['error']}"
    return result


async def forward_bot_media_to_target(client, target, channel, post_id, bot_result,
                                      bot_username, token, reply_to_msg_id=None,
                                      is_reprobe=False, max_size_mb=4096,
                                      post_caption=None):
    """Forward bot-fetched media to target chat, reply to anchor (主帖 in push chat).

    caption（2026-05-15 萊斯：发到群必须带主帖完整文案，不要内部 debug 文案）：
      • 第一组 album：{主帖正文(已 strip 口令尾巴)}\\n\\n📎 原帖 @ch/id · url
      • 后续组：只 📎 原帖尾缀
      • 纯 plain text（不传 parse_mode）—— 主帖含 # / emoji / backtick，
        md parse 会炸；TG server 自动识别 t.me URL 为链接（对齐 send_post）
      • DUD（download+reupload），非 native forward —— 群里不出现「轉發自」分享标签

    max_size_mb: 单 file size cap。2026-05-15 萊斯决策「不限制档案大小，TG 最大
    也只能傳 4G」→ default 拉到 4096MB（即 TG 上限，等同不限）。保留参数仅作未来
    可调 escape hatch；大文件跨国 download 慢（~1MB/s）会拖 cycle，萊斯已接受。
    """
    media = bot_result.get("media", [])
    if not media:
        return {"forwarded": 0, "groups": 0}

    ch_clean = channel.lstrip("@")
    src_url = f"https://t.me/{ch_clean}/{post_id}"
    body = (post_caption or "").strip()[:900]
    full_caption = (body + "\n\n" if body else "") + f"📎 原帖 @{ch_clean}/{post_id} · {src_url}"
    tail_caption = f"📎 原帖 @{ch_clean}/{post_id} · {src_url}"
    is_first_group = True  # 仅第一组 album 带完整主帖文案，后续组只 📎 尾缀

    # Group by grouped_id (album)
    groups = {}
    for m in media:
        key = m.grouped_id if m.grouped_id else ("solo", m.id)
        groups.setdefault(key, []).append(m)

    # 2026-05-15 video attributes 透傳（萊斯回報 bot 拉来的视频被 TG client 渲染成
    # document 不能 inline 播放，跟之前 14274 album reupload bug 同源）：
    # 单档路径必须显式 attributes=[DocumentAttributeVideo(...)] + supports_streaming=True
    # 否则 TG client 端降級 document → 黑縮圖 + 必须先下載才能看。
    # album 路径靠 hachoir 嗅探每个 file 的 metadata（pip install hachoir 已落地）。
    def _video_attrs_from(m):
        if not getattr(m, "document", None):
            return None
        for a in m.document.attributes:
            if isinstance(a, DocumentAttributeVideo):
                return DocumentAttributeVideo(
                    duration=a.duration, w=a.w, h=a.h,
                    round_message=a.round_message,
                    supports_streaming=True,
                    nosound=a.nosound,
                )
        return None

    # 2026-05-15 萊斯：人類 TG client 本來就多線程並發下載 chunk，串行下載多個
    # 大視頻純屬自我設限。改全局並發 download（跨 group），Telethon 多 DC 連接
    # 突破單連接限速；download 完成後按 group send_file（上傳仍按 album 原子）。
    skipped_oversize = 0

    # 2026-05-29 frozen .app cwd=/（唯讀）修復：download_media 不傳 file= 會落進程
    # cwd；Finder 啟動的 .app cwd 是唯讀根目錄 → 每個藍鏈 media 下載 PermissionError、
    # 靜默失敗、paths 空、deliver 永不觸發。對齊 forward_keyword/fetch_discussion 顯式
    # file= 可寫 dir 的作法，下載到 tempdir（檔案過渡性，sink shutil.move 後即清）。
    _dl_dir = Path(tempfile.gettempdir()) / "hm_botmedia"
    _dl_dir.mkdir(parents=True, exist_ok=True)

    async def _dl_one(m, sem):
        size_mb = (m.document.size / 1024 / 1024) if (m.document and m.document.size) else 0
        if size_mb > max_size_mb:
            print(f"    ⏭️ skip bot-msg {m.id}: {size_mb:.0f}MB > cap {max_size_mb}MB "
                  f"(/start {token} @ @{bot_username} 手动自取)")
            return (m.id, None, None, True)  # oversize flag
        async with sem:
            try:
                # file= 顯式可寫 stem（m.id 唯一防撞），Telethon 自動補副檔名。
                p = await client.download_media(m, file=str(_dl_dir / str(m.id)))
                if p:
                    return (m.id, p, _video_attrs_from(m), False)
            except Exception as e:
                print(f"    ❌ bot-msg {m.id} download fail: {type(e).__name__}: {e}")
        return (m.id, None, None, False)

    # 全局並發 download（跨所有 group）；semaphore 限 DOWNLOAD_CONCURRENCY 路，
    # 平衡帶寬利用 + 不打爆 + human-like（TG app 一般 4 並發）。
    all_media = [m for gmsgs in groups.values() for m in gmsgs]
    sem = asyncio.Semaphore(DOWNLOAD_CONCURRENCY)
    print(f"    ⬇️ parallel download {len(all_media)} item(s), concurrency={DOWNLOAD_CONCURRENCY}")
    dl_results = await asyncio.gather(*[_dl_one(m, sem) for m in all_media])
    dl_map = {mid: (p, attrs) for mid, p, attrs, _ in dl_results}
    skipped_oversize = sum(1 for *_, ov in dl_results if ov)

    # ── HotspotMonitor sink path：一帖一 article 收「全部」media（跨 album flatten）──
    # 修 2026-05-29 多相冊丟片：原本逐 group deliver()，但 sink 用 url=...#bot_media
    # 去重 → 第 2+ 個 album 撞同一 url 被當重複丟棄（19-media 帖的視頻 album 正好整組丟，
    # 落地 0 視頻）。sink 端無 TG album 10 限，故跨組 flatten 成單次 deliver，
    # 全部 media 進同一 bot_media article。原生 send_file 路徑（無 sink）維持逐組不變。
    from backend.vendor.group_monitor import delivery as _hm_delivery
    if _hm_delivery.has_sink():
        sink_paths = []
        for _gid, _gmsgs in groups.items():
            for _m in sorted(_gmsgs, key=lambda x: x.id):
                _p, _a = dl_map.get(_m.id, (None, None))
                if _p:
                    sink_paths.append(_p)
        forwarded = 0
        try:
            if sink_paths:
                _first = all_media[0] if all_media else None
                _grp = getattr(_first, "grouped_id", None) if _first else None
                _rt = getattr(_first, "reply_to", None) if _first else None
                _rt_mid = getattr(_rt, "reply_to_msg_id", None) if _rt else None
                await _hm_delivery.deliver(
                    list(sink_paths), full_caption,
                    {"channel": channel, "src_msg_id": post_id, "kind": "bot_media",
                     "grouped_id": _grp, "reply_to_msg_id": _rt_mid})
                forwarded = len(sink_paths)
        finally:
            from pathlib import Path as _Path
            for _p in sink_paths:
                try:
                    _Path(_p).unlink(missing_ok=True)
                except Exception:
                    pass
        return {"forwarded": forwarded, "groups": len(groups),
                "skipped_oversize": skipped_oversize}

    forwarded = 0
    all_paths_for_cleanup = []
    try:
        for gid, gmsgs in groups.items():
            gmsgs.sort(key=lambda m: m.id)
            paths = []
            attrs_list = []  # 跟 paths 一一对应，单档透传用
            for m in gmsgs:
                p, attrs = dl_map.get(m.id, (None, None))
                if p:
                    paths.append(p)
                    attrs_list.append(attrs)
                    all_paths_for_cleanup.append(p)
            if not paths:
                continue
            # 第一組 album 带主帖完整文案 + 📎；后续组只 📎 尾缀
            caption = full_caption if is_first_group else tail_caption
            is_first_group = False
            # ── HotspotMonitor delivery seam（flag guard，保命零感知）──
            from backend.vendor.group_monitor import delivery as _hm_delivery
            if _hm_delivery.has_sink() and paths:
                # HotspotMonitor extension: pass grouped_id+reply_to for sink-side post grouping (CLAUDE.md #6 sanctioned narrow exception)
                _first_gmsg = gmsgs[0] if gmsgs else None
                _g_grouped_id = getattr(_first_gmsg, "grouped_id", None) if _first_gmsg else gid if isinstance(gid, int) else None
                _g_rt = getattr(_first_gmsg, "reply_to", None) if _first_gmsg else None
                _g_reply_to_mid = getattr(_g_rt, "reply_to_msg_id", None) if _g_rt else None
                await _hm_delivery.deliver(
                    list(paths), caption,
                    {"channel": channel, "src_msg_id": post_id, "kind": "bot_media",
                     "grouped_id": _g_grouped_id, "reply_to_msg_id": _g_reply_to_mid})
                forwarded += len(paths)
                continue
            # ── 原生 send_file（sink 未設＝live 行為不變）──
            try:
                if len(paths) > 1:
                    # album 靠 hachoir 自动嗅探每个 file metadata（DocumentAttributeVideo
                    # 等都会被 Telethon 通过 hachoir 解析后正确填到 server side）
                    # 纯 plain text：不传 parse_mode，避免主帖 # / backtick / emoji 炸 md
                    await client.send_file(target, paths, album=True, caption=caption,
                                           reply_to=reply_to_msg_id,
                                           supports_streaming=True)
                else:
                    # 单档显式透传 video attrs
                    extra = {"attributes": [attrs_list[0]]} if attrs_list[0] else {}
                    await client.send_file(target, paths[0], caption=caption,
                                           reply_to=reply_to_msg_id,
                                           supports_streaming=True, **extra)
                forwarded += len(paths)
                print(f"    ✓ uploaded {len(paths)} items (bot-album {gid}) [DUD]")
            except FloodWaitError as e:
                print(f"    ⚠️ FloodWait {e.seconds}s on bot-album upload — abort")
                return {"forwarded": forwarded, "groups": len(groups),
                        "skipped_oversize": skipped_oversize}
            except Exception as e:
                print(f"    ❌ bot-album upload fail ({gid}): {type(e).__name__}: {e}")
            await asyncio.sleep(2)
    finally:
        # DUD 即時清理（萊斯「上傳完進行刪除」要求）— 全局统一清理
        from pathlib import Path as _Path
        for p in all_paths_for_cleanup:
            try:
                _Path(p).unlink(missing_ok=True)
            except Exception:
                pass

    return {"forwarded": forwarded, "groups": len(groups), "skipped_oversize": skipped_oversize}
