#!/usr/bin/env python3
"""Two-step Reader login (avoids interactive stdin):

  Step A: send_code.py        → triggers TG to send code to phone
  Step B: TG_CODE=12345 sign_in.py    → completes sign-in

Run via repo's venv: .venv/bin/python scripts/login.py {send|signin}
"""
import asyncio
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402
from telethon import TelegramClient  # noqa: E402
from telethon.errors import SessionPasswordNeededError  # noqa: E402

load_dotenv(ROOT / ".env")
API_ID = int(os.environ["TG_API_ID"])
API_HASH = os.environ["TG_API_HASH"]
PHONE = os.environ["TG_PHONE"]
SESSION_NAME = os.environ.get("TG_SESSION_NAME", "monitor_session")
SESSION = str(ROOT / "sessions" / SESSION_NAME)
HASH_PATH = ROOT / "sessions" / ".phone_code_hash"


async def send_code():
    client = TelegramClient(SESSION, API_ID, API_HASH)
    await client.connect()
    if await client.is_user_authorized():
        me = await client.get_me()
        print(f"already logged in as: {me.username or me.first_name} ({me.phone})")
        await client.disconnect()
        return 0
    sent = await client.send_code_request(PHONE)
    HASH_PATH.write_text(sent.phone_code_hash, encoding="utf-8")
    print(f"code sent to {PHONE}, type={sent.type.__class__.__name__}")
    print(f"phone_code_hash saved → {HASH_PATH}")
    print("next: TG_CODE=12345 .venv/bin/python scripts/login.py signin")
    await client.disconnect()
    return 0


async def sign_in():
    code = os.environ.get("TG_CODE")
    if not code:
        print("ERROR: TG_CODE env not set", file=sys.stderr)
        return 1
    if not HASH_PATH.exists():
        print(f"ERROR: {HASH_PATH} missing — run `send` first", file=sys.stderr)
        return 1
    phone_code_hash = HASH_PATH.read_text(encoding="utf-8").strip()

    client = TelegramClient(SESSION, API_ID, API_HASH)
    await client.connect()
    try:
        await client.sign_in(PHONE, code, phone_code_hash=phone_code_hash)
    except SessionPasswordNeededError:
        pwd = os.environ.get("TG_2FA_PASSWORD")
        if not pwd:
            print("ERROR: 2FA enabled — set TG_2FA_PASSWORD", file=sys.stderr)
            return 1
        await client.sign_in(password=pwd)
    me = await client.get_me()
    print(f"signed in as: @{me.username or me.first_name} ({me.phone})")
    HASH_PATH.unlink(missing_ok=True)
    await client.disconnect()
    return 0


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("send", "signin"):
        print("Usage: login.py {send|signin}")
        sys.exit(1)
    coro = send_code() if sys.argv[1] == "send" else sign_in()
    sys.exit(asyncio.run(coro))


if __name__ == "__main__":
    main()
