"""
One-shot Telethon login for the monitor session.

Flow:
  1. Read api_id/api_hash/phone/2fa from .env (project root)
  2. send_code_request → Telegram sends SMS to phone
  3. Poll /tmp/.tg_code_login for the SMS code (user pastes it)
  4. sign_in(code) → if SessionPasswordNeededError, sign_in(password=2fa)
  5. Print AUTH_OK with user info, exit

The session file is written to sessions/<TG_SESSION_NAME>.session.
"""
import asyncio
import os
import sys
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneNumberBannedError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    FloodWaitError,
)

load_dotenv(PROJECT / ".env")

API_ID = int(os.environ["TG_API_ID"])
API_HASH = os.environ["TG_API_HASH"]
PHONE = os.environ["TG_PHONE"]
SESSION_NAME = os.environ.get("TG_SESSION_NAME", "monitor_session")
PASSWORD = os.environ.get("TG_2FA_PASSWORD") or None

SESSION_PATH = str(PROJECT / "sessions" / SESSION_NAME)
CODE_FILE = Path("/tmp/.tg_code_login")
CODE_TIMEOUT_SEC = 600


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


async def main():
    log(f"connecting api_id={API_ID} session={SESSION_NAME} phone={PHONE}")
    client = TelegramClient(SESSION_PATH, API_ID, API_HASH)
    await client.connect()

    if await client.is_user_authorized():
        me = await client.get_me()
        print(f"ALREADY_AUTHED id={me.id} username={me.username} phone={me.phone}", flush=True)
        await client.disconnect()
        return 0

    # Step 1: request SMS
    try:
        sent = await client.send_code_request(PHONE)
    except FloodWaitError as e:
        print(f"FLOOD_WAIT seconds={e.seconds}", flush=True)
        await client.disconnect()
        return 2
    except PhoneNumberBannedError:
        print("PHONE_BANNED", flush=True)
        await client.disconnect()
        return 3

    print(f"CODE_SENT type={sent.type.__class__.__name__} phone_code_hash_len={len(sent.phone_code_hash)}", flush=True)
    print(f"WAITING file={CODE_FILE} timeout={CODE_TIMEOUT_SEC}s", flush=True)

    # Step 2: poll for code file
    if CODE_FILE.exists():
        CODE_FILE.unlink()  # clear any stale value

    elapsed = 0
    while not CODE_FILE.exists() and elapsed < CODE_TIMEOUT_SEC:
        await asyncio.sleep(2)
        elapsed += 2

    if not CODE_FILE.exists():
        print("TIMEOUT_NO_CODE", flush=True)
        await client.disconnect()
        return 4

    code = CODE_FILE.read_text(encoding="utf-8").strip()
    CODE_FILE.unlink()
    log(f"got code (len={len(code)})")

    # Step 3: sign in with code, then 2FA if needed
    try:
        await client.sign_in(phone=PHONE, code=code, phone_code_hash=sent.phone_code_hash)
    except SessionPasswordNeededError:
        if not PASSWORD:
            print("NEED_2FA_BUT_NO_PASSWORD", flush=True)
            await client.disconnect()
            return 5
        log("2FA needed, signing in with password")
        await client.sign_in(password=PASSWORD)
    except PhoneCodeInvalidError:
        print("CODE_INVALID", flush=True)
        await client.disconnect()
        return 6
    except PhoneCodeExpiredError:
        print("CODE_EXPIRED", flush=True)
        await client.disconnect()
        return 7

    me = await client.get_me()
    print(
        f"AUTH_OK id={me.id} username={me.username} first={me.first_name} "
        f"last={me.last_name} phone={me.phone}",
        flush=True,
    )
    await client.disconnect()
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
