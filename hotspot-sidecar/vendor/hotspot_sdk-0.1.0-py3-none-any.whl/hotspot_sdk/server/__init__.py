"""hotspot_sdk.server — optional FastAPI service over the library (Unit 9).

Install with ``hotspot-sdk[server]``. Build the app via :func:`create_app`.
"""
from __future__ import annotations

__all__ = ["create_app"]


def __getattr__(name: str):
    # Lazy so importing the package doesn't require fastapi.
    if name == "create_app":
        from .app import create_app

        return create_app
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
