"""Run the HTTP service: ``python -m hotspot_sdk.server`` or ``hotspot-sdk-server``.

Config comes from ``HOTSPOT_*`` env vars and an optional ``HOTSPOT_CONFIG_FILE``
JSON path — keeping the entry point dependency-free of any hard-coded location.
"""
from __future__ import annotations

import os


def main() -> None:
    try:
        import uvicorn
    except ImportError as e:  # pragma: no cover
        raise SystemExit(
            "uvicorn not installed. Install with: pip install 'hotspot-sdk[server]'"
        ) from e

    from ..config import load_config
    from .app import create_app

    cfg = load_config(path=os.environ.get("HOTSPOT_CONFIG_FILE") or None)
    app = create_app(cfg)
    uvicorn.run(
        app,
        host=os.environ.get("HOTSPOT_HOST", "127.0.0.1"),
        port=int(os.environ.get("HOTSPOT_PORT", "8000")),
    )


if __name__ == "__main__":
    main()
