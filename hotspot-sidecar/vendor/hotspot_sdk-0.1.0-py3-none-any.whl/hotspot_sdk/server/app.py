"""FastAPI service shell — Unit 9.

A thin protocol-translation layer over the Python library. It contains **no business
logic**: every endpoint resolves config, calls a capability, and returns the typed
result. Capabilities whose optional dependencies (telethon / nudenet / ...) are not
installed degrade to a clear ``503`` rather than failing at import time.

Build the app with :func:`create_app` so the host controls configuration:

    from hotspot_sdk.server.app import create_app
    app = create_app(my_config)        # pass HotspotConfig | dict | None
"""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel

from ..adapters import CollectingSink
from ..config import HotspotConfig, load_config


class ScoreRequest(BaseModel):
    text: str


class SnapshotRequest(BaseModel):
    ranking: dict[str, int]


class AnalyzeRequest(BaseModel):
    path: str
    kind: str = "image"  # "image" | "video"


class ForwardRequest(BaseModel):
    keyword: str
    limit: Optional[int] = None


def create_app(config: HotspotConfig | dict | None = None):
    """Create the FastAPI app. ``fastapi`` is required (``hotspot-sdk[server]``)."""
    try:
        from fastapi import Depends, FastAPI, Header, HTTPException
    except ImportError as e:  # pragma: no cover - exercised via packaging, not unit
        raise RuntimeError(
            "FastAPI not installed. Install with: pip install 'hotspot-sdk[server]'"
        ) from e

    import os

    cfg = load_config(config)
    # Optional shared-secret gate. If HOTSPOT_API_KEY is set, every endpoint (except
    # /health) requires a matching X-API-Key header. Unset → no auth, which is only
    # safe on the loopback default bind. The mutating /telegram/* routes drive the
    # owner's logged-in account, so any non-loopback deploy MUST set this.
    api_key = os.environ.get("HOTSPOT_API_KEY")
    # /content/analyze reaches native media decoders with a caller-supplied path, so
    # it is confined to a configured root and capped in size. Disabled if unset.
    media_root = os.environ.get("HOTSPOT_MEDIA_ROOT")
    max_media_bytes = int(os.environ.get("HOTSPOT_MAX_MEDIA_BYTES", str(256 * 1024 * 1024)))

    async def require_api_key(x_api_key: Optional[str] = Header(default=None)):
        if api_key and x_api_key != api_key:
            raise HTTPException(401, "invalid or missing X-API-Key")

    def safe_media_path(raw: str) -> str:
        if not media_root:
            raise HTTPException(
                400, "content analysis disabled: set HOTSPOT_MEDIA_ROOT to enable it"
            )
        root = os.path.realpath(media_root)
        rp = os.path.realpath(raw)
        if rp != root and not rp.startswith(root + os.sep):
            raise HTTPException(403, "path is outside the configured media root")
        if not os.path.isfile(rp):
            raise HTTPException(422, "media file not found")
        if os.path.getsize(rp) > max_media_bytes:
            raise HTTPException(413, "media exceeds the configured size limit")
        return rp

    app = FastAPI(title="hotspot-sdk", version="0.1.0", dependencies=[Depends(require_api_key)])

    # A long-running service tracks the leaderboard across requests, so the ranker
    # is held on the app (stateful diffing) rather than rebuilt per request.
    from ..hotspot import HotspotRanker

    app.state.ranker = HotspotRanker(cfg)

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return {"status": "ok", "version": "0.1.0", "capabilities": _capabilities()}

    # ---- scoring (pure, always available) ----
    @app.post("/score")
    async def score(req: ScoreRequest):
        from ..scoring import VocabScorer

        return VocabScorer(cfg).score(req.text)

    # ---- hotspot ranking (pure, always available) ----
    @app.post("/hotspot/snapshot")
    async def hotspot_snapshot(req: SnapshotRequest):
        return await app.state.ranker.process_snapshot(req.ranking)

    # ---- content analysis (needs hotspot-sdk[content]) ----
    @app.post("/content/analyze")
    async def content_analyze(req: AnalyzeRequest):
        safe_path = safe_media_path(req.path)  # confines to media root, caps size
        try:
            from ..content import ContentAnalyzer
        except ImportError as e:
            raise HTTPException(503, f"content extra not installed: {e}")
        sink = CollectingSink()
        analyzer = ContentAnalyzer(cfg, sink=sink)
        if req.kind == "video":
            return await analyzer.analyze_video(safe_path)
        verdict = await analyzer.analyze_image(safe_path)
        if verdict is None:
            raise HTTPException(422, "could not decode media")
        return verdict

    # ---- telegram (needs hotspot-sdk[telegram] + live credentials) ----
    @app.post("/telegram/forward")
    async def telegram_forward(req: ForwardRequest):
        try:
            cfg.require_telegram()
        except ValueError as e:
            raise HTTPException(400, str(e))
        try:
            from ..telegram import TelegramMonitor
        except ImportError as e:
            raise HTTPException(503, f"telegram extra not installed: {e}")
        sink = CollectingSink()
        monitor = TelegramMonitor(cfg, sink=sink)
        await monitor.forward_keyword(req.keyword, limit=req.limit)
        return {"delivered": [i.model_dump() for i in sink.drain()]}

    @app.post("/telegram/run-once")
    async def telegram_run_once():
        try:
            cfg.require_telegram()
        except ValueError as e:
            raise HTTPException(400, str(e))
        try:
            from ..telegram import TelegramMonitor
        except ImportError as e:
            raise HTTPException(503, f"telegram extra not installed: {e}")
        sink = CollectingSink()
        monitor = TelegramMonitor(cfg, sink=sink)
        await monitor.run_once()
        return {"delivered": [i.model_dump() for i in sink.drain()]}

    return app


def _capabilities() -> dict[str, bool]:
    """Report which optional capabilities are importable in this install."""
    import importlib.util

    def have(mod: str) -> bool:
        return importlib.util.find_spec(mod) is not None

    return {
        "scoring": True,
        "hotspot": True,
        "content": have("nudenet") or have("cv2"),
        "telegram": have("telethon"),
    }
