"""Unified output adapter (sink) — the single seam between engine and host.

This generalises the ``group_monitor/delivery.py`` ``set_sink`` pattern to the whole
SDK: every capability produces typed items and hands them to an injectable
``OutputSink`` instead of side-effecting (uploading to TG, writing files, etc.).

⚠️ Process-local boundary (inherited from the original ``delivery._SINK`` warning):
a sink installed via the module-level ``set_default_sink`` is visible only inside the
process that set it. For multi-process deployments (e.g. the FastAPI server running
the monitor in a worker subprocess), install the sink inside the worker — never rely
on the main process's module state propagating to children. Prefer passing a sink
explicitly into each engine call where possible; the module-level default exists only
for parity with the original single-process design.
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable, Optional, Protocol, runtime_checkable

from pydantic import BaseModel


# ---- Typed output items, one per capability -------------------------------------

class ForwardedMedia(BaseModel):
    """A media post the Telegram engine forwarded/recovered."""
    paths: list[str]
    caption: str = ""
    source_channel: str = ""
    source_msg_id: int = 0
    meta: dict[str, Any] = {}


class RankingAlert(BaseModel):
    """A hotspot ranking change worth surfacing."""
    keyword: str
    kind: str            # "jump" | "drop" | "new_entry"
    rank: int = 0
    prev_rank: int = 0
    delta: int = 0
    meta: dict[str, Any] = {}


class ContentVerdict(BaseModel):
    """NSFW / cover analysis result for one media path."""
    path: str
    nsfw_score: float = 0.0
    action_score: float = 0.0
    sharp_score: float = 0.0
    labels: dict[str, float] = {}
    meta: dict[str, Any] = {}


class ScoreResult(BaseModel):
    """Copywriting / hotness score for a piece of text."""
    text: str
    score: float = 0.0
    breakdown: dict[str, float] = {}
    flags: list[str] = []


# ---- The sink protocol ----------------------------------------------------------

@runtime_checkable
class OutputSink(Protocol):
    """Where capabilities deliver their results.

    A host implements ``deliver`` to route items wherever it wants (DB, queue,
    re-upload to TG, ...). ``deliver`` is async to match the engine's async core and
    to let hosts do I/O without blocking the event loop.
    """

    async def deliver(self, item: BaseModel) -> dict:  # pragma: no cover - protocol
        ...


class CollectingSink:
    """Default sink: keeps delivered items in memory and returns them.

    Useful for ``import``-style usage where the caller just wants the data back, and
    for tests. Never raises on a normal deliver.
    """

    def __init__(self) -> None:
        self.items: list[BaseModel] = []

    async def deliver(self, item: BaseModel) -> dict:
        self.items.append(item)
        return {"ok": True, "count": len(self.items)}

    def drain(self) -> list[BaseModel]:
        items = self.items
        self.items = []
        return items


class CallbackSink:
    """Adapter that wraps a plain (sync or async) callable as a sink."""

    def __init__(self, fn: Callable[[BaseModel], Any | Awaitable[Any]]) -> None:
        self._fn = fn

    async def deliver(self, item: BaseModel) -> dict:
        result = self._fn(item)
        if hasattr(result, "__await__"):
            result = await result
        return result if isinstance(result, dict) else {"ok": True}


# ---- Module-level default (process-local, parity with delivery._SINK) ------------

_DEFAULT_SINK: Optional[OutputSink] = None


def set_default_sink(sink: OutputSink | None) -> None:
    """Install a process-local default sink. See the process-local warning above."""
    global _DEFAULT_SINK
    _DEFAULT_SINK = sink


def clear_default_sink() -> None:
    global _DEFAULT_SINK
    _DEFAULT_SINK = None


def get_default_sink() -> Optional[OutputSink]:
    return _DEFAULT_SINK


def resolve_sink(sink: OutputSink | None = None) -> OutputSink:
    """Pick the sink to use: explicit arg > process default > a fresh CollectingSink.

    Never returns ``None`` so callers can always ``await sink.deliver(...)``.
    """
    if sink is not None:
        return sink
    if _DEFAULT_SINK is not None:
        return _DEFAULT_SINK
    return CollectingSink()


async def safe_deliver(sink: OutputSink, item: BaseModel) -> dict:
    """Deliver while shielding the engine from a misbehaving host sink.

    Mirrors the original engine guarantee that delivery problems never crash a scan.
    """
    try:
        return await sink.deliver(item)
    except Exception as e:  # noqa: BLE001 - intentional boundary
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
